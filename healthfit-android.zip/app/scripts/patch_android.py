"""Prepara il progetto Android generato da Capacitor: codice nativo, permessi, servizio, icone, versione e firma."""
import os, re, shutil, subprocess, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))   # cartella app/
AND = os.path.join(ROOT, "android")
build = int(sys.argv[1]) if len(sys.argv) > 1 else 1

# 1) codice nativo
dst = os.path.join(AND, "app/src/main/java/it/healthfit/app")
os.makedirs(dst, exist_ok=True)
for f in os.listdir(os.path.join(ROOT, "native")):
    if f.endswith(".java"):
        shutil.copy(os.path.join(ROOT, "native", f), os.path.join(dst, f))

# 2) permessi e servizio nel manifest
mf = os.path.join(AND, "app/src/main/AndroidManifest.xml")
m = open(mf, encoding="utf-8").read()
perms = [
    '<uses-permission android:name="android.permission.BLUETOOTH" android:maxSdkVersion="30" />',
    '<uses-permission android:name="android.permission.BLUETOOTH_ADMIN" android:maxSdkVersion="30" />',
    '<uses-permission android:name="android.permission.BLUETOOTH_SCAN" />',
    '<uses-permission android:name="android.permission.BLUETOOTH_CONNECT" />',
    '<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />',
    '<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />',
    '<uses-permission android:name="android.permission.FOREGROUND_SERVICE" />',
    '<uses-permission android:name="android.permission.FOREGROUND_SERVICE_CONNECTED_DEVICE" />',
    '<uses-permission android:name="android.permission.FOREGROUND_SERVICE_LOCATION" />',
    '<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />',
    '<uses-permission android:name="android.permission.WAKE_LOCK" />',
    '<uses-permission android:name="android.permission.VIBRATE" />',
    '<uses-permission android:name="android.permission.CAMERA" />',
    '<uses-permission android:name="android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS" />',
    '<uses-permission android:name="android.permission.health.READ_HEALTH_DATA_HISTORY" />',
    '<uses-feature android:name="android.hardware.bluetooth_le" android:required="false" />',
    '<uses-feature android:name="android.hardware.camera" android:required="false" />',
]
if "BLUETOOTH_CONNECT" not in m:
    m = m.replace('<uses-permission android:name="android.permission.INTERNET" />',
                  '<uses-permission android:name="android.permission.INTERNET" />\n    ' + "\n    ".join(perms))
svc = '<service android:name=".HrService" android:exported="false" android:foregroundServiceType="connectedDevice|location" />'
if ".HrService" not in m:
    m = m.replace("</application>", "    " + svc + "\n    </application>")
open(mf, "w", encoding="utf-8").write(m)

# 3) versione e firma
bg = os.path.join(AND, "app/build.gradle")
g = open(bg, encoding="utf-8").read()
g = re.sub(r"versionCode \d+", f"versionCode {build}", g)
g = re.sub(r'versionName "[^"]*"', f'versionName "1.{build}"', g)
if "signingConfigs" not in g:
    g = g.replace("    buildTypes {", """    signingConfigs {
        release {
            storeFile file('../../healthfit.p12')
            storePassword 'healthfit2026'
            keyAlias 'healthfit'
            keyPassword 'healthfit2026'
            storeType 'pkcs12'
        }
    }
    buildTypes {""", 1)
    g = g.replace("            minifyEnabled false", "            minifyEnabled false\n            signingConfig signingConfigs.release", 1)
open(bg, "w", encoding="utf-8").write(g)

# 4) icone (dall'icona dell'app)
icon = os.path.join(ROOT, "icon.png")
sizes = {"mdpi": 48, "hdpi": 72, "xhdpi": 96, "xxhdpi": 144, "xxxhdpi": 192}
res = os.path.join(AND, "app/src/main/res")
shutil.rmtree(os.path.join(res, "mipmap-anydpi-v26"), ignore_errors=True)
for d, px in sizes.items():
    for name in ("ic_launcher.png", "ic_launcher_round.png", "ic_launcher_foreground.png"):
        out = os.path.join(res, f"mipmap-{d}", name)
        subprocess.run(["convert", icon, "-resize", f"{px}x{px}", out], check=True)

# 5) Health Connect: Android 8+ e informativa privacy
vg = os.path.join(AND, "variables.gradle")
v = open(vg, encoding="utf-8").read()
v = re.sub(r"minSdkVersion = \d+", "minSdkVersion = 26", v)
open(vg, "w", encoding="utf-8").write(v)
sx = os.path.join(AND, "app/src/main/res/values/strings.xml")
x = open(sx, encoding="utf-8").read()
if "health_connect_privacy_policy_url" not in x:
    x = x.replace("</resources>", '    <string name="health_connect_privacy_policy_url">https://health-fitness-app.github.io/health-fitness/privacy.html</string>\n</resources>')
open(sx, "w", encoding="utf-8").write(x)
print(f"Progetto pronto: versione 1.{build} (codice {build})")
