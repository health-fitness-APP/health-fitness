"""Prepara il progetto Android generato da Capacitor: codice nativo, permessi, servizio, icone, versione e firma."""
import os, re, shutil, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))   # cartella app/
AND = os.path.join(ROOT, "android")
build = int(sys.argv[1]) if len(sys.argv) > 1 else 1

# 1) codice nativo
dst = os.path.join(AND, "app/src/main/java/it/healthfit/app")
os.makedirs(dst, exist_ok=True)
for f in os.listdir(os.path.join(ROOT, "native")):
    if f.endswith(".java"):
        shutil.copy(os.path.join(ROOT, "native", f), os.path.join(dst, f))

# 2) permessi e servizio nel manifest
mf = os.path.join(AND, "app/src/main/AndroidManifest.xml")
m = open(mf, encoding="utf-8").read()
perms = [
    '<uses-permission android:name="android.permission.BLUETOOTH" android:maxSdkVersion="30" />',
    '<uses-permission android:name="android.permission.BLUETOOTH_ADMIN" android:maxSdkVersion="30" />',
    '<uses-permission android:name="android.permission.BLUETOOTH_SCAN" />',
    '<uses-permission android:name="android.permission.BLUETOOTH_CONNECT" />',
    '<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />',
    '<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />',
    '<uses-permission android:name="android.permission.FOREGROUND_SERVICE" />',
    '<uses-permission android:name="android.permission.FOREGROUND_SERVICE_CONNECTED_DEVICE" />',
    '<uses-permission android:name="android.permission.FOREGROUND_SERVICE_LOCATION" />',
    '<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />',
    '<uses-permission android:name="android.permission.WAKE_LOCK" />',
    '<uses-permission android:name="android.permission.ACTIVITY_RECOGNITION" />',
    '<uses-permission android:name="com.google.android.gms.permission.ACTIVITY_RECOGNITION" />',
    '<uses-permission android:name="android.permission.ACCESS_BACKGROUND_LOCATION" />',
    '<uses-permission android:name="android.permission.VIBRATE" />',
    '<uses-permission android:name="android.permission.CAMERA" />',
    '<uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM" android:maxSdkVersion="32" />',
    '<uses-permission android:name="android.permission.USE_EXACT_ALARM" />',
    '<uses-permission android:name="android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS" />',
    '<uses-permission android:name="android.permission.health.READ_HEALTH_DATA_HISTORY" />',
    '<uses-permission android:name="android.permission.health.READ_SPEED" />',
    '<uses-permission android:name="android.permission.health.READ_EXERCISE_ROUTES" />',
    '<uses-feature android:name="android.hardware.bluetooth_le" android:required="false" />',
    '<uses-feature android:name="android.hardware.camera" android:required="false" />',
]
if "BLUETOOTH_CONNECT" not in m:
    m = m.replace('<uses-permission android:name="android.permission.INTERNET" />',
                  '<uses-permission android:name="android.permission.INTERNET" />\n    ' + "\n    ".join(perms))
svc = '<service android:name=".HrService" android:exported="false" android:foregroundServiceType="connectedDevice|location" />'
if ".HrService" not in m:
    m = m.replace("</application>", "    " + svc + "\n    </application>")
wsvc = """<service android:name=".PhoneWatchListener" android:exported="true">
            <intent-filter>
                <action android:name="com.google.android.gms.wearable.MESSAGE_RECEIVED" />
                <data android:scheme="wear" android:host="*" android:pathPrefix="/healthfit" />
            </intent-filter>
            <intent-filter>
                <action android:name="com.google.android.gms.wearable.DATA_CHANGED" />
                <data android:scheme="wear" android:host="*" android:pathPrefix="/healthfit" />
            </intent-filter>
        </service>"""
if ".PhoneWatchListener" not in m:
    m = m.replace("</application>", "    " + wsvc + "\n    </application>")
rcv = '<receiver android:name=".RestAlarmReceiver" android:exported="false" />'
if ".RestAlarmReceiver" not in m:
    m = m.replace("</application>", "    " + rcv + "\n    </application>")
arc = '<receiver android:name=".AutoActReceiver" android:exported="false" />'
if ".AutoActReceiver" not in m:
    m = m.replace("</application>", "    " + arc + "\n    </application>")
boot = """<receiver android:name=".AutoActBoot" android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED" />
                <action android:name="android.intent.action.MY_PACKAGE_REPLACED" />
            </intent-filter>
        </receiver>"""
if ".AutoActBoot" not in m:
    m = m.replace("</application>", "    " + boot + "\n    </application>")
sg = '<receiver android:name=".SkiGuard$Act" android:exported="false" />'
if ".SkiGuard$Act" not in m:
    m = m.replace("</application>", "    " + sg + "\n    </application>")
for perm in ("android.permission.SEND_SMS", "android.permission.USE_FULL_SCREEN_INTENT"):
    if perm not in m:
        m = m.replace('<uses-permission android:name="android.permission.INTERNET" />',
                      '<uses-permission android:name="android.permission.INTERNET" />\n    <uses-permission android:name="' + perm + '" />')
if "RECEIVE_BOOT_COMPLETED" not in m:
    m = m.replace('<uses-permission android:name="android.permission.INTERNET" />',
                  '<uses-permission android:name="android.permission.INTERNET" />\n    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />')
open(mf, "w", encoding="utf-8").write(m)

# 3) versione e firma
bg = os.path.join(AND, "app/build.gradle")
g = open(bg, encoding="utf-8").read()
g = re.sub(r"versionCode \d+", f"versionCode {build}", g)
g = re.sub(r'versionName "[^"]*"', f'versionName "1.{build}"', g)
if "signingConfigs" not in g:
    g = g.replace("    buildTypes {", """    signingConfigs {
        release {
            storeFile file('../../healthfit.p12')
            storePassword 'healthfit2026'
            keyAlias 'healthfit'
            keyPassword 'healthfit2026'
            storeType 'pkcs12'
        }
    }
    buildTypes {""", 1)
    g = g.replace("            minifyEnabled false", "            minifyEnabled false\n            signingConfig signingConfigs.release", 1)
if "checkReleaseBuilds" not in g:
    g = g.replace("android {", "android {\n    lint { checkReleaseBuilds false; abortOnError false }", 1)
if "play-services-wearable" not in g:
    g = g.replace("dependencies {", """dependencies {
    implementation 'com.google.android.gms:play-services-wearable:18.2.0'
    implementation 'com.google.android.gms:play-services-location:21.3.0'
    implementation 'androidx.wear:wear-remote-interactions:1.1.0'
    implementation 'com.google.guava:guava:33.3.1-android'""", 1)
open(bg, "w", encoding="utf-8").write(g)

# 4) icone: già pronte in tutte le misure nella cartella icons/ (nessun programma esterno)
res = os.path.join(AND, "app/src/main/res")
shutil.rmtree(os.path.join(res, "mipmap-anydpi-v26"), ignore_errors=True)
icons = os.path.join(ROOT, "icons")
for d in os.listdir(icons):
    for name in os.listdir(os.path.join(icons, d)):
        os.makedirs(os.path.join(res, d), exist_ok=True)
        shutil.copy(os.path.join(icons, d, name), os.path.join(res, d, name))

# 5) Health Connect: Android 8+ e informativa privacy
vg = os.path.join(AND, "variables.gradle")
v = open(vg, encoding="utf-8").read()
v = re.sub(r"minSdkVersion = \d+", "minSdkVersion = 26", v)
open(vg, "w", encoding="utf-8").write(v)
sx = os.path.join(AND, "app/src/main/res/values/strings.xml")
x = open(sx, encoding="utf-8").read()
if "health_connect_privacy_policy_url" not in x:
    x = x.replace("</resources>", '    <string name="health_connect_privacy_policy_url">https://health-fitness-app.github.io/health-fitness/privacy.html</string>\n</resources>')
open(sx, "w", encoding="utf-8").write(x)
print(f"Progetto pronto: versione 1.{build} (codice {build})")
