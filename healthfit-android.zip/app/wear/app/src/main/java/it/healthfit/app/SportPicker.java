package it.healthfit.app;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

/**
 * Scelta dello sport a cerchi: quello al centro è grande, i vicini più piccoli ai lati, il nome sopra.
 * Si scorre col dito o con la ghiera; un tocco sul cerchio centrale avvia.
 */
public class SportPicker extends View {
    public interface Listener { void onPick(String sport); void onStart(String sport); }
    private final String[] keys = RunService.SPORTS;
    private float pos = 0;              // indice (anche frazionario) dello sport al centro
    private Listener l;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG), ico = new Paint(Paint.ANTI_ALIAS_FLAG), txt = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float downX, downPos; private boolean dragging;
    private ValueAnimator anim;

    public SportPicker(Context c) {
        super(c);
        ico.setStyle(Paint.Style.STROKE); ico.setStrokeCap(Paint.Cap.ROUND); ico.setStrokeJoin(Paint.Join.ROUND); ico.setColor(0xFF0B2A1E);
        txt.setColor(0xFFFFFFFF); txt.setTypeface(Typeface.DEFAULT_BOLD); txt.setTextAlign(Paint.Align.CENTER);
    }
    public void setListener(Listener x) { l = x; }
    public void setSport(String k) { int i = java.util.Arrays.asList(keys).indexOf(k); pos = Math.max(0, i); invalidate(); }
    public boolean busy() { return dragging || (anim != null && anim.isRunning()); }
    public String sport() { return keys[Math.round(pos)]; }

    @Override protected void onMeasure(int w, int h) { int W = MeasureSpec.getSize(w); setMeasuredDimension(W, Math.round(W * 0.62f)); }

    @Override protected void onDraw(Canvas c) {
        float W = getWidth(), H = getHeight(), cy = H * 0.62f;
        txt.setTextSize(W * 0.085f);
        c.drawText(RunService.sportName(sport()), W / 2f, H * 0.14f, txt);
        // prima i cerchi lontani, poi i vicini, per ultimo quello al centro
        Integer[] order = new Integer[keys.length]; for (int i = 0; i < keys.length; i++) order[i] = i;
        java.util.Arrays.sort(order, (a, b) -> Float.compare(Math.abs(b - pos), Math.abs(a - pos)));
        for (int i : order) {
            float d = i - pos, ad = Math.abs(d); if (ad > 2.6f) continue;
            float r = W * (0.235f - Math.min(ad, 2f) * 0.055f);
            float cx = W / 2f + Math.signum(d) * W * (ad <= 1 ? ad * 0.30f : 0.30f + (ad - 1) * 0.18f);
            int a = ad < 0.5f ? 255 : ad < 1.5f ? 215 : 150;
            fill.setShader(new LinearGradient(cx - r, cy - r, cx + r, cy + r, ad < 0.5f ? 0xFF3FF0B0 : 0xFF2FD28A, ad < 0.5f ? 0xFF21C873 : 0xFF1B9E68, Shader.TileMode.CLAMP));
            fill.setAlpha(a); c.drawCircle(cx, cy, r, fill);
            ico.setAlpha(a); ico.setStrokeWidth(r * 0.085f);
            drawIcon(c, keys[i], cx, cy, r * 0.55f);
        }
    }

    /** Icone semplici disegnate a linee (omino stilizzato), centrate in (x,y), raggio s. */
    private void drawIcon(Canvas c, String k, float x, float y, float s) {
        Paint p = ico; Paint head = new Paint(p); head.setStyle(Paint.Style.FILL);
        switch (k) {
            case "run":
                c.drawCircle(x + s * 0.20f, y - s * 0.72f, s * 0.16f, head);
                line(c, x + s * 0.10f, y - s * 0.48f, x - s * 0.10f, y + s * 0.08f);        // busto
                line(c, x - s * 0.10f, y + s * 0.08f, x + s * 0.35f, y + s * 0.38f); line(c, x + s * 0.35f, y + s * 0.38f, x + s * 0.25f, y + s * 0.85f);
                line(c, x - s * 0.10f, y + s * 0.08f, x - s * 0.45f, y + s * 0.45f); line(c, x - s * 0.45f, y + s * 0.45f, x - s * 0.80f, y + s * 0.35f);
                line(c, x + s * 0.05f, y - s * 0.35f, x + s * 0.45f, y - s * 0.10f); line(c, x + s * 0.05f, y - s * 0.35f, x - s * 0.35f, y - s * 0.20f);
                break;
            case "walk":
                c.drawCircle(x, y - s * 0.75f, s * 0.16f, head);
                line(c, x, y - s * 0.50f, x - s * 0.02f, y + s * 0.10f);
                line(c, x - s * 0.02f, y + s * 0.10f, x + s * 0.28f, y + s * 0.85f); line(c, x - s * 0.02f, y + s * 0.10f, x - s * 0.30f, y + s * 0.85f);
                line(c, x, y - s * 0.38f, x + s * 0.28f, y + s * 0.05f); line(c, x, y - s * 0.38f, x - s * 0.26f, y + s * 0.02f);
                break;
            case "ski":
                c.drawCircle(x + s * 0.30f, y - s * 0.70f, s * 0.15f, head);
                line(c, x + s * 0.18f, y - s * 0.48f, x - s * 0.08f, y - s * 0.02f);
                line(c, x - s * 0.08f, y - s * 0.02f, x + s * 0.22f, y + s * 0.22f); line(c, x + s * 0.22f, y + s * 0.22f, x - s * 0.05f, y + s * 0.50f);
                line(c, x + s * 0.10f, y - s * 0.35f, x + s * 0.55f, y - s * 0.05f); line(c, x + s * 0.55f, y - s * 0.05f, x + s * 0.40f, y + s * 0.60f);   // bastoncino
                line(c, x - s * 0.80f, y + s * 0.40f, x + s * 0.55f, y + s * 0.78f);   // sci
                break;
            case "bike":
                c.drawCircle(x - s * 0.50f, y + s * 0.40f, s * 0.36f, p); c.drawCircle(x + s * 0.50f, y + s * 0.40f, s * 0.36f, p);
                line(c, x - s * 0.50f, y + s * 0.40f, x - s * 0.05f, y - s * 0.10f); line(c, x - s * 0.05f, y - s * 0.10f, x + s * 0.35f, y - s * 0.10f);
                line(c, x + s * 0.35f, y - s * 0.10f, x + s * 0.50f, y + s * 0.40f); line(c, x - s * 0.05f, y - s * 0.10f, x + s * 0.05f, y + s * 0.40f);
                line(c, x + s * 0.05f, y + s * 0.40f, x - s * 0.50f, y + s * 0.40f); line(c, x + s * 0.30f, y - s * 0.30f, x + s * 0.45f, y - s * 0.30f);
                c.drawCircle(x + s * 0.10f, y - s * 0.65f, s * 0.15f, head);
                break;
            default:   // palestra: manubrio
                RectF a = new RectF(x - s * 0.85f, y - s * 0.40f, x - s * 0.55f, y + s * 0.40f), b = new RectF(x + s * 0.55f, y - s * 0.40f, x + s * 0.85f, y + s * 0.40f);
                c.drawRoundRect(a, s * 0.08f, s * 0.08f, head); c.drawRoundRect(b, s * 0.08f, s * 0.08f, head);
                RectF a2 = new RectF(x - s * 0.55f, y - s * 0.25f, x - s * 0.40f, y + s * 0.25f), b2 = new RectF(x + s * 0.40f, y - s * 0.25f, x + s * 0.55f, y + s * 0.25f);
                c.drawRect(a2, head); c.drawRect(b2, head);
                line(c, x - s * 0.40f, y, x + s * 0.40f, y);
        }
    }
    private void line(Canvas c, float a, float b, float x, float y) { c.drawLine(a, b, x, y, ico); }

    /** Scorre di uno (ghiera o tasto). */
    public void step(int dir) { go(Math.max(0, Math.min(keys.length - 1, Math.round(pos) + dir))); }
    private void go(int target) {
        if (anim != null) anim.cancel();
        anim = ValueAnimator.ofFloat(pos, target); anim.setDuration(220); anim.setInterpolator(new DecelerateInterpolator());
        anim.addUpdateListener(v -> { pos = (float) v.getAnimatedValue(); invalidate(); });
        anim.start();
        if (l != null) l.onPick(keys[target]);
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        float W = getWidth();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: downX = e.getX(); downPos = pos; dragging = false; if (anim != null) anim.cancel(); return true;
            case MotionEvent.ACTION_MOVE:
                float dx = e.getX() - downX;
                if (!dragging && Math.abs(dx) > W * 0.04f) { dragging = true; getParent().requestDisallowInterceptTouchEvent(true); }
                if (dragging) { pos = Math.max(-0.3f, Math.min(keys.length - 0.7f, downPos - dx / (W * 0.30f))); invalidate(); }
                return true;
            case MotionEvent.ACTION_UP:
                if (dragging) { go(Math.max(0, Math.min(keys.length - 1, Math.round(pos)))); return true; }
                float cx = W / 2f, cy = getHeight() * 0.62f, r = W * 0.235f;
                if (Math.hypot(e.getX() - cx, e.getY() - cy) <= r) { if (l != null) l.onStart(sport()); }
                else if (e.getX() < cx) step(-1); else step(1);
                return true;
            case MotionEvent.ACTION_CANCEL: go(Math.max(0, Math.min(keys.length - 1, Math.round(pos)))); return true;
        }
        return super.onTouchEvent(e);
    }
}
