package it.healthfit.app;

import java.util.Arrays;

/**
 * Metriche di corsa avanzate dall'accelerometro del polso, passo per passo (stime come quelle di Samsung Health).
 * Ogni appoggio del piede spinge il corpo verso l'alto: la forza verticale sale sopra 1 g e poi torna sotto.
 * Dal momento in cui inizia ogni spinta ricavo la durata del passo; dalla parte della spinta sopra 1 g ricavo il tempo
 * di contatto con il modello "molla-massa" (spinta a mezza sinusoide, impulso medio = peso corporeo).
 * Classe senza Android: riceve i campioni da RunDynamics.
 */
final class StepAnalyzer {
    private static final double G = 9.80665;
    private static final long MS = 1_000_000L;
    private double gx, gy, gz, f = 1;   // gravità (dal sensore di gravità se c'è, altrimenti media lenta) e forza verticale filtrata, in g
    private boolean gInit, gSensor;
    private long lastT = 0;
    // spinta in corso (forza sopra 1 g)
    private boolean high;
    private long hiStart, hiEnd, lowSince;
    private double hiPeak;
    private long prevStart = 0;          // inizio della spinta del passo precedente (ns)
    private int chain = 0;               // sequenza di passi consecutivi senza buchi
    // passi validi: durata del passo e tempo di contatto (s), sequenza di appartenenza
    private float[] T = new float[4096], C = new float[4096];
    private int[] K = new int[4096];
    private int n = 0;
    // movimento del braccio/corpo (anche camminata) per la pausa automatica: ultimo istante e inizio del movimento continuo (ms)
    volatile long lastMove = 0, moveStart = 0;

    /** Gravità dal sensore di fusione dell'orologio (più precisa durante l'oscillazione del braccio). */
    synchronized void gravity(float x, float y, float z) { gx = x; gy = y; gz = z; gInit = true; gSensor = true; }

    /** Interrompe la sequenza (pausa, ripresa): il passo dopo non viene confrontato con quello prima. */
    synchronized void breakChain() { prevStart = 0; high = false; lastT = 0; chain++; }

    synchronized void add(long tNs, float ax, float ay, float az) {
        if (!gInit) { gx = ax; gy = ay; gz = az; gInit = true; }
        if (lastT == 0 || tNs <= lastT || tNs - lastT > 500 * MS) { lastT = tNs; if (prevStart != 0) breakChain(); lastT = tNs; return; }
        double dt = (tNs - lastT) / 1e9; long tPrev = lastT; lastT = tNs;
        if (!gSensor) { double a = dt / (1.0 + dt); gx += (ax - gx) * a; gy += (ay - gy) * a; gz += (az - gz) * a; }
        double gn = Math.sqrt(gx * gx + gy * gy + gz * gz); if (gn < 1) return;
        double fv = (ax * gx + ay * gy + az * gz) / gn / G;
        double f0 = f; f += (fv - f) * (dt / (0.02 + dt));   // filtro a circa 8 Hz: tolgo le vibrazioni dell'impatto
        if (Math.abs(f - 1) > 0.15) { long now = System.currentTimeMillis(); if (now - lastMove > 700) moveStart = now; lastMove = now; }
        long tx = tNs - (long) ((tNs - tPrev) * Math.max(0, Math.min(1, (f - 1) / (f - f0 == 0 ? 1e-9 : f - f0))));   // istante esatto in cui passa 1 g
        if (!high) { if (f > 1.0) { high = true; hiStart = tx; hiEnd = tx; hiPeak = f; lowSince = 0; } return; }
        if (f > hiPeak) hiPeak = f;
        if (f < 1.0) {
            if (lowSince == 0) { lowSince = tNs; hiEnd = tx; }
            else if (tNs - lowSince > 40 * MS) { high = false; step(hiStart, hiEnd, hiPeak); }
        } else lowSince = 0;
    }

    private void step(long start, long end, double peak) {
        double d = (end - start) / 1e9;
        if (peak < 1.3 || d < 0.04 || d > 0.40) return;            // non è un appoggio di corsa
        if (prevStart != 0) {
            double t = (start - prevStart) / 1e9;
            if (t < 0.24) return;                                     // rimbalzo dentro lo stesso passo: lo ignoro
            if (t > 0.45) chain++;                                    // passo perso o camminata: nuova sequenza
            else {
                double c = contact(d, t);
                if (n == T.length) { T = Arrays.copyOf(T, n * 2); C = Arrays.copyOf(C, n * 2); K = Arrays.copyOf(K, n * 2); }
                T[n] = (float) t; C[n] = (float) c; K[n] = chain; n++;
            }
        }
        prevStart = start;
    }

    /** Tempo di contatto dalla durata d della spinta sopra 1 g e dalla durata t del passo (modello a mezza sinusoide). */
    static double contact(double d, double t) {
        double lo = d, hi = t * 0.92;
        if (g(hi, t) <= d) return hi;
        for (int i = 0; i < 40; i++) { double m = (lo + hi) / 2; if (g(m, t) < d) lo = m; else hi = m; }
        return Math.max(0.12, Math.min(0.40, (lo + hi) / 2));
    }
    private static double g(double tc, double t) { return tc * (1 - 2 / Math.PI * Math.asin(Math.min(1, 2 * tc / (Math.PI * t)))); }

    /**
     * Risultato: {passi usati, durata del passo, contatto, volo (s), asimmetria (%), variabilità della falcata (%)},
     * oppure null se i passi di corsa sono troppo pochi.
     */
    synchronized double[] result() {
        if (n < 60) return null;
        float[] tf = new float[n]; for (int i = 0; i < n; i++) tf[i] = T[i] - C[i];
        // a blocchi di 20 passi della stessa sequenza: passi pari e dispari (destro e sinistro) e falcate (due passi)
        int B = 20; double[] asy = new double[n / B + 1], cv = new double[n / B + 1]; int nb = 0;
        int i = 0;
        while (i + B <= n) {
            if (K[i + B - 1] != K[i]) { int j = i; while (K[j] == K[i]) j++; i = j; continue; }
            double se = 0, so = 0; for (int j = 0; j < B; j++) { if (j % 2 == 0) se += T[i + j]; else so += T[i + j]; }
            se /= B / 2.0; so /= B / 2.0;
            asy[nb] = Math.abs(se - so) / ((se + so) / 2) * 100;
            double[] s = new double[B / 2]; double m = 0; for (int j = 0; j < B / 2; j++) { s[j] = T[i + 2 * j] + T[i + 2 * j + 1]; m += s[j]; } m /= B / 2.0;
            double v = 0; for (double x : s) v += (x - m) * (x - m); cv[nb] = Math.sqrt(v / (B / 2.0 - 1)) / m * 100;
            nb++; i += B;
        }
        return new double[]{ n, mean(T, n), mean(C, n), mean(tf, n), nb > 0 ? med(asy, nb) : -1, nb > 0 ? med(cv, nb) : -1 };
    }
    /** Media senza il 10% più basso e il 10% più alto (passi anomali). */
    private static double mean(float[] a, int n) { float[] b = Arrays.copyOf(a, n); Arrays.sort(b); double s = 0; int c = 0; for (int i = n / 10; i < n - n / 10; i++) { s += b[i]; c++; } return s / c; }
    private static double med(double[] a, int n) { double[] b = Arrays.copyOf(a, n); Arrays.sort(b); return b[n / 2]; }
}
