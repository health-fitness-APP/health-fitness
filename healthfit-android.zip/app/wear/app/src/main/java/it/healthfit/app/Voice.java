package it.healthfit.app;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioDeviceInfo;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;

import com.google.android.gms.wearable.Wearable;

import java.nio.charset.StandardCharsets;
import java.util.Locale;

/**
 * Voce durante la corsa, come Samsung Health. Parla dalle cuffie collegate all'orologio se ci sono;
 * altrimenti fa parlare il telefono (dove di solito ci sono cuffie e Spotify); se il telefono non c'è, usa l'altoparlante dell'orologio.
 * La musica si abbassa mentre parla e torna al volume normale subito dopo.
 */
final class Voice {
    private final Context ctx;
    private final Handler h = new Handler(Looper.getMainLooper());
    private TextToSpeech tts;
    private boolean ready = false;
    private int speaking = 0;
    private AudioManager am;
    private AudioFocusRequest focusReq;

    Voice(Context c) {
        ctx = c.getApplicationContext();
        am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
        try {
            tts = new TextToSpeech(ctx, st -> { if (st != TextToSpeech.SUCCESS) return;
                tts.setLanguage(Locale.ITALIAN);
                tts.setAudioAttributes(attrs());
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String id) {}
                    @Override public void onDone(String id) { h.post(() -> { speaking = Math.max(0, speaking - 1); if (speaking == 0) releaseFocus(); }); }
                    @SuppressWarnings("deprecation")
                    @Override public void onError(String id) { onDone(id); }
                });
                ready = true; });
        } catch (Exception ignored) {}
    }

    private static AudioAttributes attrs() {
        return new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build();
    }

    /** Cuffie Bluetooth collegate all'orologio? */
    private boolean watchHeadset() {
        try {
            for (AudioDeviceInfo d : am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)) {
                int t = d.getType();
                if (t == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP || t == AudioDeviceInfo.TYPE_BLUETOOTH_SCO) return true;
                if (Build.VERSION.SDK_INT >= 31 && t == AudioDeviceInfo.TYPE_BLE_HEADSET) return true;
            }
        } catch (Exception ignored) {}
        return false;
    }

    void say(String msg) {
        if (msg == null || msg.isEmpty()) return;
        if (watchHeadset()) { speakHere(msg); return; }
        final byte[] data = msg.getBytes(StandardCharsets.UTF_8);
        Wearable.getNodeClient(ctx).getConnectedNodes()
            .addOnSuccessListener(nodes -> {
                if (nodes.isEmpty()) { speakHere(msg); return; }
                Wearable.getMessageClient(ctx).sendMessage(nodes.get(0).getId(), "/healthfit/say", data)
                    .addOnFailureListener(e -> speakHere(msg));
            })
            .addOnFailureListener(e -> speakHere(msg));
    }

    private void speakHere(String msg) {
        h.post(() -> {
            if (!ready || tts == null) return;
            if (speaking == 0) requestFocus();
            speaking++;
            tts.speak(msg, TextToSpeech.QUEUE_ADD, null, "hf" + System.nanoTime());
        });
    }

    private void requestFocus() {
        try {
            focusReq = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                .setAudioAttributes(attrs()).setOnAudioFocusChangeListener(fc -> {}).build();
            am.requestAudioFocus(focusReq);
        } catch (Exception ignored) {}
    }
    private void releaseFocus() { try { if (focusReq != null) am.abandonAudioFocusRequest(focusReq); } catch (Exception ignored) {} }

    void shutdown() {
        try { if (tts != null) tts.shutdown(); } catch (Exception ignored) {}
        tts = null; ready = false; speaking = 0; releaseFocus();
    }
}
