package it.healthfit.app;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.SystemClock;

import androidx.annotation.NonNull;
import androidx.health.services.client.HealthServices;
import androidx.health.services.client.PassiveListenerService;
import androidx.health.services.client.PassiveMonitoringClient;
import androidx.health.services.client.data.DataPointContainer;
import androidx.health.services.client.data.DataType;
import androidx.health.services.client.data.IntervalDataPoint;
import androidx.health.services.client.data.PassiveListenerConfig;
import androidx.health.services.client.data.SampleDataPoint;
import androidx.health.services.client.data.UserActivityInfo;

import com.google.common.util.concurrent.FutureCallback;
import com.google.common.util.concurrent.Futures;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.TimeZone;

/**
 * Misure di tutto il giorno fatte da HealthFit (senza Samsung Health): battito, passi, calorie e sonno,
 * con il monitoraggio passivo di Wear OS (a basso consumo). Ogni ora manda gli ultimi 2 giorni al telefono.
 * Dati per giorno, a fasce di 5 minuti (288 al giorno): h = battito medio, s = passi; più totali e sonno.
 */
public final class Passive {
    private Passive() {}
    static final String P = "hf_passive";
    static final TimeZone ROME = TimeZone.getTimeZone("Europe/Rome");

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences(P, Context.MODE_PRIVATE); }
    static boolean on(Context c) { return prefs(c).getBoolean("on", false); }

    static boolean permsOk(Context c) {
        if (c.checkSelfPermission(Manifest.permission.BODY_SENSORS) != PackageManager.PERMISSION_GRANTED) return false;
        if (c.checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) != PackageManager.PERMISSION_GRANTED) return false;
        return true;
    }
    static boolean bgOk(Context c) {
        return Build.VERSION.SDK_INT < 33 || c.checkSelfPermission("android.permission.BODY_SENSORS_BACKGROUND") == PackageManager.PERMISSION_GRANTED;
    }

    /** Accende o spegne le misure di tutto il giorno. */
    static void set(Context c, boolean on, Runnable done) {
        prefs(c).edit().putBoolean("on", on).apply();
        PassiveMonitoringClient pc = HealthServices.getClient(c).getPassiveMonitoringClient();
        if (!on) { try { pc.clearPassiveListenerServiceAsync(); } catch (Exception ignored) {} if (done != null) done.run(); return; }
        if (!permsOk(c)) { prefs(c).edit().putString("err", "Mancano i permessi: apri HealthFit sull'orologio").apply(); if (done != null) done.run(); return; }
        Set<DataType<?, ?>> types = new HashSet<>();
        types.add(DataType.HEART_RATE_BPM); types.add(DataType.STEPS_DAILY); types.add(DataType.CALORIES_DAILY);
        PassiveListenerConfig cfg = new PassiveListenerConfig.Builder().setDataTypes(types).setShouldUserActivityInfoBeRequested(true).build();
        Futures.addCallback(pc.setPassiveListenerServiceAsync(Svc.class, cfg), new FutureCallback<Void>() {
            @Override public void onSuccess(Void v) { prefs(c).edit().putString("err", "").putLong("regAt", System.currentTimeMillis()).apply(); if (done != null) done.run(); }
            @Override public void onFailure(@NonNull Throwable t) { prefs(c).edit().putString("err", "Non riesco ad attivare: " + t.getMessage()).apply(); if (done != null) done.run(); }
        }, c.getMainExecutor());
    }

    static String day(long ms) { SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd", Locale.ITALY); f.setTimeZone(ROME); return f.format(new Date(ms)); }
    static int slot(long ms) { Calendar k = Calendar.getInstance(ROME); k.setTimeInMillis(ms); return (k.get(Calendar.HOUR_OF_DAY) * 60 + k.get(Calendar.MINUTE)) / 5; }

    /** Stato salvato: {"days":{iso:{"h":[288 somme],"n":[288 conteggi],"s":[288 passi],"st":tot,"kc":tot,"stLast":v}},"sleep":[[inizio,fine]...],"asleepAt":ms} */
    static JSONObject load(Context c) { try { return new JSONObject(prefs(c).getString("data", "{}")); } catch (Exception e) { return new JSONObject(); } }
    static JSONObject dayObj(JSONObject root, String d) throws Exception {
        JSONObject days = root.optJSONObject("days"); if (days == null) { days = new JSONObject(); root.put("days", days); }
        JSONObject o = days.optJSONObject(d);
        if (o == null) {
            o = new JSONObject(); JSONArray h = new JSONArray(), n = new JSONArray(), s = new JSONArray();
            for (int i = 0; i < 288; i++) { h.put(0); n.put(0); s.put(0); }
            o.put("h", h); o.put("n", n); o.put("s", s); days.put(d, o);
            // tieni solo gli ultimi 3 giorni
            while (days.length() > 3) { String min = null; for (Iterator<String> it = days.keys(); it.hasNext(); ) { String k = it.next(); if (min == null || k.compareTo(min) < 0) min = k; } days.remove(min); }
        }
        return o;
    }

    static synchronized void onData(Context c, DataPointContainer dp) {
        try {
            JSONObject root = load(c); long now = System.currentTimeMillis();
            Instant boot = Instant.ofEpochMilli(now - SystemClock.elapsedRealtime());
            List<SampleDataPoint<Double>> hr = dp.getData(DataType.HEART_RATE_BPM);
            if (!hr.isEmpty()) prefs(c).edit().putLong("lastHr", now).apply();
            for (SampleDataPoint<Double> p : hr) {
                double b = p.getValue(); if (!(b > 25 && b < 230)) continue;
                long t = p.getTimeInstant(boot).toEpochMilli();
                JSONObject o = dayObj(root, day(t)); int sl = slot(t);
                o.getJSONArray("h").put(sl, o.getJSONArray("h").getDouble(sl) + b); o.getJSONArray("n").put(sl, o.getJSONArray("n").getInt(sl) + 1);
            }
            List<IntervalDataPoint<Long>> st = dp.getData(DataType.STEPS_DAILY);
            if (!st.isEmpty()) {
                long v = st.get(st.size() - 1).getValue();
                JSONObject o = dayObj(root, day(now)); long last = o.optLong("stLast", -1);
                long delta = last < 0 ? 0 : (v >= last ? v - last : 0);
                int sl = slot(now); o.getJSONArray("s").put(sl, o.getJSONArray("s").getLong(sl) + delta);
                o.put("stLast", v); o.put("st", Math.max(o.optLong("st", 0), v));
            }
            List<IntervalDataPoint<Double>> kc = dp.getData(DataType.CALORIES_DAILY);
            if (!kc.isEmpty()) { JSONObject o = dayObj(root, day(now)); o.put("kc", Math.round(kc.get(kc.size() - 1).getValue())); }
            save(c, root);
        } catch (Exception ignored) {}
        maybeSend(c, false);
    }

    static synchronized void onActivity(Context c, UserActivityInfo info) {
        try {
            JSONObject root = load(c);
            boolean asleep = String.valueOf(info.getUserActivityState()).toUpperCase(Locale.ROOT).contains("ASLEEP");
            long t = info.getStateChangeTime().toEpochMilli();
            long since = root.optLong("asleepAt", 0);
            if (asleep && since == 0) root.put("asleepAt", t);
            else if (!asleep && since > 0) {
                if (t - since >= 20 * 60 * 1000L) { JSONArray sl = root.optJSONArray("sleep"); if (sl == null) sl = new JSONArray(); JSONArray seg = new JSONArray(); seg.put(since); seg.put(t); sl.put(seg); while (sl.length() > 12) sl.remove(0); root.put("sleep", sl); }
                root.put("asleepAt", 0);
            }
            save(c, root);
        } catch (Exception ignored) {}
        maybeSend(c, true);
    }

    static void save(Context c, JSONObject root) { prefs(c).edit().putString("data", root.toString()).putLong("lastData", System.currentTimeMillis()).apply(); }

    /** Al telefono al massimo una volta all'ora (o subito al risveglio, o quando lo chiede il telefono): tipo "passive".
     *  Va sia come messaggio (immediato) sia come dato sincronizzato (arriva anche se il telefono ora non è raggiungibile).
     *  L'ora dell'invio si segna solo se il telefono l'ha ricevuto, così se fallisce si riprova al dato successivo. */
    static void maybeSend(Context c, boolean force) {
        SharedPreferences p = prefs(c); long now = System.currentTimeMillis();
        if (!force && now - p.getLong("sentAt", 0) < 60 * 60 * 1000L) return;
        if (!force && now - p.getLong("tryAt", 0) < 10 * 60 * 1000L) return;
        p.edit().putLong("tryAt", now).apply();
        try {
            JSONObject root = load(c), out = new JSONObject(); out.put("kind", "passive"); out.put("at", now); out.put("v", 2);
            JSONObject days = root.optJSONObject("days"), od = new JSONObject();
            if (days != null) for (Iterator<String> it = days.keys(); it.hasNext(); ) {
                String d = it.next(); JSONObject o = days.getJSONObject(d), r = new JSONObject();
                JSONArray h = o.getJSONArray("h"), n = o.getJSONArray("n"), s = o.getJSONArray("s"), hh = new JSONArray(), ss = new JSONArray();
                for (int i = 0; i < 288; i++) { int k = n.getInt(i); hh.put(k > 0 ? (int) Math.round(h.getDouble(i) / k) : 0); ss.put(s.getLong(i)); }
                r.put("hr", hh); r.put("st", ss); r.put("steps", o.optLong("st", 0)); r.put("kcal", o.optLong("kc", 0)); od.put(d, r);
            }
            out.put("days", od); out.put("sleep", root.optJSONArray("sleep") == null ? new JSONArray() : root.optJSONArray("sleep"));
            out.put("asleepAt", root.optLong("asleepAt", 0));
            out.put("st", status(c));
            final byte[] data = out.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8);
            final Context ac = c.getApplicationContext();
            // 1) dato sincronizzato: Wear OS lo consegna al telefono appena si collega (anche dopo ore)
            try {
                com.google.android.gms.wearable.PutDataRequest req = com.google.android.gms.wearable.PutDataRequest.create("/healthfit/passive");
                req.setData(data); req.setUrgent();
                com.google.android.gms.wearable.Wearable.getDataClient(ac).putDataItem(req)
                    .addOnFailureListener(e -> prefs(ac).edit().putString("sendErr", "dato: " + e.getMessage()).apply());
            } catch (Exception e) { p.edit().putString("sendErr", "dato: " + e.getMessage()).apply(); }
            // 2) messaggio subito, se il telefono è collegato
            com.google.android.gms.wearable.Wearable.getNodeClient(ac).getConnectedNodes().addOnSuccessListener(nodes -> {
                if (nodes.isEmpty()) { prefs(ac).edit().putString("sendErr", "telefono non collegato").apply(); return; }
                for (com.google.android.gms.wearable.Node n : nodes) com.google.android.gms.wearable.Wearable.getMessageClient(ac).sendMessage(n.getId(), "/healthfit/result", data)
                    .addOnSuccessListener(x -> prefs(ac).edit().putLong("sentAt", System.currentTimeMillis()).putString("sendErr", "").apply())
                    .addOnFailureListener(e -> prefs(ac).edit().putString("sendErr", "invio: " + e.getMessage()).apply());
            }).addOnFailureListener(e -> prefs(ac).edit().putString("sendErr", "telefono: " + e.getMessage()).apply());
        } catch (Exception e) { p.edit().putString("sendErr", "preparazione: " + e.getMessage()).apply(); }
    }

    /** Stato delle misure, per capire dal telefono dove si ferma (permessi, sensore, invio). */
    static JSONObject status(Context c) {
        JSONObject s = new JSONObject(); SharedPreferences p = prefs(c);
        try {
            s.put("on", on(c)); s.put("perms", permsOk(c)); s.put("bg", bgOk(c));
            s.put("lastData", p.getLong("lastData", 0)); s.put("lastHr", p.getLong("lastHr", 0)); s.put("regAt", p.getLong("regAt", 0));
            s.put("sentAt", p.getLong("sentAt", 0)); s.put("err", p.getString("err", "")); s.put("sendErr", p.getString("sendErr", ""));
            s.put("ver", Updater.current(c));
        } catch (Exception ignored) {}
        return s;
    }

    /** Se le misure sono accese, le registra di nuovo (Wear OS a volte le perde dopo un aggiornamento o un riavvio). */
    static void reRegister(Context c) { if (on(c)) set(c, true, null); }

    /** Dopo un riavvio dell'orologio o un aggiornamento dell'app riattiva le misure. */
    public static class Boot extends android.content.BroadcastReceiver {
        @Override public void onReceive(Context c, android.content.Intent i) { reRegister(c.getApplicationContext()); }
    }

    /** Servizio chiamato da Wear OS con i nuovi dati, anche con l'app chiusa. */
    public static class Svc extends PassiveListenerService {
        @Override public void onNewDataPointsReceived(@NonNull DataPointContainer dataPoints) { onData(getApplicationContext(), dataPoints); }
        @Override public void onUserActivityInfoReceived(@NonNull UserActivityInfo info) { onActivity(getApplicationContext(), info); }
    }
}
