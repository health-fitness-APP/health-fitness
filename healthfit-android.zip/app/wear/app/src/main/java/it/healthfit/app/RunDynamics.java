package it.healthfit.app;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Handler;
import android.os.HandlerThread;

import org.json.JSONObject;

/** Legge accelerometro e gravità dell'orologio (50 al secondo, su un thread a parte) e li passa a StepAnalyzer. */
final class RunDynamics implements SensorEventListener {
    private final SensorManager sm;
    private HandlerThread th;
    private final StepAnalyzer an = new StepAnalyzer();
    private volatile boolean active;

    RunDynamics(Context c) { sm = (SensorManager) c.getSystemService(Context.SENSOR_SERVICE); }

    void start() {
        try {
            Sensor acc = sm != null ? sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) : null; if (acc == null) return;
            th = new HandlerThread("hf-dyn"); th.start(); Handler h = new Handler(th.getLooper());
            Sensor gr = sm.getDefaultSensor(Sensor.TYPE_GRAVITY);
            if (gr != null) sm.registerListener(this, gr, 20000, h);
            sm.registerListener(this, acc, 20000, h);
            active = true;
        } catch (Exception ignored) {}
    }
    long lastMove() { return an.lastMove; }
    long moveStart() { return an.moveStart; }
    void setActive(boolean a) { if (!a) an.breakChain(); active = a; }
    void stop() { active = false; try { if (sm != null) sm.unregisterListener(this); } catch (Exception ignored) {} if (th != null) { th.quitSafely(); th = null; } }

    @Override public void onSensorChanged(SensorEvent e) {
        if (!active) return;
        if (e.sensor.getType() == Sensor.TYPE_GRAVITY) an.gravity(e.values[0], e.values[1], e.values[2]);
        else an.add(e.timestamp, e.values[0], e.values[1], e.values[2]);
    }
    @Override public void onAccuracyChanged(Sensor s, int a) {}

    /** Per il riepilogo: {n, step, gct, ft (ms), asym, cv (%)}; null se i passi di corsa sono troppo pochi. */
    JSONObject summary() {
        double[] r = an.result(); if (r == null) return null;
        try {
            JSONObject o = new JSONObject();
            o.put("n", (int) r[0]); o.put("step", Math.round(r[1] * 1000)); o.put("gct", Math.round(r[2] * 1000)); o.put("ft", Math.round(r[3] * 1000));
            if (r[4] >= 0) o.put("asym", Math.round(r[4] * 10) / 10.0);
            if (r[5] >= 0) o.put("cv", Math.round(r[5] * 10) / 10.0);
            return o;
        } catch (Exception e) { return null; }
    }
}
