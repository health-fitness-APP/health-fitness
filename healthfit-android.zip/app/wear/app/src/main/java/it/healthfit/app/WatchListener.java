package it.healthfit.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.VibrationEffect;
import android.os.Vibrator;

import androidx.core.app.NotificationCompat;

import com.google.android.gms.tasks.Tasks;
import com.google.android.gms.wearable.ChannelClient;
import com.google.android.gms.wearable.MessageEvent;
import com.google.android.gms.wearable.Wearable;
import com.google.android.gms.wearable.WearableListenerService;

import org.json.JSONObject;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;

/** Riceve dal telefono la corsa da fare e apre da solo l'app sull'orologio. */
public class WatchListener extends WearableListenerService {
    static final String CHANNEL = "hf_watch_open";
    static final int NOTIF = 5152;

    /** "Aggiorna orologio" dal telefono: l'APK arriva su un canale e lo installo (poi basta toccare Installa). */
    @Override public void onChannelOpened(ChannelClient.Channel ch) {
        if (!"/healthfit/apk".equals(ch.getPath())) return;
        ChannelClient cc = Wearable.getChannelClient(this);
        try (InputStream in = Tasks.await(cc.getInputStream(ch))) { Updater.installFrom(getApplicationContext(), in); }
        catch (Exception e) { getSharedPreferences("hf", MODE_PRIVATE).edit().putString("updErr", "Aggiornamento dal telefono non riuscito: " + e.getMessage()).apply(); RunService.notifyUi(); }
        finally { try { cc.close(ch); } catch (Exception ignored) {} }
    }

    @Override public void onMessageReceived(MessageEvent ev) {
        if (!"/healthfit/run".equals(ev.getPath())) return;
        String json = new String(ev.getData(), StandardCharsets.UTF_8);
        SharedPreferences.Editor e = getSharedPreferences("hf", MODE_PRIVATE).edit().putString("plan", json);
        try {   // la fascia salvata sul telefono resta valida anche per le corse avviate dall'orologio
            JSONObject o = new JSONObject(json);
            if (o.has("hrAddr")) e.putString("hrAddr", o.optString("hrAddr", "")).putString("hrName", o.optString("hrName", ""));
        } catch (Exception ignored) {}
        e.apply();
        RunService.notifyUi();
        if (RunService.S.running) return;

        Intent i = new Intent(this, WatchActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        i.putExtra("fromPhone", true);
        try { startActivity(i); } catch (Exception ignored) {}
        // se l'orologio non lascia aprire l'app da sola, la apre la notifica a schermo intero (o basta toccarla)
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Corsa dal telefono", NotificationManager.IMPORTANCE_HIGH));
            PendingIntent pi = PendingIntent.getActivity(this, 1, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            String title = "Corsa";
            try { title = new JSONObject(json).optString("title", "Corsa"); } catch (Exception ignored) {}
            Notification n = new NotificationCompat.Builder(this, CHANNEL).setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .setContentTitle("HealthFit · " + title).setContentText("Tocca per aprire e poi AVVIA")
                .setPriority(NotificationCompat.PRIORITY_HIGH).setCategory(NotificationCompat.CATEGORY_ALARM)
                .setContentIntent(pi).setFullScreenIntent(pi, true).setAutoCancel(true).setTimeoutAfter(10 * 60 * 1000L).build();
            nm.notify(NOTIF, n);
        } catch (Exception ignored) {}
        try { Vibrator vb = (Vibrator) getSystemService(VIBRATOR_SERVICE); if (vb != null) vb.vibrate(VibrationEffect.createOneShot(250, VibrationEffect.DEFAULT_AMPLITUDE)); } catch (Exception ignored) {}
    }
}
