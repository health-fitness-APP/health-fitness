package it.healthfit.app;

import android.content.Intent;

import com.google.android.gms.wearable.MessageEvent;
import com.google.android.gms.wearable.WearableListenerService;

import java.nio.charset.StandardCharsets;

/** Riceve dal telefono la corsa da fare e apre l'app sull'orologio. */
public class WatchListener extends WearableListenerService {
    @Override public void onMessageReceived(MessageEvent ev) {
        if ("/healthfit/run".equals(ev.getPath())) {
            String json = new String(ev.getData(), StandardCharsets.UTF_8);
            getSharedPreferences("hf", MODE_PRIVATE).edit().putString("plan", json).apply();
            Intent i = new Intent(this, WatchActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            i.putExtra("fromPhone", true);
            try { startActivity(i); } catch (Exception ignored) { /* si apre quando l'utente tocca l'app */ }
        }
    }
}
