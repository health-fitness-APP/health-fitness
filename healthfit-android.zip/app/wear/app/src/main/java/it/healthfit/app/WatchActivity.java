package it.healthfit.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Schermata sull'orologio: corsa del giorno inviata dal telefono, battito, zona, tempo, km e ritmo. */
public class WatchActivity extends Activity {
    private TextView title, plan, bpm, zone, stats, err;
    private Button start, pause, stop;
    private final Handler h = new Handler(Looper.getMainLooper());
    private static final int[] ZCOL = {0xFF9AA5B1, 0xFF2F7FD8, 0xFF2E8B5F, 0xFFE9A21E, 0xFFE5484D};
    private static final String[] ZLAB = {"Z1 recupero", "Z2 facile", "Z3 medio", "Z4 soglia", "Z5 massimale"};

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView sv = new ScrollView(this);
        LinearLayout col = new LinearLayout(this); col.setOrientation(LinearLayout.VERTICAL); col.setGravity(Gravity.CENTER_HORIZONTAL);
        int pad = dp(22); col.setPadding(pad, dp(26), pad, dp(40));
        title = text(15, true, Color.WHITE); plan = text(11, false, 0xFFB8C2CC);
        bpm = text(44, true, Color.WHITE); zone = text(13, true, Color.WHITE); stats = text(13, false, Color.WHITE); err = text(11, false, 0xFFFF8A80);
        start = button("AVVIA", 0xFF2E8B5F); pause = button("PAUSA", 0xFF5A6570); stop = button("FINE", 0xFFE5484D);
        col.addView(title); col.addView(plan); col.addView(bpm); col.addView(zone); col.addView(stats); col.addView(err);
        col.addView(start); col.addView(pause); col.addView(stop);
        sv.addView(col); setContentView(sv);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        start.setOnClickListener(v -> { if (askPerms()) send(RunService.ACTION_START); });
        pause.setOnClickListener(v -> send(RunService.S.paused ? RunService.ACTION_RESUME : RunService.ACTION_PAUSE));
        stop.setOnClickListener(v -> send(RunService.ACTION_STOP));
        askPerms();
    }

    private int dp(int v) { return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics()); }
    private TextView text(int sp, boolean bold, int color) {
        TextView t = new TextView(this); t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp); t.setTextColor(color); t.setGravity(Gravity.CENTER);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD); t.setPadding(0, dp(2), 0, dp(2)); return t;
    }
    private Button button(String label, int color) {
        Button bt = new Button(this); bt.setText(label); bt.setTextColor(Color.WHITE); bt.setAllCaps(false); bt.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        GradientDrawable g = new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(24)); bt.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(44)); lp.topMargin = dp(8); bt.setLayoutParams(lp); return bt;
    }
    private void send(String action) { Intent i = new Intent(this, RunService.class); i.setAction(action);
        if (RunService.ACTION_START.equals(action)) startForegroundService(i); else startService(i); refresh(); }

    private boolean askPerms() {
        List<String> need = new ArrayList<>();
        String[] all = Build.VERSION.SDK_INT >= 33
            ? new String[]{Manifest.permission.BODY_SENSORS, Manifest.permission.ACTIVITY_RECOGNITION, Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.POST_NOTIFICATIONS}
            : new String[]{Manifest.permission.BODY_SENSORS, Manifest.permission.ACTIVITY_RECOGNITION, Manifest.permission.ACCESS_FINE_LOCATION};
        for (String p : all) if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) need.add(p);
        if (need.isEmpty()) return true;
        requestPermissions(need.toArray(new String[0]), 7); return false;
    }

    @Override protected void onResume() {
        super.onResume();
        RunService.listener = () -> h.post(this::refresh);
        String unsent = getSharedPreferences("hf", MODE_PRIVATE).getString("unsent", null);
        if (unsent != null) RunService.sendToPhone(this, unsent);
        refresh();
    }
    @Override protected void onPause() { RunService.listener = null; super.onPause(); }

    private void refresh() {
        RunService.State s = RunService.S;
        SharedPreferences p = getSharedPreferences("hf", MODE_PRIVATE);
        String t = "Corsa libera", pl = "Avvia dal telefono per ricevere la corsa del piano";
        try { JSONObject o = new JSONObject(p.getString("plan", "{}"));
            if (o.has("title")) { t = o.optString("title");
                StringBuilder sb = new StringBuilder();
                if (o.optInt("lo", -1) >= 0) sb.append("🎯 ").append(o.optInt("lo") == o.optInt("hi") ? "Z" + (o.optInt("lo") + 1) : "Z" + (o.optInt("lo") + 1) + "–Z" + (o.optInt("hi") + 1));
                if (o.optDouble("km", 0) > 0) sb.append(sb.length() > 0 ? " · " : "").append(String.format(Locale.ITALY, "%.1f km", o.optDouble("km")));
                if (!o.optString("pace").isEmpty()) sb.append(" · ").append(o.optString("pace")).append("/km");
                if (!o.optString("desc").isEmpty()) sb.append("\n").append(o.optString("desc"));
                pl = sb.toString(); } } catch (Exception ignored) {}
        title.setText(s.running ? s.title : t); plan.setText(pl);
        boolean fresh = System.currentTimeMillis() - s.lastBeat < 5000 && s.bpm > 0;
        bpm.setText(fresh ? String.valueOf(s.bpm) : "--");
        if (fresh) { int z = zoneOf(s.bpm, s.hrMax); zone.setText(ZLAB[z]); zone.setTextColor(ZCOL[z]); } else { zone.setText(s.running ? "battito…" : ""); zone.setTextColor(Color.WHITE); }
        long m = s.activeSec / 60, sec = s.activeSec % 60;
        String pace = s.km > 0.2 ? fmtPace(s.activeSec / s.km) : "–";
        stats.setText(s.running || s.finished ? String.format(Locale.ITALY, "%d:%02d · %.2f km · %s/km", m, sec, s.km, pace) : "");
        err.setText(s.error); err.setVisibility(s.error.isEmpty() ? View.GONE : View.VISIBLE);
        start.setVisibility(s.running ? View.GONE : View.VISIBLE); start.setText(s.finished ? "NUOVA CORSA" : "AVVIA");
        pause.setVisibility(s.running ? View.VISIBLE : View.GONE); pause.setText(s.paused ? "RIPRENDI" : "PAUSA");
        stop.setVisibility(s.running ? View.VISIBLE : View.GONE);
        if (s.finished && !s.running) plan.setText("Corsa salvata: il riepilogo è stato mandato al telefono ✓");
    }
    private static int zoneOf(int b, int mx) { double pc = b / (double) mx; return pc < 0.6 ? 0 : pc < 0.7 ? 1 : pc < 0.8 ? 2 : pc < 0.9 ? 3 : 4; }
    private static String fmtPace(double secPerKm) { long p = Math.round(secPerKm); return (p / 60) + ":" + String.format(Locale.ITALY, "%02d", p % 60); }
}
