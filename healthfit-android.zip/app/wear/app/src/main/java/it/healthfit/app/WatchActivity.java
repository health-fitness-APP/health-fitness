package it.healthfit.app;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Schermata sull'orologio, come l'allenamento di Samsung Health: orario, tempo, distanza, ritmo attuale e medio,
 * battito (dalla fascia o dal polso) con la zona, calorie. Prima dell'avvio mostra la corsa inviata dal telefono.
 */
public class WatchActivity extends Activity {
    private TextView clock, title, plan, time, dist, paceNow, paceAvg, bpm, zone, kcal, strap, err, segLine, segInfo, timeLab, avgLab;
    private LinearLayout secs;
    private LinearLayout live;
    private Button start, pause, stop, upd;
    private TextView updMsg;
    private final Handler h = new Handler(Looper.getMainLooper());
    private boolean pendingStart = false;
    private final SimpleDateFormat hhmm = new SimpleDateFormat("HH:mm", Locale.ITALY);
    private static final int[] ZCOL = {0xFF9AA5B1, 0xFF2F7FD8, 0xFF2E8B5F, 0xFFE9A21E, 0xFFE5484D};
    private static final String[] ZLAB = {"Z1 recupero", "Z2 facile", "Z3 medio", "Z4 soglia", "Z5 massimale"};
    private static final int GREY = 0xFFB8C2CC;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView sv = new ScrollView(this);
        LinearLayout col = new LinearLayout(this); col.setOrientation(LinearLayout.VERTICAL); col.setGravity(Gravity.CENTER_HORIZONTAL);
        int pad = dp(20); col.setPadding(pad, dp(10), pad, dp(40));
        clock = text(13, true, GREY);
        title = text(15, true, Color.WHITE); plan = text(11, false, GREY);

        // dati della corsa in corso
        live = new LinearLayout(this); live.setOrientation(LinearLayout.VERTICAL); live.setGravity(Gravity.CENTER_HORIZONTAL);
        // tutto il necessario nella prima schermata, senza scorrere: tempo, km e battito, ritmi, fase
        time = text(28, true, Color.WHITE);
        dist = text(24, true, Color.WHITE); bpm = text(24, true, Color.WHITE);
        zone = text(10, true, Color.WHITE); zone.setPadding(0, 0, 0, dp(3));
        LinearLayout top = new LinearLayout(this); top.setOrientation(LinearLayout.HORIZONTAL);
        top.addView(cell(dist, label("km"))); top.addView(cell(bpm, zone));
        LinearLayout paces = new LinearLayout(this); paces.setOrientation(LinearLayout.HORIZONTAL);
        paceNow = text(17, true, Color.WHITE); paceAvg = text(17, true, Color.WHITE);
        paces.addView(cell(paceNow, label("ritmo attuale"))); timeLab = label("tempo"); avgLab = label("ritmo medio"); paces.addView(cell(paceAvg, avgLab));
        segLine = text(13, true, 0xFFFFD27A); segInfo = text(10, false, GREY);
        kcal = text(11, false, GREY);
        live.addView(segLine); live.addView(segInfo); live.addView(time); live.addView(timeLab); live.addView(top); live.addView(paces); live.addView(kcal);
        // scorrendo: totali e poi ogni fase (riscaldamento, allenamento…)
        secs = new LinearLayout(this); secs.setOrientation(LinearLayout.VERTICAL); secs.setGravity(Gravity.CENTER_HORIZONTAL);
        live.addView(secs);

        strap = text(11, false, GREY); err = text(11, false, 0xFFFF8A80);
        start = button("AVVIA", 0xFF2E8B5F); pause = button("PAUSA", 0xFF5A6570); stop = button("FINE", 0xFFE5484D);
        col.addView(clock); col.addView(title); col.addView(plan); col.addView(live); col.addView(strap); col.addView(err);
        col.addView(start); col.addView(pause); col.addView(stop);
        // aggiornamento dal polso, senza PC
        upd = button("⟳ AGGIORNA APP", 0xFF33404D); updMsg = text(11, false, GREY); updMsg.setText("Versione 1." + Updater.current(this));
        col.addView(upd); col.addView(updMsg);
        upd.setOnClickListener(v -> Updater.run(this, (m, busy) -> { updMsg.setText(m); upd.setEnabled(!busy); }));
        sv.addView(col); setContentView(sv);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        start.setOnClickListener(v -> { if (askPerms()) send(RunService.ACTION_START); else pendingStart = true; });
        pause.setOnClickListener(v -> send(RunService.S.paused ? RunService.ACTION_RESUME : RunService.ACTION_PAUSE));
        stop.setOnClickListener(v -> send(RunService.ACTION_STOP));
        askPerms();
    }

    private int dp(int v) { return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics()); }
    private TextView text(int sp, boolean bold, int color) {
        TextView t = new TextView(this); t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp); t.setTextColor(color); t.setGravity(Gravity.CENTER);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD); t.setPadding(0, dp(1), 0, dp(1)); t.setIncludeFontPadding(false); return t;
    }
    private TextView label(String s) { TextView t = text(10, false, GREY); t.setText(s); t.setPadding(0, 0, 0, dp(4)); return t; }
    private LinearLayout cell(TextView value, TextView lab) {
        LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setGravity(Gravity.CENTER_HORIZONTAL);
        c.addView(value); c.addView(lab);
        c.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)); return c;
    }
    private Button button(String label, int color) {
        Button bt = new Button(this); bt.setText(label); bt.setTextColor(Color.WHITE); bt.setAllCaps(false); bt.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        GradientDrawable g = new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(24)); bt.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(44)); lp.topMargin = dp(8); bt.setLayoutParams(lp); return bt;
    }
    private void send(String action) { Intent i = new Intent(this, RunService.class); i.setAction(action);
        if (RunService.ACTION_START.equals(action)) startForegroundService(i); else startService(i); refresh(); }

    /** Chiede i permessi mancanti. Per partire bastano sensori e posizione: senza Bluetooth il battito arriva dal polso. */
    private boolean askPerms() {
        List<String> all = new ArrayList<>();
        all.add(Manifest.permission.BODY_SENSORS); all.add(Manifest.permission.ACTIVITY_RECOGNITION); all.add(Manifest.permission.ACCESS_FINE_LOCATION);
        if (Build.VERSION.SDK_INT >= 31) { all.add(Manifest.permission.BLUETOOTH_SCAN); all.add(Manifest.permission.BLUETOOTH_CONNECT); }
        if (Build.VERSION.SDK_INT >= 33) all.add(Manifest.permission.POST_NOTIFICATIONS);
        List<String> need = new ArrayList<>();
        for (String p : all) if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) need.add(p);
        if (!need.isEmpty()) requestPermissions(need.toArray(new String[0]), 7);
        return coreGranted() && need.isEmpty();
    }
    private boolean coreGranted() {
        return checkSelfPermission(Manifest.permission.BODY_SENSORS) == PackageManager.PERMISSION_GRANTED
            && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }
    @Override public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (pendingStart && coreGranted() && !RunService.S.running) { pendingStart = false; send(RunService.ACTION_START); }
    }

    /** Tasto dell'orologio (Indietro, o tasti laterali dove ci sono) durante la corsa: pausa e ripresa, come Samsung Health.
     *  Il tasto viene consumato del tutto (pressione e rilascio), così l'app resta aperta: per uscire si usa il tasto Home. */
    private long lastToggle = 0;
    private Object backCb = null;   // OnBackInvokedCallback (Android 13+): senza, il sistema chiude l'app al tasto Indietro
    private static boolean pauseKey(int code) {
        return code == android.view.KeyEvent.KEYCODE_BACK || code == android.view.KeyEvent.KEYCODE_STEM_1 || code == android.view.KeyEvent.KEYCODE_STEM_2
            || code == android.view.KeyEvent.KEYCODE_STEM_3 || code == android.view.KeyEvent.KEYCODE_STEM_PRIMARY;
    }
    private void togglePause() {
        long n = android.os.SystemClock.uptimeMillis(); if (n - lastToggle < 700) return;   // un solo cambio anche se arrivano sia il tasto sia il "back"
        lastToggle = n; RunService.togglePause(this); h.postDelayed(this::refresh, 150);
    }
    @Override public boolean dispatchKeyEvent(android.view.KeyEvent e) {
        if (RunService.S.running && pauseKey(e.getKeyCode())) {
            if (e.getAction() == android.view.KeyEvent.ACTION_DOWN && e.getRepeatCount() == 0) togglePause();
            return true;
        }
        return super.dispatchKeyEvent(e);
    }
    @SuppressWarnings("deprecation")
    @Override public void onBackPressed() { if (RunService.S.running) { togglePause(); return; } super.onBackPressed(); }
    /** Durante la corsa il "back" del sistema (Android 13+) mette in pausa invece di chiudere l'app. */
    private void syncBack() {
        if (Build.VERSION.SDK_INT < 33) return;
        try {
            boolean want = RunService.S.running;
            if (want && backCb == null) {
                android.window.OnBackInvokedCallback cb = this::togglePause; backCb = cb;
                getOnBackInvokedDispatcher().registerOnBackInvokedCallback(android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT, cb);
            } else if (!want && backCb != null) {
                getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback((android.window.OnBackInvokedCallback) backCb); backCb = null;
            }
        } catch (Exception ignored) {}
    }

    @Override protected void onNewIntent(Intent i) { super.onNewIntent(i); setIntent(i); refresh(); }

    @Override protected void onResume() {
        super.onResume();
        try { ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).cancel(WatchListener.NOTIF); } catch (Exception ignored) {}
        RunService.listener = () -> h.post(this::refresh);
        String unsent = getSharedPreferences("hf", MODE_PRIVATE).getString("unsent", null);
        if (unsent != null) RunService.sendToPhone(this, unsent);
        refresh();
        h.removeCallbacks(clockTick); h.post(clockTick);
    }
    @Override protected void onPause() { RunService.listener = null; h.removeCallbacks(clockTick); super.onPause(); }

    // l'orario si aggiorna anche quando la corsa non è partita
    private final Runnable clockTick = new Runnable() { @Override public void run() {
        clock.setText(hhmm.format(new Date())); if (!RunService.S.running && !RunService.S.recovering) refresh(); h.postDelayed(this, 15000); } };

    private void refresh() {
        RunService.State s = RunService.S;
        syncBack();
        SharedPreferences p = getSharedPreferences("hf", MODE_PRIVATE);
        clock.setText(hhmm.format(new Date()));
        String t = "Corsa libera", pl = "Avvia dal telefono per ricevere la corsa del piano";
        try { JSONObject o = new JSONObject(p.getString("plan", "{}"));
            if (o.has("title")) { t = o.optString("runType", "").isEmpty() ? o.optString("title") : o.optString("runType");
                StringBuilder sb = new StringBuilder();
                if (o.optInt("lo", -1) >= 0) sb.append("🎯 ").append(o.optInt("lo") == o.optInt("hi") ? "Z" + (o.optInt("lo") + 1) : "Z" + (o.optInt("lo") + 1) + "–Z" + (o.optInt("hi") + 1));
                if (o.optDouble("km", 0) > 0) sb.append(sb.length() > 0 ? " · " : "").append(String.format(Locale.ITALY, "%.1f km", o.optDouble("km")));
                if (!o.optString("pace").isEmpty()) sb.append(" · ").append(o.optString("pace")).append("/km");
                if (!o.optString("desc").isEmpty()) sb.append("\n").append(o.optString("desc"));
                pl = sb.toString(); } } catch (Exception ignored) {}
        boolean show = s.running || s.finished || s.recovering;
        title.setText(show ? (s.runType.isEmpty() ? s.title : s.runType) : t);
        title.setVisibility(s.running ? View.GONE : View.VISIBLE);   // in corsa lascio lo spazio ai numeri
        plan.setText(s.recovering ? "Recupero del battito: resta fermo o cammina piano… ancora " + s.recLeft + " s"
            : s.finished && !s.running ? "Corsa salvata: il riepilogo è stato mandato al telefono ✓" : pl);
        plan.setVisibility(s.running ? View.GONE : View.VISIBLE);
        live.setVisibility(show ? View.VISIBLE : View.GONE);

        boolean ph = s.phSec.length > 0 && s.phIdx < s.phSec.length;
        long tSec = ph && s.running ? s.phSec[s.phIdx] : s.activeSec; double tKm = ph && s.running ? s.phKm[s.phIdx] : s.km;
        time.setText((s.paused ? "⏸ " : "") + hms(tSec));
        timeLab.setText(s.paused ? "IN PAUSA · premi il tasto per ripartire" : ph && s.running ? "tempo della fase" : "tempo");
        timeLab.setTextColor(s.paused ? 0xFFFFD27A : GREY);
        dist.setText(String.format(Locale.ITALY, "%.2f", tKm));
        paceNow.setText(s.running && !s.paused && s.paceNow > 0 ? fmtPace(s.paceNow) : "–");
        paceAvg.setText(tKm > 0.2 ? fmtPace(tSec / tKm) : "–"); avgLab.setText(ph && s.running ? "ritmo fase" : "ritmo medio");
        buildSecs(s, ph);
        boolean fresh = (s.running || s.recovering) && System.currentTimeMillis() - s.lastBeat < 5000 && s.bpm > 0;
        bpm.setText("♥ " + (fresh ? String.valueOf(s.bpm) : "--"));
        if (fresh) { int z = zoneOf(s.bpm, s.hrMax); bpm.setTextColor(ZCOL[z]); zone.setText(ZLAB[z].substring(0, 2) + (s.hrHiB > 0 || s.hrLoB > 0 ? " · 🎯" + (s.hrLoB > 0 ? s.hrLoB : "") + (s.hrLoB > 0 && s.hrHiB > 0 ? "–" : s.hrHiB > 0 ? "≤" : "+") + (s.hrHiB > 0 ? s.hrHiB : "") : " · " + ("fascia".equals(s.hrSrc) ? "fascia" : "polso"))); zone.setTextColor(ZCOL[z]); }
        else if (s.finished && !s.running && s.samples > 0) { bpm.setText("♥ " + Math.round((double) s.sumHr / s.samples)); bpm.setTextColor(Color.WHITE); zone.setText("media · max " + s.maxHr); zone.setTextColor(GREY); }
        else { bpm.setTextColor(Color.WHITE); zone.setText(s.running ? "battito…" : "battiti"); zone.setTextColor(GREY); }
        segLine.setText(s.running ? s.seg : ""); segLine.setVisibility(s.running && !s.seg.isEmpty() ? View.VISIBLE : View.GONE);
        segInfo.setText(s.running ? s.segInfo : ""); segInfo.setVisibility(s.running && !s.segInfo.isEmpty() ? View.VISIBLE : View.GONE);
        kcal.setText(s.kcal > 0 ? Math.round(s.kcal) + " kcal" : "");

        String st;
        if (s.recovering) st = "";
        else if (s.running) st = "🫀 " + (s.strap.isEmpty() ? "battito dal polso" : s.strap);
        else { String nm = p.getString("hrName", ""), ad = p.getString("hrAddr", "");
            st = !ad.isEmpty() ? "🫀 " + (nm.isEmpty() ? "Fascia" : nm) + ": la collego all'avvio" : "🫀 Se indossi la fascia la cerco all'avvio"; }
        strap.setText(s.finished && !s.running ? "" : st);
        err.setText(s.error); err.setVisibility(s.error.isEmpty() ? View.GONE : View.VISIBLE);
        upd.setVisibility(s.running || s.recovering ? View.GONE : View.VISIBLE); updMsg.setVisibility(upd.getVisibility());
        String ue = p.getString("updErr", ""); if (!ue.isEmpty()) { updMsg.setText(ue); p.edit().remove("updErr").apply(); }
        start.setVisibility(s.running || s.recovering ? View.GONE : View.VISIBLE); start.setText(s.finished ? "NUOVA CORSA" : "AVVIA");
        pause.setVisibility(s.running ? View.VISIBLE : View.GONE); pause.setText(s.paused ? "RIPRENDI" : "PAUSA");
        stop.setVisibility(s.running || s.recovering ? View.VISIBLE : View.GONE); stop.setText(s.recovering ? "SALTA IL RECUPERO" : "FINE");
    }
    /** Sezioni sotto il quadro: prima i totali, poi ogni fase già iniziata. */
    private void buildSecs(RunService.State s, boolean ph) {
        secs.removeAllViews();
        if (!ph || !(s.running || s.finished || s.recovering)) return;
        addSec("TOTALE", s.activeSec, s.km, s.samples > 0 ? Math.round((double) s.sumHr / s.samples) : 0, 0xFFFFFFFF);
        for (int i = 0; i < s.phSec.length && i <= s.phIdx; i++)
            addSec(s.phName[i].toUpperCase(Locale.ITALY) + (i == s.phIdx && s.running ? " · ora" : ""), s.phSec[i], s.phKm[i], s.phHrN[i] > 0 ? Math.round((double) s.phHrSum[i] / s.phHrN[i]) : 0, i == s.phIdx ? 0xFFFFD27A : GREY);
    }
    private void addSec(String name, long sec, double km, long hr, int color) {
        TextView t = text(11, true, color); t.setText(name); t.setPadding(0, dp(8), 0, 0); secs.addView(t);
        TextView v = text(13, false, Color.WHITE);
        v.setText(hms(sec) + String.format(Locale.ITALY, " · %.2f km", km) + (km > 0.2 ? " · " + fmtPace(sec / km) + "/km" : "") + (hr > 0 ? " · ♥" + hr : ""));
        secs.addView(v);
    }
    private static int zoneOf(int b, int mx) { double pc = b / (double) mx; return pc < 0.6 ? 0 : pc < 0.7 ? 1 : pc < 0.8 ? 2 : pc < 0.9 ? 3 : 4; }
    private static String fmtPace(double secPerKm) { long p = Math.round(secPerKm); if (p >= 60 * 60) return "–"; return (p / 60) + ":" + String.format(Locale.ITALY, "%02d", p % 60); }
    private static String hms(long sec) { long hh = sec / 3600, m = (sec % 3600) / 60, s = sec % 60;
        return hh > 0 ? String.format(Locale.ITALY, "%d:%02d:%02d", hh, m, s) : String.format(Locale.ITALY, "%d:%02d", m, s); }
}
