package it.healthfit.app;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Schermata sull'orologio, come l'allenamento di Samsung Health: orario, tempo, distanza, ritmo attuale e medio,
 * battito (dalla fascia o dal polso) con la zona, calorie. Prima dell'avvio mostra la corsa inviata dal telefono.
 */
public class WatchActivity extends Activity {
    private TextView clock, title, plan, time, dist, paceNow, paceAvg, bpm, zone, kcal, strap, err, segLine;
    private LinearLayout live;
    private Button start, pause, stop;
    private final Handler h = new Handler(Looper.getMainLooper());
    private boolean pendingStart = false;
    private final SimpleDateFormat hhmm = new SimpleDateFormat("HH:mm", Locale.ITALY);
    private static final int[] ZCOL = {0xFF9AA5B1, 0xFF2F7FD8, 0xFF2E8B5F, 0xFFE9A21E, 0xFFE5484D};
    private static final String[] ZLAB = {"Z1 recupero", "Z2 facile", "Z3 medio", "Z4 soglia", "Z5 massimale"};
    private static final int GREY = 0xFFB8C2CC;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView sv = new ScrollView(this);
        LinearLayout col = new LinearLayout(this); col.setOrientation(LinearLayout.VERTICAL); col.setGravity(Gravity.CENTER_HORIZONTAL);
        int pad = dp(20); col.setPadding(pad, dp(10), pad, dp(40));
        clock = text(13, true, GREY);
        title = text(15, true, Color.WHITE); plan = text(11, false, GREY);

        // dati della corsa in corso
        live = new LinearLayout(this); live.setOrientation(LinearLayout.VERTICAL); live.setGravity(Gravity.CENTER_HORIZONTAL);
        // tutto il necessario nella prima schermata, senza scorrere: tempo, km e battito, ritmi, fase
        time = text(28, true, Color.WHITE);
        dist = text(24, true, Color.WHITE); bpm = text(24, true, Color.WHITE);
        zone = text(10, true, Color.WHITE); zone.setPadding(0, 0, 0, dp(3));
        LinearLayout top = new LinearLayout(this); top.setOrientation(LinearLayout.HORIZONTAL);
        top.addView(cell(dist, label("km"))); top.addView(cell(bpm, zone));
        LinearLayout paces = new LinearLayout(this); paces.setOrientation(LinearLayout.HORIZONTAL);
        paceNow = text(17, true, Color.WHITE); paceAvg = text(17, true, Color.WHITE);
        paces.addView(cell(paceNow, label("ritmo attuale"))); paces.addView(cell(paceAvg, label("ritmo medio")));
        segLine = text(11, true, 0xFFFFD27A);
        kcal = text(11, false, GREY);
        live.addView(time); live.addView(top); live.addView(paces); live.addView(segLine); live.addView(kcal);

        strap = text(11, false, GREY); err = text(11, false, 0xFFFF8A80);
        start = button("AVVIA", 0xFF2E8B5F); pause = button("PAUSA", 0xFF5A6570); stop = button("FINE", 0xFFE5484D);
        col.addView(clock); col.addView(title); col.addView(plan); col.addView(live); col.addView(strap); col.addView(err);
        col.addView(start); col.addView(pause); col.addView(stop);
        sv.addView(col); setContentView(sv);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        start.setOnClickListener(v -> { if (askPerms()) send(RunService.ACTION_START); else pendingStart = true; });
        pause.setOnClickListener(v -> send(RunService.S.paused ? RunService.ACTION_RESUME : RunService.ACTION_PAUSE));
        stop.setOnClickListener(v -> send(RunService.ACTION_STOP));
        askPerms();
    }

    private int dp(int v) { return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics()); }
    private TextView text(int sp, boolean bold, int color) {
        TextView t = new TextView(this); t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp); t.setTextColor(color); t.setGravity(Gravity.CENTER);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD); t.setPadding(0, dp(1), 0, dp(1)); t.setIncludeFontPadding(false); return t;
    }
    private TextView label(String s) { TextView t = text(10, false, GREY); t.setText(s); t.setPadding(0, 0, 0, dp(4)); return t; }
    private LinearLayout cell(TextView value, TextView lab) {
        LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setGravity(Gravity.CENTER_HORIZONTAL);
        c.addView(value); c.addView(lab);
        c.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)); return c;
    }
    private Button button(String label, int color) {
        Button bt = new Button(this); bt.setText(label); bt.setTextColor(Color.WHITE); bt.setAllCaps(false); bt.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        GradientDrawable g = new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(24)); bt.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(44)); lp.topMargin = dp(8); bt.setLayoutParams(lp); return bt;
    }
    private void send(String action) { Intent i = new Intent(this, RunService.class); i.setAction(action);
        if (RunService.ACTION_START.equals(action)) startForegroundService(i); else startService(i); refresh(); }

    /** Chiede i permessi mancanti. Per partire bastano sensori e posizione: senza Bluetooth il battito arriva dal polso. */
    private boolean askPerms() {
        List<String> all = new ArrayList<>();
        all.add(Manifest.permission.BODY_SENSORS); all.add(Manifest.permission.ACTIVITY_RECOGNITION); all.add(Manifest.permission.ACCESS_FINE_LOCATION);
        if (Build.VERSION.SDK_INT >= 31) { all.add(Manifest.permission.BLUETOOTH_SCAN); all.add(Manifest.permission.BLUETOOTH_CONNECT); }
        if (Build.VERSION.SDK_INT >= 33) all.add(Manifest.permission.POST_NOTIFICATIONS);
        List<String> need = new ArrayList<>();
        for (String p : all) if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) need.add(p);
        if (!need.isEmpty()) requestPermissions(need.toArray(new String[0]), 7);
        return coreGranted() && need.isEmpty();
    }
    private boolean coreGranted() {
        return checkSelfPermission(Manifest.permission.BODY_SENSORS) == PackageManager.PERMISSION_GRANTED
            && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }
    @Override public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (pendingStart && coreGranted() && !RunService.S.running) { pendingStart = false; send(RunService.ACTION_START); }
    }

    @Override protected void onNewIntent(Intent i) { super.onNewIntent(i); setIntent(i); refresh(); }

    @Override protected void onResume() {
        super.onResume();
        try { ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).cancel(WatchListener.NOTIF); } catch (Exception ignored) {}
        RunService.listener = () -> h.post(this::refresh);
        String unsent = getSharedPreferences("hf", MODE_PRIVATE).getString("unsent", null);
        if (unsent != null) RunService.sendToPhone(this, unsent);
        refresh();
        h.removeCallbacks(clockTick); h.post(clockTick);
    }
    @Override protected void onPause() { RunService.listener = null; h.removeCallbacks(clockTick); super.onPause(); }

    // l'orario si aggiorna anche quando la corsa non è partita
    private final Runnable clockTick = new Runnable() { @Override public void run() {
        clock.setText(hhmm.format(new Date())); if (!RunService.S.running && !RunService.S.recovering) refresh(); h.postDelayed(this, 15000); } };

    private void refresh() {
        RunService.State s = RunService.S;
        SharedPreferences p = getSharedPreferences("hf", MODE_PRIVATE);
        clock.setText(hhmm.format(new Date()));
        String t = "Corsa libera", pl = "Avvia dal telefono per ricevere la corsa del piano";
        try { JSONObject o = new JSONObject(p.getString("plan", "{}"));
            if (o.has("title")) { t = o.optString("title");
                StringBuilder sb = new StringBuilder();
                if (o.optInt("lo", -1) >= 0) sb.append("🎯 ").append(o.optInt("lo") == o.optInt("hi") ? "Z" + (o.optInt("lo") + 1) : "Z" + (o.optInt("lo") + 1) + "–Z" + (o.optInt("hi") + 1));
                if (o.optDouble("km", 0) > 0) sb.append(sb.length() > 0 ? " · " : "").append(String.format(Locale.ITALY, "%.1f km", o.optDouble("km")));
                if (!o.optString("pace").isEmpty()) sb.append(" · ").append(o.optString("pace")).append("/km");
                if (!o.optString("desc").isEmpty()) sb.append("\n").append(o.optString("desc"));
                pl = sb.toString(); } } catch (Exception ignored) {}
        boolean show = s.running || s.finished || s.recovering;
        title.setText(show ? s.title : t);
        title.setVisibility(s.running ? View.GONE : View.VISIBLE);   // in corsa lascio lo spazio ai numeri
        plan.setText(s.recovering ? "Recupero del battito: resta fermo o cammina piano… ancora " + s.recLeft + " s"
            : s.finished && !s.running ? "Corsa salvata: il riepilogo è stato mandato al telefono ✓" : pl);
        plan.setVisibility(s.running ? View.GONE : View.VISIBLE);
        live.setVisibility(show ? View.VISIBLE : View.GONE);

        time.setText((s.paused ? "⏸ " : "") + hms(s.activeSec));
        dist.setText(String.format(Locale.ITALY, "%.2f", s.km));
        paceNow.setText(s.running && !s.paused && s.paceNow > 0 ? fmtPace(s.paceNow) : "–");
        paceAvg.setText(s.km > 0.2 ? fmtPace(s.activeSec / s.km) : "–");
        boolean fresh = (s.running || s.recovering) && System.currentTimeMillis() - s.lastBeat < 5000 && s.bpm > 0;
        bpm.setText("♥ " + (fresh ? String.valueOf(s.bpm) : "--"));
        if (fresh) { int z = zoneOf(s.bpm, s.hrMax); bpm.setTextColor(ZCOL[z]); zone.setText(ZLAB[z].substring(0, 2) + " · " + ("fascia".equals(s.hrSrc) ? "fascia" : "polso")); zone.setTextColor(ZCOL[z]); }
        else if (s.finished && !s.running && s.samples > 0) { bpm.setText("♥ " + Math.round((double) s.sumHr / s.samples)); bpm.setTextColor(Color.WHITE); zone.setText("media · max " + s.maxHr); zone.setTextColor(GREY); }
        else { bpm.setTextColor(Color.WHITE); zone.setText(s.running ? "battito…" : "battiti"); zone.setTextColor(GREY); }
        segLine.setText(s.running ? s.seg : ""); segLine.setVisibility(s.running && !s.seg.isEmpty() ? View.VISIBLE : View.GONE);
        kcal.setText(s.kcal > 0 ? Math.round(s.kcal) + " kcal" : "");

        String st;
        if (s.recovering) st = "";
        else if (s.running) st = "🫀 " + (s.strap.isEmpty() ? "battito dal polso" : s.strap);
        else { String nm = p.getString("hrName", ""), ad = p.getString("hrAddr", "");
            st = !ad.isEmpty() ? "🫀 " + (nm.isEmpty() ? "Fascia" : nm) + ": la collego all'avvio" : "🫀 Se indossi la fascia la cerco all'avvio"; }
        strap.setText(s.finished && !s.running ? "" : st);
        err.setText(s.error); err.setVisibility(s.error.isEmpty() ? View.GONE : View.VISIBLE);
        start.setVisibility(s.running || s.recovering ? View.GONE : View.VISIBLE); start.setText(s.finished ? "NUOVA CORSA" : "AVVIA");
        pause.setVisibility(s.running ? View.VISIBLE : View.GONE); pause.setText(s.paused ? "RIPRENDI" : "PAUSA");
        stop.setVisibility(s.running || s.recovering ? View.VISIBLE : View.GONE); stop.setText(s.recovering ? "SALTA IL RECUPERO" : "FINE");
    }
    private static int zoneOf(int b, int mx) { double pc = b / (double) mx; return pc < 0.6 ? 0 : pc < 0.7 ? 1 : pc < 0.8 ? 2 : pc < 0.9 ? 3 : 4; }
    private static String fmtPace(double secPerKm) { long p = Math.round(secPerKm); if (p >= 60 * 60) return "–"; return (p / 60) + ":" + String.format(Locale.ITALY, "%02d", p % 60); }
    private static String hms(long sec) { long hh = sec / 3600, m = (sec % 3600) / 60, s = sec % 60;
        return hh > 0 ? String.format(Locale.ITALY, "%d:%02d:%02d", hh, m, s) : String.format(Locale.ITALY, "%d:%02d", m, s); }
}
