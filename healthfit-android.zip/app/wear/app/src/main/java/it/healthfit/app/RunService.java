package it.healthfit.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.ParcelUuid;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.core.app.ServiceCompat;
import androidx.core.content.ContextCompat;
import androidx.health.services.client.ExerciseClient;
import androidx.health.services.client.ExerciseUpdateCallback;
import androidx.health.services.client.HealthServices;
import androidx.health.services.client.data.Availability;
import androidx.health.services.client.data.CumulativeDataPoint;
import androidx.health.services.client.data.DataPointContainer;
import androidx.health.services.client.data.DataType;
import androidx.health.services.client.data.ExerciseCapabilities;
import androidx.health.services.client.data.ExerciseConfig;
import androidx.health.services.client.data.ExerciseLapSummary;
import androidx.health.services.client.data.ExerciseType;
import androidx.health.services.client.data.ExerciseUpdate;
import androidx.health.services.client.data.LocationData;
import androidx.health.services.client.data.SampleDataPoint;

import com.google.android.gms.wearable.Node;
import com.google.android.gms.wearable.Wearable;
import com.google.common.util.concurrent.FutureCallback;
import com.google.common.util.concurrent.Futures;

import org.json.JSONArray;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

/**
 * Registra la corsa sull'orologio (GPS del Galaxy Watch), vibra fuori zona e a ogni km, poi manda il riepilogo al telefono.
 * Battito: dalla fascia cardio se è collegata e manda dati, altrimenti dal sensore dell'orologio (e ci torna da sola se la fascia si stacca).
 * Ogni 5 secondi salva un punto del percorso (tempo, metri, battito, altitudine, passi, posizione) per il riepilogo sul telefono;
 * dopo FINE misura per un minuto il recupero del battito, poi manda tutto.
 */
public class RunService extends Service {
    public static final String ACTION_START = "hf.START", ACTION_PAUSE = "hf.PAUSE", ACTION_RESUME = "hf.RESUME", ACTION_STOP = "hf.STOP";
    static final String CHANNEL = "hf_watch_run";
    static final int NOTIF = 5151;
    static final UUID HR_SERVICE = UUID.fromString("0000180d-0000-1000-8000-00805f9b34fb");
    static final UUID HR_MEASURE = UUID.fromString("00002a37-0000-1000-8000-00805f9b34fb");
    static final UUID CCC = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");

    public static final class State {
        public boolean running, paused, finished;
        public String title = "Corsa", error = "";
        public int bpm, maxHr, lo = -1, hi = -1, hrMax = 185;
        public long samples, sumHr, activeSec, lastBeat, startedAt;
        public double km, kcal;
        public double paceNow;               // ritmo degli ultimi ~30 secondi (s/km), 0 = non disponibile
        public long[] zoneSec = new long[5];
        public String hrSrc = "";            // "fascia" o "orologio": da dove arriva il battito mostrato
        public String strap = "";            // stato della fascia: "", "cerco…", "collegata", "non trovata"…
        public String strapName = "";
        public long strapSec, watchSec;      // secondi con battito dalla fascia e dal polso
        public boolean recovering;           // dopo FINE: misuro il recupero del battito
        public int recLeft;                  // secondi di recupero che mancano
        public long steps;
        public String seg = "";              // fase in corso e tipo di corsa, es. "Riscaldamento – Lungo"
        public String segInfo = "";          // es. "ancora 2:10 · obiettivo 6:40/km"
        public String runType = "";
        public int hrLoB, hrHiB;             // battiti della zona obiettivo (0 = nessun limite)
        public double target;                // ritmo obiettivo della fase (s/km), 0 = nessuno
        // dati di ogni fase (riscaldamento, allenamento…): tempo, km, somma e numero dei battiti
        public String[] phName = new String[0];
        public long[] phSec = new long[0], phHrSum = new long[0], phHrN = new long[0];
        public double[] phKm = new double[0];
        public int phIdx = 0;
        public double lastKmVal = 0;         // km a cui è iniziata la fase in corso (per i km della fase)
    }
    public static final State S = new State();
    public interface Listener { void onUpdate(); }
    public static Listener listener;

    private ExerciseClient ex;
    private final Handler h = new Handler(Looper.getMainLooper());
    private PowerManager.WakeLock wl;
    private long outSince = 0, lastAlert = 0;
    private int lastKm = 0;
    private JSONObject ref = null;
    // battito dalle due sorgenti (scritto anche dai thread del Bluetooth)
    private volatile int strapBpm = 0, wristBpm = 0;
    private volatile long strapAt = 0, wristAt = 0;
    // ritmo attuale: tempo e km degli ultimi 30 secondi di corsa
    private final long[] rSec = new long[31];
    private final double[] rKm = new double[31];
    private int rN = 0, rPos = 0;
    // fascia cardio
    private BluetoothGatt gatt;
    private BluetoothDevice strapDev;
    private BluetoothLeScanner scanner;
    private boolean scanning = false;
    private String strapAddr = "";
    private int reconnects = 0;
    private Voice voice;
    // percorso e dati per il riepilogo
    static final int REC_SEC = 60;
    private final ArrayList<int[]> trk = new ArrayList<>();   // {secondi, metri, bpm, altitudine, passi, lat*1e5, lon*1e5}
    private final ArrayList<int[]> rec = new ArrayList<>();   // {secondi dopo FINE, bpm}
    private volatile double lat = 0, lon = 0, alt = Double.NaN, baro = Double.NaN, elevGain = -1, elevLoss = -1;
    private volatile long stepsTot = -1;
    private long stopAt = 0, recSec = 0;
    private JSONObject frozen = null;
    // fasi della seduta (riscaldamento, allenamento, recuperi, defaticamento) e ritmo obiettivo
    private JSONArray segs = null;
    private int segIdx = 0;
    private long segStartSec = 0, lastKmSec = 0;
    private double segStartKm = 0, planPace = 0;
    // obiettivo della seduta (km o minuti) e avvisi già dati al 30, 50, 80 e 100%
    private double goalKm = 0, goalMin = 0;
    private int goalStep = 0;
    // defaticamento come Samsung Health: finisce da solo quando il battito scende sotto questa soglia
    private int coolHr = 0;
    private long coolBelowSince = 0;
    private boolean autoEnding = false;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String a = intent != null ? intent.getAction() : null;
        if (ACTION_START.equals(a)) start();
        else if (ACTION_PAUSE.equals(a)) pause();
        else if (ACTION_RESUME.equals(a)) resume();
        else if (ACTION_STOP.equals(a)) stop();
        return START_NOT_STICKY;
    }

    private void start() {
        if (S.running) return;
        if (S.recovering) finishRecovery();
        SharedPreferences p = getSharedPreferences("hf", MODE_PRIVATE);
        ref = null;
        try {
            JSONObject plan = new JSONObject(p.getString("plan", "{}"));
            S.title = plan.optString("title", "Corsa"); S.lo = plan.optInt("lo", -1); S.hi = plan.optInt("hi", -1); S.hrMax = plan.optInt("hrMax", 185);
            ref = plan.optJSONObject("ref");
            segs = plan.optJSONArray("segs"); planPace = paceOf(plan.optString("pace", "")); S.runType = plan.optString("runType", "");
        } catch (Exception e) { S.title = "Corsa"; segs = null; planPace = 0; S.runType = ""; }
        S.hrLoB = 0; S.hrHiB = 0;
        if (S.lo >= 0) { double[] lo = {0, .6, .7, .8, .9}, hi = {.6, .7, .8, .9, 1.0};
            S.hrLoB = (int) Math.round(S.hrMax * lo[Math.min(4, S.lo)]); S.hrHiB = S.hi >= 4 ? 0 : (int) Math.round(S.hrMax * hi[Math.max(0, S.hi)]); }
        coolHr = (int) Math.round(S.hrMax * 0.65); coolBelowSince = 0; autoEnding = false;
        segIdx = 0; segStartSec = 0; segStartKm = 0; lastKmSec = 0; S.seg = ""; S.target = planPace; goalStep = 0; goalKm = 0; goalMin = 0;
        try { goalKm = new JSONObject(p.getString("plan", "{}")).optDouble("km", 0); } catch (Exception ignored) {}
        if (goalKm <= 0 && segs != null) { double m = 0; boolean allTime = true;
            for (int i = 0; i < segs.length(); i++) { JSONObject g = segs.optJSONObject(i); if (g == null) continue; if (g.optDouble("min", 0) > 0) m += g.optDouble("min", 0); else allTime = false; }
            if (allTime) goalMin = m; }
        int nPh = segs != null && segs.length() > 0 ? segs.length() : 0;
        S.phName = new String[nPh]; S.phSec = new long[nPh]; S.phKm = new double[nPh]; S.phHrSum = new long[nPh]; S.phHrN = new long[nPh]; S.phIdx = 0; S.lastKmVal = 0;
        // più tratti veloci (ripetute, scatti): li numero, "Scatto 1", "Recupero 1", "Scatto 2"…
        int nWork = 0; for (int i = 0; i < nPh; i++) { JSONObject g = segs.optJSONObject(i); if (g != null && "work".equals(g.optString("k", "work"))) nWork++; }
        String rep = S.runType.matches("(?i).*(scatt|sprint|allung).*") ? "Scatto" : "Ripetuta";
        int w = 0, r = 0;
        for (int i = 0; i < nPh; i++) { JSONObject g = segs.optJSONObject(i); String k = g != null ? g.optString("k", "work") : "work";
            S.phName[i] = nWork > 1 && "work".equals(k) ? rep + " " + (++w) : nWork > 1 && "recovery".equals(k) ? "Recupero " + (++r) : kindName(k); }
        if (S.title.isEmpty()) S.title = "Corsa";
        S.running = true; S.paused = false; S.finished = false; S.error = ""; S.bpm = 0; S.maxHr = 0; S.samples = 0; S.sumHr = 0; S.activeSec = 0; S.km = 0; S.kcal = 0;
        S.zoneSec = new long[5]; S.startedAt = System.currentTimeMillis(); S.paceNow = 0; S.hrSrc = ""; S.strapSec = 0; S.watchSec = 0; S.lastBeat = 0;
        lastKm = 0; outSince = 0; rN = 0; rPos = 0; strapBpm = 0; wristBpm = 0; strapAt = 0; wristAt = 0; reconnects = 0;
        S.recovering = false; S.recLeft = 0; S.steps = 0; trk.clear(); rec.clear(); lat = 0; lon = 0; alt = Double.NaN; baro = Double.NaN;
        elevGain = -1; elevLoss = -1; stepsTot = -1; stopAt = 0; recSec = 0; frozen = null;
        strapAddr = p.getString("hrAddr", ""); S.strapName = p.getString("hrName", "");

        createChannel();
        int type = 0;
        if (Build.VERSION.SDK_INT >= 34) {
            type = ServiceInfo.FOREGROUND_SERVICE_TYPE_HEALTH | ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION;
            if (btAllowed()) type |= ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE;
        } else if (Build.VERSION.SDK_INT >= 29) type = ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION;
        ServiceCompat.startForeground(this, NOTIF, notif("Avvio…"), type);

        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "healthfit:watchrun");
        wl.acquire(6 * 60 * 60 * 1000L);

        ex = HealthServices.getClient(this).getExerciseClient();
        ex.setUpdateCallback(cb);
        // chiedo all'orologio quali dati sa misurare: posizione, passi e altitudine solo se ci sono (altrimenti l'avvio fallirebbe)
        Futures.addCallback(ex.getCapabilitiesAsync(), new FutureCallback<ExerciseCapabilities>() {
            @Override public void onSuccess(ExerciseCapabilities caps) {
                Set<DataType<?, ?>> sup = null;
                try { sup = caps.getExerciseTypeCapabilities(ExerciseType.RUNNING).getSupportedDataTypes(); } catch (Exception ignored) {}
                startExercise(sup);
            }
            @Override public void onFailure(@NonNull Throwable t) { startExercise(null); }
        }, ContextCompat.getMainExecutor(this));
        if (voice != null) voice.shutdown();
        voice = new Voice(this);
        h.postDelayed(() -> say("Corsa avviata"), 2500);
        startStrap();
        h.removeCallbacks(tick); h.postDelayed(tick, 1000);
    }

    private void startExercise(Set<DataType<?, ?>> sup) {
        if (!S.running || ex == null) return;
        Set<DataType<?, ?>> types = new HashSet<>();
        types.add(DataType.HEART_RATE_BPM);
        types.add(DataType.DISTANCE_TOTAL);
        types.add(DataType.CALORIES_TOTAL);
        if (sup != null) {
            if (sup.contains(DataType.LOCATION)) types.add(DataType.LOCATION);
            if (sup.contains(DataType.STEPS_TOTAL)) types.add(DataType.STEPS_TOTAL);
            if (sup.contains(DataType.ABSOLUTE_ELEVATION)) types.add(DataType.ABSOLUTE_ELEVATION);
            if (sup.contains(DataType.ELEVATION_GAIN_TOTAL)) types.add(DataType.ELEVATION_GAIN_TOTAL);
            if (sup.contains(DataType.ELEVATION_LOSS_TOTAL)) types.add(DataType.ELEVATION_LOSS_TOTAL);
        }
        ExerciseConfig cfg = new ExerciseConfig.Builder(ExerciseType.RUNNING)
            .setDataTypes(types).setIsAutoPauseAndResumeEnabled(false).setIsGpsEnabled(true).build();
        Futures.addCallback(ex.startExerciseAsync(cfg), new FutureCallback<Void>() {
            @Override public void onSuccess(Void v) { vibrate(new long[]{0, 200}); }
            @Override public void onFailure(@NonNull Throwable t) { S.error = "Non riesco ad avviare: " + t.getMessage(); notifyUi(); }
        }, ContextCompat.getMainExecutor(this));
    }

    private final ExerciseUpdateCallback cb = new ExerciseUpdateCallback() {
        @Override public void onExerciseUpdateReceived(@NonNull ExerciseUpdate update) {
            DataPointContainer m = update.getLatestMetrics();
            List<SampleDataPoint<Double>> hr = m.getData(DataType.HEART_RATE_BPM);
            if (!hr.isEmpty()) { double b = hr.get(hr.size() - 1).getValue(); if (b > 25 && b < 240) { wristBpm = (int) Math.round(b); wristAt = System.currentTimeMillis(); pickHr(); } }
            if (S.recovering) return;   // dopo FINE serve solo il battito: distanza e calorie restano quelle della corsa
            CumulativeDataPoint<Double> d = m.getData(DataType.DISTANCE_TOTAL);
            if (d != null) S.km = d.getTotal() / 1000.0;
            CumulativeDataPoint<Double> c = m.getData(DataType.CALORIES_TOTAL);
            if (c != null) S.kcal = c.getTotal();
            List<SampleDataPoint<LocationData>> loc = m.getData(DataType.LOCATION);
            if (!loc.isEmpty()) { LocationData L = loc.get(loc.size() - 1).getValue(); lat = L.getLatitude(); lon = L.getLongitude();
                double a = L.getAltitude(); if (!Double.isNaN(a) && a > -500 && a < 9000) alt = a; }
            List<SampleDataPoint<Double>> el = m.getData(DataType.ABSOLUTE_ELEVATION);
            if (!el.isEmpty()) { double a = el.get(el.size() - 1).getValue(); if (!Double.isNaN(a) && a > -500 && a < 9000) baro = a; }
            CumulativeDataPoint<Long> st = m.getData(DataType.STEPS_TOTAL);
            if (st != null) { stepsTot = st.getTotal(); S.steps = stepsTot; }
            CumulativeDataPoint<Double> eg = m.getData(DataType.ELEVATION_GAIN_TOTAL);
            if (eg != null) elevGain = eg.getTotal();
            CumulativeDataPoint<Double> eL = m.getData(DataType.ELEVATION_LOSS_TOTAL);
            if (eL != null) elevLoss = eL.getTotal();
        }
        @Override public void onLapSummaryReceived(@NonNull ExerciseLapSummary s) {}
        @Override public void onRegistered() {}
        @Override public void onRegistrationFailed(@NonNull Throwable t) { S.error = "Health Services: " + t.getMessage(); notifyUi(); }
        @Override public void onAvailabilityChanged(@NonNull DataType<?, ?> type, @NonNull Availability a) {}
    };

    /** Sceglie il battito da mostrare: la fascia se ha mandato un dato negli ultimi 5 secondi, altrimenti il polso. */
    private void pickHr() {
        long now = System.currentTimeMillis();
        if (strapBpm > 0 && now - strapAt < 5000) { S.bpm = strapBpm; S.lastBeat = strapAt; S.hrSrc = "fascia"; }
        else if (wristBpm > 0 && now - wristAt < 5000) { S.bpm = wristBpm; S.lastBeat = wristAt; S.hrSrc = "orologio"; }
    }

    // ---------- fascia cardio (servizio Bluetooth standard Heart Rate) ----------
    private boolean btAllowed() {
        if (Build.VERSION.SDK_INT >= 31)
            return checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
                && checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED;
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    /** Cerca la fascia salvata sul telefono (o, se non ce n'è una, la prima fascia cardio accesa vicino). */
    @SuppressLint("MissingPermission")
    private void startStrap() {
        if (!S.running || gatt != null || scanning) return;
        if (!btAllowed()) { S.strap = "Bluetooth non permesso: battito dal polso"; return; }
        try {
            BluetoothManager bm = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
            BluetoothAdapter ad = bm != null ? bm.getAdapter() : null;
            if (ad == null || !ad.isEnabled()) { S.strap = "Bluetooth spento: battito dal polso"; return; }
            scanner = ad.getBluetoothLeScanner();
            if (scanner == null) { S.strap = ""; return; }
            ScanFilter f = new ScanFilter.Builder().setServiceUuid(new ParcelUuid(HR_SERVICE)).build();
            ScanSettings st = new ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build();
            scanner.startScan(Collections.singletonList(f), st, scanCb);
            scanning = true; S.strap = "cerco la fascia…";
            h.postDelayed(scanTimeout, 15000);
        } catch (Exception e) { scanning = false; S.strap = ""; }
    }

    private final Runnable scanTimeout = new Runnable() { @SuppressLint("MissingPermission") @Override public void run() {
        stopScan();
        if (!S.running || gatt != null) return;
        // la fascia salvata a volte non si annuncia nella ricerca: provo a collegarla direttamente
        if (!strapAddr.isEmpty()) {
            try {
                BluetoothManager bm = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
                connect(bm.getAdapter().getRemoteDevice(strapAddr));
                return;
            } catch (Exception ignored) {}
        }
        S.strap = "fascia non trovata: battito dal polso";
        h.postDelayed(() -> startStrap(), 45000);   // riprova: magari la indossi dopo
    }};

    private final ScanCallback scanCb = new ScanCallback() {
        @Override public void onScanResult(int type, ScanResult r) {
            BluetoothDevice dev = r.getDevice();
            if (dev == null || gatt != null) return;
            if (!strapAddr.isEmpty() && !strapAddr.equalsIgnoreCase(dev.getAddress())) return;
            h.post(() -> { if (gatt == null && S.running) { stopScan(); h.removeCallbacks(scanTimeout); connect(dev); } });
        }
        @Override public void onScanFailed(int code) { scanning = false; }
    };

    @SuppressLint("MissingPermission")
    private void stopScan() {
        if (!scanning) return; scanning = false;
        try { if (scanner != null) scanner.stopScan(scanCb); } catch (Exception ignored) {}
    }

    @SuppressLint("MissingPermission")
    private void connect(BluetoothDevice dev) {
        try {
            strapDev = dev;
            try { String n = dev.getName(); if (n != null && !n.isEmpty()) S.strapName = n; } catch (Exception ignored) {}
            if (S.strapName.isEmpty()) S.strapName = "Fascia";
            if (gatt != null) { try { gatt.close(); } catch (Exception ignored) {} }
            S.strap = "collego " + S.strapName + "…";
            gatt = dev.connectGatt(this, false, gcb, BluetoothDevice.TRANSPORT_LE);
        } catch (Exception e) { gatt = null; S.strap = "fascia non collegata: battito dal polso"; }
    }

    private final BluetoothGattCallback gcb = new BluetoothGattCallback() {
        @SuppressLint("MissingPermission")
        @Override public void onConnectionStateChange(BluetoothGatt g, int status, int newState) {
            if (newState == BluetoothProfile.STATE_CONNECTED) { reconnects = 0; S.strap = S.strapName + " collegata"; g.discoverServices(); }
            else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                h.post(() -> {
                    try { g.close(); } catch (Exception ignored) {}
                    if (gatt == g) gatt = null;
                    if (!S.running) return;
                    S.strap = "fascia persa: battito dal polso";
                    if (reconnects < 40 && strapDev != null) { reconnects++;
                        h.postDelayed(() -> { if (S.running && gatt == null) connect(strapDev); }, Math.min(15000, 1500L * reconnects)); }
                });
            }
        }
        @SuppressLint("MissingPermission")
        @SuppressWarnings("deprecation")
        @Override public void onServicesDiscovered(BluetoothGatt g, int status) {
            BluetoothGattService s = g.getService(HR_SERVICE); if (s == null) return;
            BluetoothGattCharacteristic c = s.getCharacteristic(HR_MEASURE); if (c == null) return;
            g.setCharacteristicNotification(c, true);
            BluetoothGattDescriptor d = c.getDescriptor(CCC);
            if (d != null) {
                if (Build.VERSION.SDK_INT >= 33) g.writeDescriptor(d, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                else { d.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE); g.writeDescriptor(d); }
            }
        }
        @Override public void onCharacteristicChanged(@NonNull BluetoothGatt g, @NonNull BluetoothGattCharacteristic c, @NonNull byte[] v) { parse(v); }
        @SuppressWarnings("deprecation")
        @Override public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic c) { if (Build.VERSION.SDK_INT < 33) parse(c.getValue()); }
    };

    private void parse(byte[] v) {
        if (v == null || v.length < 2) return;
        int flags = v[0] & 0xff;
        int bpm = (flags & 1) != 0 && v.length >= 3 ? ((v[1] & 0xff) | ((v[2] & 0xff) << 8)) : (v[1] & 0xff);
        if (bpm > 25 && bpm < 240) { strapBpm = bpm; strapAt = System.currentTimeMillis(); }
    }

    @SuppressLint("MissingPermission")
    private void stopStrap() {
        stopScan(); h.removeCallbacks(scanTimeout);
        try { if (gatt != null) { gatt.disconnect(); gatt.close(); } } catch (Exception ignored) {}
        gatt = null; strapDev = null;
    }

    // ---------- ogni secondo ----------
    private int zoneOf(int b) { double pc = b / (double) S.hrMax; return pc < 0.6 ? 0 : pc < 0.7 ? 1 : pc < 0.8 ? 2 : pc < 0.9 ? 3 : 4; }

    private final Runnable tick = new Runnable() { @Override public void run() {
        if (S.recovering) { recoveryTick(); return; }
        if (!S.running) return;
        pickHr();
        if (!S.paused) {
            S.activeSec++;
            if (System.currentTimeMillis() - S.lastBeat < 5000 && S.bpm > 0) {
                int z = zoneOf(S.bpm); S.sumHr += S.bpm; S.samples++; S.maxHr = Math.max(S.maxHr, S.bpm); S.zoneSec[z]++;
                if ("fascia".equals(S.hrSrc)) S.strapSec++; else S.watchSec++;
                checkZone(z);
            }
            int k = (int) Math.floor(S.km);
            if (k > lastKm && k >= 1) { lastKm = k; vibrate(new long[]{0, 120, 120, 120}); sayKm(k); }
            updatePace();
            updateSeg();
            checkGoal();
            if (S.phIdx < S.phSec.length) { S.phSec[S.phIdx] = S.activeSec - segStartSec; S.phKm[S.phIdx] = S.km - segStartKm;
                if (System.currentTimeMillis() - S.lastBeat < 5000 && S.bpm > 0) { S.phHrSum[S.phIdx] += S.bpm; S.phHrN[S.phIdx]++; } }
            if (S.activeSec % 5 == 0) addPoint();
        }
        if (S.activeSec % 5 == 0) updateNotif();
        notifyUi();
        h.postDelayed(this, 1000);
    }};

    /** Un punto del percorso ogni 5 secondi di corsa. */
    private void addPoint() {
        boolean fresh = System.currentTimeMillis() - S.lastBeat < 5000 && S.bpm > 0;
        double a = !Double.isNaN(baro) ? baro : alt;
        trk.add(new int[]{ (int) S.activeSec, (int) Math.round(S.km * 1000), fresh ? S.bpm : 0, Double.isNaN(a) ? -9999 : (int) Math.round(a),
            stepsTot >= 0 ? (int) stepsTot : -1, (int) Math.round(lat * 1e5), (int) Math.round(lon * 1e5) });
    }

    /** Dopo FINE: per un minuto registro come scende il battito (ogni 2 secondi). */
    private void recoveryTick() {
        pickHr();
        recSec++; S.recLeft = (int) Math.max(0, REC_SEC - recSec);
        boolean fresh = System.currentTimeMillis() - S.lastBeat < 5000 && S.bpm > 0;
        if (recSec % 2 == 0 && fresh) rec.add(new int[]{ (int) recSec, S.bpm });
        notifyUi();
        if (recSec % 5 == 0) updateNotif();
        if (recSec >= REC_SEC) { finishRecovery(); return; }
        h.postDelayed(tick, 1000);
    }

    /** Ritmo attuale: distanza percorsa negli ultimi 30 secondi di corsa (le pause non contano). */
    private void updatePace() {
        rSec[rPos] = S.activeSec; rKm[rPos] = S.km; rPos = (rPos + 1) % rSec.length; if (rN < rSec.length) rN++;
        int oldest = rN < rSec.length ? 0 : rPos;
        long ds = S.activeSec - rSec[oldest]; double dk = S.km - rKm[oldest];
        S.paceNow = ds >= 10 && dk >= 0.02 ? ds / dk : 0;   // sotto 20 metri in 30 secondi: fermo, nessun ritmo
    }

    private void checkZone(int z) {
        if (S.lo < 0) return;
        long now = System.currentTimeMillis();
        String kind = curKind();
        // sotto la zona conta solo nei tratti di allenamento (non in riscaldamento, recuperi e defaticamento)
        boolean out = z > S.hi || (S.lo >= 3 && z < S.lo && "work".equals(kind));
        if (!out) { outSince = 0; return; }
        if (outSince == 0) outSince = now;
        long limit = z > S.hi ? 20000 : 60000;
        if (now - outSince > limit && now - lastAlert > 45000) {
            lastAlert = now;
            // sopra la zona: due vibrazioni lunghe · sotto la zona: tre brevi
            vibrate(z > S.hi ? new long[]{0, 500, 200, 500} : new long[]{0, 150, 120, 150, 120, 150});
            say("Battito " + S.bpm + ", " + (z > S.hi ? "sopra la zona, rallenta. " : "puoi spingere un po' di più. ") + rangeWords());
        }
    }

    /** Obiettivo della fase detto a voce: "Inizia scatto 2: 400 metri a 4 e 30, battiti tra 160 e 175". */
    private String phaseGoal(JSONObject g, int i) {
        String k = g.optString("k", "work"); double min = g.optDouble("min", 0), km = g.optDouble("km", 0), t = segTarget(g);
        StringBuilder sb = new StringBuilder("Inizia ").append(S.phName[i].toLowerCase(Locale.ITALY)).append(": ");
        if (km > 0) sb.append(km < 1 ? Math.round(km * 1000) + " metri" : kmWords(km) + " chilometri");
        else if (min > 0) sb.append(min < 1 ? Math.round(min * 60) + " secondi" : (Math.round(min * 10) / 10.0 == Math.round(min) ? String.valueOf(Math.round(min)) : String.format(Locale.ITALY, "%.1f", min).replace(",", " virgola ")) + " minuti");
        else sb.append("corsa libera");
        if (t > 0) sb.append(" a ").append(paceWords(t)).append(" al chilometro");
        else if ("warmup".equals(k) || "cooldown".equals(k) || "recovery".equals(k)) sb.append(", andatura facile");
        if ("work".equals(k)) { String r = rangeWords(); if (!r.isEmpty()) sb.append(", battiti: ").append(r.substring(0, 1).toLowerCase(Locale.ITALY)).append(r.substring(1)); }
        return sb.toString();
    }

    private String rangeWords() {
        return S.hrLoB > 0 && S.hrHiB > 0 ? "Stai tra " + S.hrLoB + " e " + S.hrHiB : S.hrHiB > 0 ? "Stai sotto i " + S.hrHiB : S.hrLoB > 0 ? "Stai sopra i " + S.hrLoB : "";
    }

    // ---------- voce ----------
    private void say(String msg) { if (voice != null && (S.running || S.recovering)) voice.say(msg); }
    private static String paceWords(double secPerKm) { long p = Math.round(secPerKm); return (p / 60) + " e " + (p % 60); }
    /** A ogni km: tempo, ritmo dell'ultimo km confrontato con l'obiettivo della fase, battito. */
    private void sayKm(int k) {
        long split = S.activeSec - lastKmSec; lastKmSec = S.activeSec;
        StringBuilder sb = new StringBuilder().append(k).append(k == 1 ? " chilometro" : " chilometri");
        sb.append(", tempo ").append(S.activeSec / 60).append(" minuti");
        if (split > 120 && split < 1200) {
            sb.append(", ultimo chilometro ").append(paceWords(split));
            String kind = curKind();
            if (S.target > 0 && !"warmup".equals(kind) && !"cooldown".equals(kind)) {
                long d = Math.round(split - S.target);
                if (Math.abs(d) <= 10) sb.append(", sei in linea con l'obiettivo");
                else if (d < 0) sb.append(", ").append(-d).append(" secondi più veloce dell'obiettivo, rallenta un po'");
                else sb.append(", ").append(d).append(" secondi più lento dell'obiettivo, ").append(d > 25 ? "accelera" : "spingi un pochino");
            }
        }
        if (System.currentTimeMillis() - S.lastBeat < 5000 && S.bpm > 0) sb.append(", battito ").append(S.bpm);
        say(sb.toString());
    }

    /** Avanzamento verso l'obiettivo: al 30, 50 e 80% dice quanto manca con un incoraggiamento, al 100% che è fatta. */
    private void checkGoal() {
        double pc = goalKm > 0 ? S.km / goalKm : goalMin > 0 ? S.activeSec / (goalMin * 60) : 0;
        if (pc <= 0) return;
        int[] steps = {30, 50, 80, 100};
        if (goalStep >= steps.length || pc * 100 < steps[goalStep]) return;
        int st = steps[goalStep]; while (goalStep < steps.length && pc * 100 >= steps[goalStep]) goalStep++;
        String left = goalKm > 0 ? kmWords(Math.max(0, goalKm - S.km)) + " chilometri" : Math.max(1, Math.round(goalMin - S.activeSec / 60.0)) + " minuti";
        String msg = st == 30 ? "Sei al 30 per cento, mancano " + left + ". Ottimo inizio, continua così"
            : st == 50 ? "Metà fatta! Mancano " + left + ". Stai andando alla grande"
            : st == 80 ? "Sei all'80 per cento, mancano solo " + left + ". Ultimo sforzo, ce la fai"
            : "Obiettivo raggiunto! Bravissimo";
        if (st == 100) vibrate(new long[]{0, 200, 100, 200, 100, 400});
        say(msg);
    }
    private static String kmWords(double km) { String t = String.format(Locale.ITALY, "%.1f", km); return t.endsWith(",0") ? t.substring(0, t.length() - 2) : t.replace(",", " virgola "); }

    // ---------- fasi della seduta ----------
    static double paceOf(String t) {
        try { java.util.regex.Matcher m = java.util.regex.Pattern.compile("(\\d+)[:'](\\d{1,2})").matcher(t == null ? "" : t);
            if (m.find()) { double v = Integer.parseInt(m.group(1)) * 60 + Integer.parseInt(m.group(2)); return v >= 150 && v <= 1200 ? v : 0; } } catch (Exception ignored) {}
        return 0;
    }
    private static String kindName(String k) {
        return "warmup".equals(k) ? "Riscaldamento" : "recovery".equals(k) ? "Recupero" : "cooldown".equals(k) ? "Defaticamento" : "Allenamento";
    }
    private String curKind() { JSONObject g = segs != null ? segs.optJSONObject(segIdx) : null; return g != null ? g.optString("k", "work") : "work"; }
    private double segTarget(JSONObject g) { double t = g != null ? paceOf(g.optString("p", "")) : 0; String k = g != null ? g.optString("k", "work") : "work";
        return t > 0 ? t : ("work".equals(k) ? planPace : 0); }

    /** Passa alla fase successiva quando finisce il tempo o la distanza di quella in corso e lo dice a voce, come Samsung Health. */
    private void updateSeg() {
        if (segs == null || segs.length() == 0) { S.seg = S.runType.isEmpty() ? S.title : S.runType; S.segInfo = S.target > 0 ? "🎯 obiettivo " + fmtPace(S.target) + "/km" : ""; return; }
        JSONObject g = segs.optJSONObject(segIdx); if (g == null) return;
        double min = g.optDouble("min", 0), km = g.optDouble("km", 0);
        long secIn = S.activeSec - segStartSec; double kmIn = S.km - segStartKm;
        boolean last = segIdx >= segs.length() - 1;
        boolean done = !last && (min > 0 ? secIn >= Math.round(min * 60) : km > 0 && kmIn >= km);
        if (done) {
            String was = g.optString("k", "work");
            segIdx++; segStartSec = S.activeSec; segStartKm = S.km; S.phIdx = segIdx; S.lastKmVal = S.km;
            g = segs.optJSONObject(segIdx); min = g.optDouble("min", 0); km = g.optDouble("km", 0); secIn = 0; kmIn = 0;
            S.target = segTarget(g);
            String now = g.optString("k", "work"), lab = g.optString("l", "");
            vibrate(new long[]{0, 400, 150, 400});
            StringBuilder sb = new StringBuilder(S.phName[segIdx - 1]).append(" finito. ");
            if ("cooldown".equals(now)) sb.append("Inizia il defaticamento: corri piano o cammina, finisce da solo quando il battito scende sotto ").append(coolHr);
            else sb.append(phaseGoal(g, segIdx));
            say(sb.toString());
        } else if (segIdx == 0 && S.activeSec == 1) S.target = segTarget(g);
        else if (segIdx == 0 && S.activeSec == 4) say(phaseGoal(g, 0));   // obiettivo della prima fase, dopo "Corsa avviata"
        String left = min > 0 ? " · ancora " + fmtPace(Math.max(0, Math.round(min * 60) - secIn)) : km > 0 ? String.format(Locale.ITALY, " · ancora %.1f km", Math.max(0, km - kmIn)) : "";
        S.seg = S.phName[segIdx] + (S.runType.isEmpty() ? "" : " – " + S.runType);
        String info = ((last ? "" : left) + (S.target > 0 ? " · obiettivo " + fmtPace(S.target) + "/km" : "")).replaceFirst("^ · ", "");
        boolean cool = "cooldown".equals(g.optString("k", "work")) && last;
        if (cool) info = "finisce sotto ♥" + coolHr;
        S.segInfo = info;
        // fine automatica del defaticamento: battito sotto la soglia per 15 secondi (dopo almeno 1 minuto),
        // oppure, senza battito, quando passa il tempo previsto
        if (cool && !autoEnding && secIn >= 60) {
            boolean fresh = System.currentTimeMillis() - S.lastBeat < 5000 && S.bpm > 0;
            if (fresh && S.bpm < coolHr) { if (coolBelowSince == 0) coolBelowSince = S.activeSec; } else coolBelowSince = 0;
            boolean byHr = coolBelowSince > 0 && S.activeSec - coolBelowSince >= 15;
            boolean byTime = !fresh && min > 0 && secIn >= Math.round(min * 60);
            if (byHr || byTime) {
                autoEnding = true;
                vibrate(new long[]{0, 300, 150, 300, 150, 300});
                say("Defaticamento finito" + (byHr ? ", battito sceso a " + S.bpm : "") + ". Allenamento completato, bravo!");
                h.postDelayed(this::stop, 3000);
            }
        }
    }
    private static String fmtPace(double sec) { long p = Math.round(sec); return (p / 60) + ":" + (p % 60 < 10 ? "0" : "") + (p % 60); }

    /** Pausa o ripresa (pulsante a schermo o tasto dell'orologio). */
    static void togglePause(Context c) { Intent i = new Intent(c, RunService.class); i.setAction(S.paused ? ACTION_RESUME : ACTION_PAUSE); c.startService(i); }

    private void pause() { if (!S.running || S.paused || ex == null) return; S.paused = true; S.paceNow = 0; rN = 0; rPos = 0; ex.pauseExerciseAsync(); vibrate(new long[]{0, 300}); say("Corsa in pausa"); updateNotif(); notifyUi(); }
    private void resume() { if (!S.running || !S.paused || ex == null) return; S.paused = false; ex.resumeExerciseAsync(); vibrate(new long[]{0, 120, 100, 120}); say("Si riparte"); updateNotif(); notifyUi(); }

    private void stop() {
        if (S.recovering) { finishRecovery(); return; }   // FINE durante il recupero: salto la misura
        if (!S.running) { stopSelf(); return; }
        h.removeCallbacksAndMessages(null);
        stopAt = System.currentTimeMillis();
        if (S.activeSec % 5 != 0) addPoint();
        say(String.format(Locale.ITALY, "Corsa finita: %s chilometri in %d minuti", String.format(Locale.ITALY, "%.1f", S.km).replace(",", " virgola "), S.activeSec / 60)
            + (S.samples > 0 ? ", battito medio " + Math.round((double) S.sumHr / S.samples) : "") + ". Misuro il recupero per un minuto");
        frozen = summary();
        S.running = false; S.paused = false; S.recovering = true; S.recLeft = REC_SEC; recSec = 0; rec.clear();
        boolean fresh = System.currentTimeMillis() - S.lastBeat < 5000 && S.bpm > 0;
        if (fresh) rec.add(new int[]{ 0, S.bpm });
        vibrate(new long[]{0, 300, 150, 300});
        updateNotif(); notifyUi();
        h.postDelayed(tick, 1000);
    }

    /** Fine della misura del recupero (o salto): chiudo l'allenamento e mando tutto al telefono. */
    private void finishRecovery() {
        if (!S.recovering) return;
        h.removeCallbacksAndMessages(null);
        say("Recupero misurato, riepilogo inviato al telefono");
        S.recovering = false; S.finished = true; S.recLeft = 0;
        try { if (ex != null) ex.endExerciseAsync(); } catch (Exception ignored) {}
        stopStrap();
        try { if (wl != null && wl.isHeld()) wl.release(); } catch (Exception ignored) {}
        String json;
        try {
            JSONObject o = frozen != null ? frozen : summary();
            JSONArray r = new JSONArray(); for (int[] x : rec) r.put(new JSONArray().put(x[0]).put(x[1])); o.put("rec", r);
            json = o.toString();
        } catch (Exception e) { json = "{}"; }
        // il messaggio all'orologio ha un limite di circa 100 KB: se il percorso è lunghissimo lo alleggerisco
        if (json.length() > 90000) { try { JSONObject o = new JSONObject(json); o.put("tr", track(400)); json = o.toString(); } catch (Exception ignored) {} }
        // la corsa del piano è fatta: la prossima volta l'orologio parte da "Corsa libera" finché il telefono non ne manda un'altra
        getSharedPreferences("hf", MODE_PRIVATE).edit().putString("unsent", json).remove("plan").apply();
        sendToPhone(this, json);
        vibrate(new long[]{0, 200});
        notifyUi();
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE);
        // lascio il tempo di finire la frase prima di chiudere
        h.postDelayed(() -> { if (S.running || S.recovering) return; if (voice != null) { voice.shutdown(); voice = null; } stopSelf(); }, 8000);
    }

    private JSONObject summary() {
        JSONObject o = new JSONObject();
        try {
            o.put("title", S.title); o.put("startedAt", S.startedAt); o.put("seconds", S.activeSec);
            o.put("totalSec", Math.max(S.activeSec, ((stopAt > 0 ? stopAt : System.currentTimeMillis()) - S.startedAt) / 1000));
            o.put("km", Math.round(S.km * 100) / 100.0); o.put("kcal", Math.round(S.kcal));
            o.put("avgHr", S.samples > 0 ? Math.round((double) S.sumHr / S.samples) : 0); o.put("maxHr", S.maxHr);
            JSONArray z = new JSONArray(); for (long v : S.zoneSec) z.put(v); o.put("zoneSec", z);
            o.put("hrSrc", S.strapSec > 0 && S.watchSec > 0 ? "mixed" : S.strapSec > 0 ? "strap" : "watch");
            o.put("hrMax", S.hrMax);
            if (stepsTot >= 0) o.put("steps", stepsTot);
            if (elevGain >= 0) o.put("elevGain", Math.round(elevGain));
            if (elevLoss >= 0) o.put("elevLoss", Math.round(elevLoss));
            o.put("tr", track(900));
            if (ref != null) o.put("ref", ref);
            o.put("source", "watch");
        } catch (Exception ignored) {}
        return o;
    }

    /** Percorso a colonne (al massimo n punti: se sono di più ne tengo uno ogni k, più l'ultimo). */
    private JSONObject track(int n) {
        JSONObject t = new JSONObject();
        try {
            int k = Math.max(1, (int) Math.ceil(trk.size() / (double) n));
            String[] keys = {"t", "m", "h", "a", "s", "la", "lo"};
            JSONArray[] cols = new JSONArray[keys.length];
            for (int c = 0; c < keys.length; c++) cols[c] = new JSONArray();
            for (int i = 0; i < trk.size(); i++) {
                if (i % k != 0 && i != trk.size() - 1) continue;
                int[] p = trk.get(i);
                for (int c = 0; c < keys.length; c++) cols[c].put(p[c]);
            }
            for (int c = 0; c < keys.length; c++) t.put(keys[c], cols[c]);
        } catch (Exception ignored) {}
        return t;
    }

    /** Manda il riepilogo al telefono (se non è raggiungibile resta salvato e riprova all'apertura dell'app). */
    static void sendToPhone(Context ctx, String json) {
        final byte[] data = json.getBytes(StandardCharsets.UTF_8);
        Wearable.getNodeClient(ctx).getConnectedNodes().addOnSuccessListener(nodes -> {
            for (Node n : nodes) {
                Wearable.getMessageClient(ctx).sendMessage(n.getId(), "/healthfit/result", data)
                    .addOnSuccessListener(r -> ctx.getSharedPreferences("hf", MODE_PRIVATE).edit().remove("unsent").apply());
            }
        });
    }

    private void vibrate(long[] pat) {
        try { Vibrator vb = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE); if (vb == null) return;
            vb.vibrate(VibrationEffect.createWaveform(pat, -1)); } catch (Exception ignored) {}
    }
    static void notifyUi() { if (listener != null) { try { listener.onUpdate(); } catch (Exception ignored) {} } }

    private void createChannel() {
        NotificationChannel ch = new NotificationChannel(CHANNEL, "Corsa in corso", NotificationManager.IMPORTANCE_LOW);
        ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
    }
    private Notification notif(String text) {
        Intent open = new Intent(this, WatchActivity.class); open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new NotificationCompat.Builder(this, CHANNEL).setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("HealthFit · " + S.title).setContentText(text).setOngoing(true).setOnlyAlertOnce(true)
            .setContentIntent(pi).setCategory(NotificationCompat.CATEGORY_SERVICE).build();
    }
    private void updateNotif() {
        if (S.recovering) { ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).notify(NOTIF, notif("Recupero del battito: ancora " + S.recLeft + " s" + (S.bpm > 0 ? " · " + S.bpm + " bpm" : ""))); return; }
        long m = S.activeSec / 60, s = S.activeSec % 60;
        String t = (S.paused ? "⏸ " : "") + m + ":" + (s < 10 ? "0" : "") + s + (S.bpm > 0 ? " · " + S.bpm + " bpm" : "") + (S.km > 0.05 ? String.format(Locale.ITALY, " · %.2f km", S.km) : "");
        ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).notify(NOTIF, notif(t));
    }

    @Override public void onDestroy() { h.removeCallbacksAndMessages(null); if (S.running || S.recovering) stopStrap(); if (voice != null) voice.shutdown(); super.onDestroy(); }
}
