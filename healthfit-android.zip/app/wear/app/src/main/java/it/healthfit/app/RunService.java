package it.healthfit.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.ParcelUuid;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.core.app.ServiceCompat;
import androidx.core.content.ContextCompat;
import androidx.health.services.client.ExerciseClient;
import androidx.health.services.client.ExerciseUpdateCallback;
import androidx.health.services.client.HealthServices;
import androidx.health.services.client.data.Availability;
import androidx.health.services.client.data.CumulativeDataPoint;
import androidx.health.services.client.data.DataPointContainer;
import androidx.health.services.client.data.DataType;
import androidx.health.services.client.data.ExerciseConfig;
import androidx.health.services.client.data.ExerciseLapSummary;
import androidx.health.services.client.data.ExerciseType;
import androidx.health.services.client.data.ExerciseUpdate;
import androidx.health.services.client.data.SampleDataPoint;

import com.google.android.gms.wearable.Node;
import com.google.android.gms.wearable.Wearable;
import com.google.common.util.concurrent.FutureCallback;
import com.google.common.util.concurrent.Futures;

import org.json.JSONArray;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

/**
 * Registra la corsa sull'orologio (GPS del Galaxy Watch), vibra fuori zona e a ogni km, poi manda il riepilogo al telefono.
 * Battito: dalla fascia cardio se è collegata e manda dati, altrimenti dal sensore dell'orologio (e ci torna da sola se la fascia si stacca).
 */
public class RunService extends Service {
    public static final String ACTION_START = "hf.START", ACTION_PAUSE = "hf.PAUSE", ACTION_RESUME = "hf.RESUME", ACTION_STOP = "hf.STOP";
    static final String CHANNEL = "hf_watch_run";
    static final int NOTIF = 5151;
    static final UUID HR_SERVICE = UUID.fromString("0000180d-0000-1000-8000-00805f9b34fb");
    static final UUID HR_MEASURE = UUID.fromString("00002a37-0000-1000-8000-00805f9b34fb");
    static final UUID CCC = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");

    public static final class State {
        public boolean running, paused, finished;
        public String title = "Corsa", error = "";
        public int bpm, maxHr, lo = -1, hi = -1, hrMax = 185;
        public long samples, sumHr, activeSec, lastBeat, startedAt;
        public double km, kcal;
        public double paceNow;               // ritmo degli ultimi ~30 secondi (s/km), 0 = non disponibile
        public long[] zoneSec = new long[5];
        public String hrSrc = "";            // "fascia" o "orologio": da dove arriva il battito mostrato
        public String strap = "";            // stato della fascia: "", "cerco…", "collegata", "non trovata"…
        public String strapName = "";
        public long strapSec, watchSec;      // secondi con battito dalla fascia e dal polso
    }
    public static final State S = new State();
    public interface Listener { void onUpdate(); }
    public static Listener listener;

    private ExerciseClient ex;
    private final Handler h = new Handler(Looper.getMainLooper());
    private PowerManager.WakeLock wl;
    private long outSince = 0, lastAlert = 0;
    private int lastKm = 0;
    private JSONObject ref = null;
    // battito dalle due sorgenti (scritto anche dai thread del Bluetooth)
    private volatile int strapBpm = 0, wristBpm = 0;
    private volatile long strapAt = 0, wristAt = 0;
    // ritmo attuale: tempo e km degli ultimi 30 secondi di corsa
    private final long[] rSec = new long[31];
    private final double[] rKm = new double[31];
    private int rN = 0, rPos = 0;
    // fascia cardio
    private BluetoothGatt gatt;
    private BluetoothDevice strapDev;
    private BluetoothLeScanner scanner;
    private boolean scanning = false;
    private String strapAddr = "";
    private int reconnects = 0;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String a = intent != null ? intent.getAction() : null;
        if (ACTION_START.equals(a)) start();
        else if (ACTION_PAUSE.equals(a)) pause();
        else if (ACTION_RESUME.equals(a)) resume();
        else if (ACTION_STOP.equals(a)) stop();
        return START_NOT_STICKY;
    }

    private void start() {
        if (S.running) return;
        SharedPreferences p = getSharedPreferences("hf", MODE_PRIVATE);
        ref = null;
        try {
            JSONObject plan = new JSONObject(p.getString("plan", "{}"));
            S.title = plan.optString("title", "Corsa"); S.lo = plan.optInt("lo", -1); S.hi = plan.optInt("hi", -1); S.hrMax = plan.optInt("hrMax", 185);
            ref = plan.optJSONObject("ref");
        } catch (Exception e) { S.title = "Corsa"; }
        if (S.title.isEmpty()) S.title = "Corsa";
        S.running = true; S.paused = false; S.finished = false; S.error = ""; S.bpm = 0; S.maxHr = 0; S.samples = 0; S.sumHr = 0; S.activeSec = 0; S.km = 0; S.kcal = 0;
        S.zoneSec = new long[5]; S.startedAt = System.currentTimeMillis(); S.paceNow = 0; S.hrSrc = ""; S.strapSec = 0; S.watchSec = 0; S.lastBeat = 0;
        lastKm = 0; outSince = 0; rN = 0; rPos = 0; strapBpm = 0; wristBpm = 0; strapAt = 0; wristAt = 0; reconnects = 0;
        strapAddr = p.getString("hrAddr", ""); S.strapName = p.getString("hrName", "");

        createChannel();
        int type = 0;
        if (Build.VERSION.SDK_INT >= 34) {
            type = ServiceInfo.FOREGROUND_SERVICE_TYPE_HEALTH | ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION;
            if (btAllowed()) type |= ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE;
        } else if (Build.VERSION.SDK_INT >= 29) type = ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION;
        ServiceCompat.startForeground(this, NOTIF, notif("Avvio…"), type);

        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "healthfit:watchrun");
        wl.acquire(6 * 60 * 60 * 1000L);

        ex = HealthServices.getClient(this).getExerciseClient();
        ex.setUpdateCallback(cb);
        Set<DataType<?, ?>> types = new HashSet<>();
        types.add(DataType.HEART_RATE_BPM);
        types.add(DataType.DISTANCE_TOTAL);
        types.add(DataType.CALORIES_TOTAL);
        ExerciseConfig cfg = new ExerciseConfig.Builder(ExerciseType.RUNNING)
            .setDataTypes(types).setIsAutoPauseAndResumeEnabled(false).setIsGpsEnabled(true).build();
        Futures.addCallback(ex.startExerciseAsync(cfg), new FutureCallback<Void>() {
            @Override public void onSuccess(Void v) { vibrate(new long[]{0, 200}); }
            @Override public void onFailure(@NonNull Throwable t) { S.error = "Non riesco ad avviare: " + t.getMessage(); notifyUi(); }
        }, ContextCompat.getMainExecutor(this));
        startStrap();
        h.removeCallbacks(tick); h.postDelayed(tick, 1000);
    }

    private final ExerciseUpdateCallback cb = new ExerciseUpdateCallback() {
        @Override public void onExerciseUpdateReceived(@NonNull ExerciseUpdate update) {
            DataPointContainer m = update.getLatestMetrics();
            List<SampleDataPoint<Double>> hr = m.getData(DataType.HEART_RATE_BPM);
            if (!hr.isEmpty()) { double b = hr.get(hr.size() - 1).getValue(); if (b > 25 && b < 240) { wristBpm = (int) Math.round(b); wristAt = System.currentTimeMillis(); pickHr(); } }
            CumulativeDataPoint<Double> d = m.getData(DataType.DISTANCE_TOTAL);
            if (d != null) S.km = d.getTotal() / 1000.0;
            CumulativeDataPoint<Double> c = m.getData(DataType.CALORIES_TOTAL);
            if (c != null) S.kcal = c.getTotal();
        }
        @Override public void onLapSummaryReceived(@NonNull ExerciseLapSummary s) {}
        @Override public void onRegistered() {}
        @Override public void onRegistrationFailed(@NonNull Throwable t) { S.error = "Health Services: " + t.getMessage(); notifyUi(); }
        @Override public void onAvailabilityChanged(@NonNull DataType<?, ?> type, @NonNull Availability a) {}
    };

    /** Sceglie il battito da mostrare: la fascia se ha mandato un dato negli ultimi 5 secondi, altrimenti il polso. */
    private void pickHr() {
        long now = System.currentTimeMillis();
        if (strapBpm > 0 && now - strapAt < 5000) { S.bpm = strapBpm; S.lastBeat = strapAt; S.hrSrc = "fascia"; }
        else if (wristBpm > 0 && now - wristAt < 5000) { S.bpm = wristBpm; S.lastBeat = wristAt; S.hrSrc = "orologio"; }
    }

    // ---------- fascia cardio (servizio Bluetooth standard Heart Rate) ----------
    private boolean btAllowed() {
        if (Build.VERSION.SDK_INT >= 31)
            return checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
                && checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED;
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    /** Cerca la fascia salvata sul telefono (o, se non ce n'è una, la prima fascia cardio accesa vicino). */
    @SuppressLint("MissingPermission")
    private void startStrap() {
        if (!S.running || gatt != null || scanning) return;
        if (!btAllowed()) { S.strap = "Bluetooth non permesso: battito dal polso"; return; }
        try {
            BluetoothManager bm = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
            BluetoothAdapter ad = bm != null ? bm.getAdapter() : null;
            if (ad == null || !ad.isEnabled()) { S.strap = "Bluetooth spento: battito dal polso"; return; }
            scanner = ad.getBluetoothLeScanner();
            if (scanner == null) { S.strap = ""; return; }
            ScanFilter f = new ScanFilter.Builder().setServiceUuid(new ParcelUuid(HR_SERVICE)).build();
            ScanSettings st = new ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build();
            scanner.startScan(Collections.singletonList(f), st, scanCb);
            scanning = true; S.strap = "cerco la fascia…";
            h.postDelayed(scanTimeout, 15000);
        } catch (Exception e) { scanning = false; S.strap = ""; }
    }

    private final Runnable scanTimeout = new Runnable() { @SuppressLint("MissingPermission") @Override public void run() {
        stopScan();
        if (!S.running || gatt != null) return;
        // la fascia salvata a volte non si annuncia nella ricerca: provo a collegarla direttamente
        if (!strapAddr.isEmpty()) {
            try {
                BluetoothManager bm = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
                connect(bm.getAdapter().getRemoteDevice(strapAddr));
                return;
            } catch (Exception ignored) {}
        }
        S.strap = "fascia non trovata: battito dal polso";
        h.postDelayed(() -> startStrap(), 45000);   // riprova: magari la indossi dopo
    }};

    private final ScanCallback scanCb = new ScanCallback() {
        @Override public void onScanResult(int type, ScanResult r) {
            BluetoothDevice dev = r.getDevice();
            if (dev == null || gatt != null) return;
            if (!strapAddr.isEmpty() && !strapAddr.equalsIgnoreCase(dev.getAddress())) return;
            h.post(() -> { if (gatt == null && S.running) { stopScan(); h.removeCallbacks(scanTimeout); connect(dev); } });
        }
        @Override public void onScanFailed(int code) { scanning = false; }
    };

    @SuppressLint("MissingPermission")
    private void stopScan() {
        if (!scanning) return; scanning = false;
        try { if (scanner != null) scanner.stopScan(scanCb); } catch (Exception ignored) {}
    }

    @SuppressLint("MissingPermission")
    private void connect(BluetoothDevice dev) {
        try {
            strapDev = dev;
            try { String n = dev.getName(); if (n != null && !n.isEmpty()) S.strapName = n; } catch (Exception ignored) {}
            if (S.strapName.isEmpty()) S.strapName = "Fascia";
            if (gatt != null) { try { gatt.close(); } catch (Exception ignored) {} }
            S.strap = "collego " + S.strapName + "…";
            gatt = dev.connectGatt(this, false, gcb, BluetoothDevice.TRANSPORT_LE);
        } catch (Exception e) { gatt = null; S.strap = "fascia non collegata: battito dal polso"; }
    }

    private final BluetoothGattCallback gcb = new BluetoothGattCallback() {
        @SuppressLint("MissingPermission")
        @Override public void onConnectionStateChange(BluetoothGatt g, int status, int newState) {
            if (newState == BluetoothProfile.STATE_CONNECTED) { reconnects = 0; S.strap = S.strapName + " collegata"; g.discoverServices(); }
            else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                h.post(() -> {
                    try { g.close(); } catch (Exception ignored) {}
                    if (gatt == g) gatt = null;
                    if (!S.running) return;
                    S.strap = "fascia persa: battito dal polso";
                    if (reconnects < 40 && strapDev != null) { reconnects++;
                        h.postDelayed(() -> { if (S.running && gatt == null) connect(strapDev); }, Math.min(15000, 1500L * reconnects)); }
                });
            }
        }
        @SuppressLint("MissingPermission")
        @SuppressWarnings("deprecation")
        @Override public void onServicesDiscovered(BluetoothGatt g, int status) {
            BluetoothGattService s = g.getService(HR_SERVICE); if (s == null) return;
            BluetoothGattCharacteristic c = s.getCharacteristic(HR_MEASURE); if (c == null) return;
            g.setCharacteristicNotification(c, true);
            BluetoothGattDescriptor d = c.getDescriptor(CCC);
            if (d != null) {
                if (Build.VERSION.SDK_INT >= 33) g.writeDescriptor(d, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                else { d.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE); g.writeDescriptor(d); }
            }
        }
        @Override public void onCharacteristicChanged(@NonNull BluetoothGatt g, @NonNull BluetoothGattCharacteristic c, @NonNull byte[] v) { parse(v); }
        @SuppressWarnings("deprecation")
        @Override public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic c) { if (Build.VERSION.SDK_INT < 33) parse(c.getValue()); }
    };

    private void parse(byte[] v) {
        if (v == null || v.length < 2) return;
        int flags = v[0] & 0xff;
        int bpm = (flags & 1) != 0 && v.length >= 3 ? ((v[1] & 0xff) | ((v[2] & 0xff) << 8)) : (v[1] & 0xff);
        if (bpm > 25 && bpm < 240) { strapBpm = bpm; strapAt = System.currentTimeMillis(); }
    }

    @SuppressLint("MissingPermission")
    private void stopStrap() {
        stopScan(); h.removeCallbacks(scanTimeout);
        try { if (gatt != null) { gatt.disconnect(); gatt.close(); } } catch (Exception ignored) {}
        gatt = null; strapDev = null;
    }

    // ---------- ogni secondo ----------
    private int zoneOf(int b) { double pc = b / (double) S.hrMax; return pc < 0.6 ? 0 : pc < 0.7 ? 1 : pc < 0.8 ? 2 : pc < 0.9 ? 3 : 4; }

    private final Runnable tick = new Runnable() { @Override public void run() {
        if (!S.running) return;
        pickHr();
        if (!S.paused) {
            S.activeSec++;
            if (System.currentTimeMillis() - S.lastBeat < 5000 && S.bpm > 0) {
                int z = zoneOf(S.bpm); S.sumHr += S.bpm; S.samples++; S.maxHr = Math.max(S.maxHr, S.bpm); S.zoneSec[z]++;
                if ("fascia".equals(S.hrSrc)) S.strapSec++; else S.watchSec++;
                checkZone(z);
            }
            int k = (int) Math.floor(S.km);
            if (k > lastKm && k >= 1) { lastKm = k; vibrate(new long[]{0, 120, 120, 120}); }
            updatePace();
        }
        if (S.activeSec % 5 == 0) updateNotif();
        notifyUi();
        h.postDelayed(this, 1000);
    }};

    /** Ritmo attuale: distanza percorsa negli ultimi 30 secondi di corsa (le pause non contano). */
    private void updatePace() {
        rSec[rPos] = S.activeSec; rKm[rPos] = S.km; rPos = (rPos + 1) % rSec.length; if (rN < rSec.length) rN++;
        int oldest = rN < rSec.length ? 0 : rPos;
        long ds = S.activeSec - rSec[oldest]; double dk = S.km - rKm[oldest];
        S.paceNow = ds >= 10 && dk >= 0.02 ? ds / dk : 0;   // sotto 20 metri in 30 secondi: fermo, nessun ritmo
    }

    private void checkZone(int z) {
        if (S.lo < 0) return;
        long now = System.currentTimeMillis();
        boolean out = z > S.hi || (S.lo >= 3 && z < S.lo);
        if (!out) { outSince = 0; return; }
        if (outSince == 0) outSince = now;
        long limit = z > S.hi ? 20000 : 60000;
        if (now - outSince > limit && now - lastAlert > 45000) {
            lastAlert = now;
            // sopra la zona: due vibrazioni lunghe · sotto la zona: tre brevi
            vibrate(z > S.hi ? new long[]{0, 500, 200, 500} : new long[]{0, 150, 120, 150, 120, 150});
        }
    }

    private void pause() { if (!S.running || S.paused || ex == null) return; S.paused = true; S.paceNow = 0; rN = 0; rPos = 0; ex.pauseExerciseAsync(); updateNotif(); notifyUi(); }
    private void resume() { if (!S.running || !S.paused || ex == null) return; S.paused = false; ex.resumeExerciseAsync(); updateNotif(); notifyUi(); }

    private void stop() {
        if (!S.running) { stopSelf(); return; }
        S.running = false; S.finished = true; h.removeCallbacksAndMessages(null);
        try { if (ex != null) ex.endExerciseAsync(); } catch (Exception ignored) {}
        stopStrap();
        try { if (wl != null && wl.isHeld()) wl.release(); } catch (Exception ignored) {}
        String json = summaryJson();
        // la corsa del piano è fatta: la prossima volta l'orologio parte da "Corsa libera" finché il telefono non ne manda un'altra
        getSharedPreferences("hf", MODE_PRIVATE).edit().putString("unsent", json).remove("plan").apply();
        sendToPhone(this, json);
        vibrate(new long[]{0, 300, 150, 300});
        notifyUi();
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    private String summaryJson() {
        try {
            JSONObject o = new JSONObject();
            o.put("title", S.title); o.put("startedAt", S.startedAt); o.put("seconds", S.activeSec);
            o.put("km", Math.round(S.km * 100) / 100.0); o.put("kcal", Math.round(S.kcal));
            o.put("avgHr", S.samples > 0 ? Math.round((double) S.sumHr / S.samples) : 0); o.put("maxHr", S.maxHr);
            JSONArray z = new JSONArray(); for (long v : S.zoneSec) z.put(v); o.put("zoneSec", z);
            o.put("hrSrc", S.strapSec > 0 && S.watchSec > 0 ? "mixed" : S.strapSec > 0 ? "strap" : "watch");
            if (ref != null) o.put("ref", ref);
            o.put("source", "watch");
            return o.toString();
        } catch (Exception e) { return "{}"; }
    }

    /** Manda il riepilogo al telefono (se non è raggiungibile resta salvato e riprova all'apertura dell'app). */
    static void sendToPhone(Context ctx, String json) {
        final byte[] data = json.getBytes(StandardCharsets.UTF_8);
        Wearable.getNodeClient(ctx).getConnectedNodes().addOnSuccessListener(nodes -> {
            for (Node n : nodes) {
                Wearable.getMessageClient(ctx).sendMessage(n.getId(), "/healthfit/result", data)
                    .addOnSuccessListener(r -> ctx.getSharedPreferences("hf", MODE_PRIVATE).edit().remove("unsent").apply());
            }
        });
    }

    private void vibrate(long[] pat) {
        try { Vibrator vb = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE); if (vb == null) return;
            vb.vibrate(VibrationEffect.createWaveform(pat, -1)); } catch (Exception ignored) {}
    }
    static void notifyUi() { if (listener != null) { try { listener.onUpdate(); } catch (Exception ignored) {} } }

    private void createChannel() {
        NotificationChannel ch = new NotificationChannel(CHANNEL, "Corsa in corso", NotificationManager.IMPORTANCE_LOW);
        ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
    }
    private Notification notif(String text) {
        Intent open = new Intent(this, WatchActivity.class); open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new NotificationCompat.Builder(this, CHANNEL).setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("HealthFit · " + S.title).setContentText(text).setOngoing(true).setOnlyAlertOnce(true)
            .setContentIntent(pi).setCategory(NotificationCompat.CATEGORY_SERVICE).build();
    }
    private void updateNotif() {
        long m = S.activeSec / 60, s = S.activeSec % 60;
        String t = (S.paused ? "⏸ " : "") + m + ":" + (s < 10 ? "0" : "") + s + (S.bpm > 0 ? " · " + S.bpm + " bpm" : "") + (S.km > 0.05 ? String.format(Locale.ITALY, " · %.2f km", S.km) : "");
        ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).notify(NOTIF, notif(t));
    }

    @Override public void onDestroy() { h.removeCallbacksAndMessages(null); if (S.running) stopStrap(); super.onDestroy(); }
}
