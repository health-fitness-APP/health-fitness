package it.healthfit.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.core.app.ServiceCompat;
import androidx.core.content.ContextCompat;
import androidx.health.services.client.ExerciseClient;
import androidx.health.services.client.ExerciseUpdateCallback;
import androidx.health.services.client.HealthServices;
import androidx.health.services.client.data.Availability;
import androidx.health.services.client.data.CumulativeDataPoint;
import androidx.health.services.client.data.DataPointContainer;
import androidx.health.services.client.data.DataType;
import androidx.health.services.client.data.ExerciseConfig;
import androidx.health.services.client.data.ExerciseLapSummary;
import androidx.health.services.client.data.ExerciseType;
import androidx.health.services.client.data.ExerciseUpdate;
import androidx.health.services.client.data.SampleDataPoint;

import com.google.android.gms.wearable.Node;
import com.google.android.gms.wearable.Wearable;
import com.google.common.util.concurrent.FutureCallback;
import com.google.common.util.concurrent.Futures;

import org.json.JSONArray;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Registra la corsa sull'orologio (battito e GPS del Galaxy Watch), vibra fuori zona e a ogni km, poi manda il riepilogo al telefono. */
public class RunService extends Service {
    public static final String ACTION_START = "hf.START", ACTION_PAUSE = "hf.PAUSE", ACTION_RESUME = "hf.RESUME", ACTION_STOP = "hf.STOP";
    static final String CHANNEL = "hf_watch_run";
    static final int NOTIF = 5151;

    public static final class State {
        public boolean running, paused, finished;
        public String title = "Corsa", error = "";
        public int bpm, maxHr, lo = -1, hi = -1, hrMax = 185;
        public long samples, sumHr, activeSec, lastBeat, startedAt;
        public double km, kcal;
        public long[] zoneSec = new long[5];
    }
    public static final State S = new State();
    public interface Listener { void onUpdate(); }
    public static Listener listener;

    private ExerciseClient ex;
    private final Handler h = new Handler(Looper.getMainLooper());
    private PowerManager.WakeLock wl;
    private long outSince = 0, lastAlert = 0;
    private int lastKm = 0;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String a = intent != null ? intent.getAction() : null;
        if (ACTION_START.equals(a)) start();
        else if (ACTION_PAUSE.equals(a)) pause();
        else if (ACTION_RESUME.equals(a)) resume();
        else if (ACTION_STOP.equals(a)) stop();
        return START_NOT_STICKY;
    }

    private void start() {
        if (S.running) return;
        SharedPreferences p = getSharedPreferences("hf", MODE_PRIVATE);
        try {
            JSONObject plan = new JSONObject(p.getString("plan", "{}"));
            S.title = plan.optString("title", "Corsa"); S.lo = plan.optInt("lo", -1); S.hi = plan.optInt("hi", -1); S.hrMax = plan.optInt("hrMax", 185);
        } catch (Exception e) { S.title = "Corsa"; }
        S.running = true; S.paused = false; S.finished = false; S.error = ""; S.bpm = 0; S.maxHr = 0; S.samples = 0; S.sumHr = 0; S.activeSec = 0; S.km = 0; S.kcal = 0;
        S.zoneSec = new long[5]; S.startedAt = System.currentTimeMillis(); lastKm = 0; outSince = 0;

        createChannel();
        int type = 0;
        if (Build.VERSION.SDK_INT >= 34) type = ServiceInfo.FOREGROUND_SERVICE_TYPE_HEALTH | ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION;
        else if (Build.VERSION.SDK_INT >= 29) type = ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION;
        ServiceCompat.startForeground(this, NOTIF, notif("Avvio…"), type);

        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "healthfit:watchrun");
        wl.acquire(6 * 60 * 60 * 1000L);

        ex = HealthServices.getClient(this).getExerciseClient();
        ex.setUpdateCallback(cb);
        Set<DataType<?, ?>> types = new HashSet<>();
        types.add(DataType.HEART_RATE_BPM);
        types.add(DataType.DISTANCE_TOTAL);
        types.add(DataType.CALORIES_TOTAL);
        ExerciseConfig cfg = new ExerciseConfig.Builder(ExerciseType.RUNNING)
            .setDataTypes(types).setIsAutoPauseAndResumeEnabled(false).setIsGpsEnabled(true).build();
        Futures.addCallback(ex.startExerciseAsync(cfg), new FutureCallback<Void>() {
            @Override public void onSuccess(Void v) { vibrate(new long[]{0, 200}); }
            @Override public void onFailure(@NonNull Throwable t) { S.error = "Non riesco ad avviare: " + t.getMessage(); notifyUi(); }
        }, ContextCompat.getMainExecutor(this));
        h.removeCallbacks(tick); h.postDelayed(tick, 1000);
    }

    private final ExerciseUpdateCallback cb = new ExerciseUpdateCallback() {
        @Override public void onExerciseUpdateReceived(@NonNull ExerciseUpdate update) {
            DataPointContainer m = update.getLatestMetrics();
            List<SampleDataPoint<Double>> hr = m.getData(DataType.HEART_RATE_BPM);
            if (!hr.isEmpty()) { double b = hr.get(hr.size() - 1).getValue(); if (b > 25 && b < 240) { S.bpm = (int) Math.round(b); S.lastBeat = System.currentTimeMillis(); } }
            CumulativeDataPoint<Double> d = m.getData(DataType.DISTANCE_TOTAL);
            if (d != null) S.km = d.getTotal() / 1000.0;
            CumulativeDataPoint<Double> c = m.getData(DataType.CALORIES_TOTAL);
            if (c != null) S.kcal = c.getTotal();
        }
        @Override public void onLapSummaryReceived(@NonNull ExerciseLapSummary s) {}
        @Override public void onRegistered() {}
        @Override public void onRegistrationFailed(@NonNull Throwable t) { S.error = "Health Services: " + t.getMessage(); notifyUi(); }
        @Override public void onAvailabilityChanged(@NonNull DataType<?, ?> type, @NonNull Availability a) {}
    };

    private int zoneOf(int b) { double pc = b / (double) S.hrMax; return pc < 0.6 ? 0 : pc < 0.7 ? 1 : pc < 0.8 ? 2 : pc < 0.9 ? 3 : 4; }

    private final Runnable tick = new Runnable() { @Override public void run() {
        if (!S.running) return;
        if (!S.paused) {
            S.activeSec++;
            if (System.currentTimeMillis() - S.lastBeat < 5000 && S.bpm > 0) {
                int z = zoneOf(S.bpm); S.sumHr += S.bpm; S.samples++; S.maxHr = Math.max(S.maxHr, S.bpm); S.zoneSec[z]++;
                checkZone(z);
            }
            int k = (int) Math.floor(S.km);
            if (k > lastKm && k >= 1) { lastKm = k; vibrate(new long[]{0, 120, 120, 120}); }
        }
        if (S.activeSec % 5 == 0) updateNotif();
        notifyUi();
        h.postDelayed(this, 1000);
    }};

    private void checkZone(int z) {
        if (S.lo < 0) return;
        long now = System.currentTimeMillis();
        boolean out = z > S.hi || (S.lo >= 3 && z < S.lo);
        if (!out) { outSince = 0; return; }
        if (outSince == 0) outSince = now;
        long limit = z > S.hi ? 20000 : 60000;
        if (now - outSince > limit && now - lastAlert > 45000) {
            lastAlert = now;
            // sopra la zona: due vibrazioni lunghe · sotto la zona: tre brevi
            vibrate(z > S.hi ? new long[]{0, 500, 200, 500} : new long[]{0, 150, 120, 150, 120, 150});
        }
    }

    private void pause() { if (!S.running || S.paused || ex == null) return; S.paused = true; ex.pauseExerciseAsync(); updateNotif(); notifyUi(); }
    private void resume() { if (!S.running || !S.paused || ex == null) return; S.paused = false; ex.resumeExerciseAsync(); updateNotif(); notifyUi(); }

    private void stop() {
        if (!S.running) { stopSelf(); return; }
        S.running = false; S.finished = true; h.removeCallbacks(tick);
        try { if (ex != null) ex.endExerciseAsync(); } catch (Exception ignored) {}
        try { if (wl != null && wl.isHeld()) wl.release(); } catch (Exception ignored) {}
        String json = summaryJson();
        getSharedPreferences("hf", MODE_PRIVATE).edit().putString("unsent", json).apply();
        sendToPhone(this, json);
        vibrate(new long[]{0, 300, 150, 300});
        notifyUi();
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    private String summaryJson() {
        try {
            JSONObject o = new JSONObject();
            o.put("title", S.title); o.put("startedAt", S.startedAt); o.put("seconds", S.activeSec);
            o.put("km", Math.round(S.km * 100) / 100.0); o.put("kcal", Math.round(S.kcal));
            o.put("avgHr", S.samples > 0 ? Math.round((double) S.sumHr / S.samples) : 0); o.put("maxHr", S.maxHr);
            JSONArray z = new JSONArray(); for (long v : S.zoneSec) z.put(v); o.put("zoneSec", z);
            o.put("source", "watch");
            return o.toString();
        } catch (Exception e) { return "{}"; }
    }

    /** Manda il riepilogo al telefono (se non è raggiungibile resta salvato e riprova all'apertura dell'app). */
    static void sendToPhone(Context ctx, String json) {
        final byte[] data = json.getBytes(StandardCharsets.UTF_8);
        Wearable.getNodeClient(ctx).getConnectedNodes().addOnSuccessListener(nodes -> {
            for (Node n : nodes) {
                Wearable.getMessageClient(ctx).sendMessage(n.getId(), "/healthfit/result", data)
                    .addOnSuccessListener(r -> ctx.getSharedPreferences("hf", MODE_PRIVATE).edit().remove("unsent").apply());
            }
        });
    }

    private void vibrate(long[] pat) {
        try { Vibrator vb = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE); if (vb == null) return;
            vb.vibrate(VibrationEffect.createWaveform(pat, -1)); } catch (Exception ignored) {}
    }
    private void notifyUi() { if (listener != null) { try { listener.onUpdate(); } catch (Exception ignored) {} } }

    private void createChannel() {
        NotificationChannel ch = new NotificationChannel(CHANNEL, "Corsa in corso", NotificationManager.IMPORTANCE_LOW);
        ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
    }
    private Notification notif(String text) {
        Intent open = new Intent(this, WatchActivity.class); open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new NotificationCompat.Builder(this, CHANNEL).setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("HealthFit · " + S.title).setContentText(text).setOngoing(true).setOnlyAlertOnce(true)
            .setContentIntent(pi).setCategory(NotificationCompat.CATEGORY_SERVICE).build();
    }
    private void updateNotif() {
        long m = S.activeSec / 60, s = S.activeSec % 60;
        String t = (S.paused ? "⏸ " : "") + m + ":" + (s < 10 ? "0" : "") + s + (S.bpm > 0 ? " · " + S.bpm + " bpm" : "") + (S.km > 0.05 ? String.format(Locale.ITALY, " · %.2f km", S.km) : "");
        ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).notify(NOTIF, notif(t));
    }

    @Override public void onDestroy() { h.removeCallbacks(tick); super.onDestroy(); }
}
