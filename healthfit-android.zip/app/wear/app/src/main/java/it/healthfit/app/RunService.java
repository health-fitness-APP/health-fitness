package it.healthfit.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.ParcelUuid;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.core.app.ServiceCompat;
import androidx.core.content.ContextCompat;
import androidx.health.services.client.ExerciseClient;
import androidx.health.services.client.ExerciseUpdateCallback;
import androidx.health.services.client.HealthServices;
import androidx.health.services.client.data.Availability;
import androidx.health.services.client.data.CumulativeDataPoint;
import androidx.health.services.client.data.DataPointContainer;
import androidx.health.services.client.data.DataType;
import androidx.health.services.client.data.ExerciseCapabilities;
import androidx.health.services.client.data.ExerciseConfig;
import androidx.health.services.client.data.ExerciseLapSummary;
import androidx.health.services.client.data.ExerciseType;
import androidx.health.services.client.data.ExerciseUpdate;
import androidx.health.services.client.data.LocationData;
import androidx.health.services.client.data.SampleDataPoint;

import com.google.android.gms.wearable.Node;
import com.google.android.gms.wearable.Wearable;
import com.google.common.util.concurrent.FutureCallback;
import com.google.common.util.concurrent.Futures;

import org.json.JSONArray;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

/**
 * Registra la corsa sull'orologio (GPS del Galaxy Watch), vibra fuori zona e a ogni km, poi manda il riepilogo al telefono.
 * Battito: dalla fascia cardio se è collegata e manda dati, altrimenti dal sensore dell'orologio (e ci torna da sola se la fascia si stacca).
 * Ogni 5 secondi salva un punto del percorso (tempo, metri, battito, altitudine, passi, posizione) per il riepilogo sul telefono;
 * dopo FINE misura per un minuto il recupero del battito, poi manda tutto.
 */
public class RunService extends Service {
    public static final String ACTION_START = "hf.START", ACTION_PAUSE = "hf.PAUSE", ACTION_RESUME = "hf.RESUME", ACTION_STOP = "hf.STOP", ACTION_TECH = "hf.TECH";
    static final String CHANNEL = "hf_watch_run";
    static final int NOTIF = 5151;
    static final UUID HR_SERVICE = UUID.fromString("0000180d-0000-1000-8000-00805f9b34fb");
    static final UUID HR_MEASURE = UUID.fromString("00002a37-0000-1000-8000-00805f9b34fb");
    static final UUID CCC = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");

    public static final class State {
        public boolean running, paused, finished;
        public boolean autoPaused;           // fermo (semaforo, laccio): il tempo non conta finché non riparte
        public String title = "Corsa", error = "";
        public int bpm, maxHr, lo = -1, hi = -1, hrMax = 185;
        public long samples, sumHr, activeSec, lastBeat, startedAt;
        public double km, kcal;
        public double paceNow;               // ritmo degli ultimi ~30 secondi (s/km), 0 = non disponibile
        public long[] zoneSec = new long[5];
        public String hrSrc = "";            // "fascia" o "orologio": da dove arriva il battito mostrato
        public String strap = "";            // stato della fascia: "", "cerco…", "collegata", "non trovata"…
        public String strapName = "";
        public long strapSec, watchSec;      // secondi con battito dalla fascia e dal polso
        public boolean techOffer, drill;     // tecnica di corsa: proposta aperta (tocca lo schermo) / esercizi in corso
        public boolean painAsked;            // a fine corsa: ha già risposto a «fastidi?»
        public boolean recovering;           // dopo FINE: misuro il recupero del battito
        public int recLeft;                  // secondi di recupero che mancano
        public long steps;
        public String seg = "";              // fase in corso e tipo di corsa, es. "Riscaldamento – Lungo"
        public String segInfo = "";          // es. "ancora 2:10 · obiettivo 6:40/km"
        public String runType = "";
        public int hrLoB, hrHiB;             // battiti della zona obiettivo (0 = nessun limite)
        public double target;                // ritmo obiettivo della fase (s/km), 0 = nessuno
        // dati di ogni fase (riscaldamento, allenamento…): tempo, km, somma e numero dei battiti
        public String[] phName = new String[0];
        public long[] phSec = new long[0], phHrSum = new long[0], phHrN = new long[0];
        public double[] phKm = new double[0];
        public int phIdx = 0;
        public double lastKmVal = 0;         // km a cui è iniziata la fase in corso (per i km della fase)
    }
    public static final State S = new State();
    public interface Listener { void onUpdate(); }
    public static Listener listener;

    private ExerciseClient ex;
    private final Handler h = new Handler(Looper.getMainLooper());
    private PowerManager.WakeLock wl;
    private long outSince = 0, lastAlert = 0;
    private int lastKm = 0;
    private JSONObject ref = null;
    // battito dalle due sorgenti (scritto anche dai thread del Bluetooth)
    private volatile int strapBpm = 0, wristBpm = 0;
    private volatile long strapAt = 0, wristAt = 0;
    // ritmo attuale: tempo e km degli ultimi 30 secondi di corsa
    private final long[] rSec = new long[31];
    private final double[] rKm = new double[31];
    private int rN = 0, rPos = 0;
    // fascia cardio
    private BluetoothGatt gatt;
    private BluetoothDevice strapDev;
    private BluetoothLeScanner scanner;
    private boolean scanning = false;
    private String strapAddr = "";
    private int reconnects = 0;
    private Voice voice;
    private RunDynamics dyn;   // accelerometro: contatto, volo, asimmetria e regolarità dei passi
    // percorso e dati per il riepilogo
    static final int REC_SEC = 60;
    private final ArrayList<int[]> trk = new ArrayList<>();   // {secondi, metri, bpm, altitudine, passi, lat*1e5, lon*1e5}
    private final ArrayList<int[]> rec = new ArrayList<>();   // {secondi dopo FINE, bpm}
    private volatile double lat = 0, lon = 0, alt = Double.NaN, baro = Double.NaN, elevGain = -1, elevLoss = -1;
    private volatile long stepsTot = -1;
    private long stopAt = 0, recSec = 0;
    private JSONObject frozen = null;
    // fasi della seduta (riscaldamento, allenamento, recuperi, defaticamento) e ritmo obiettivo
    private JSONArray segs = null;
    private int segIdx = 0;
    private long segStartSec = 0, lastKmSec = 0;
    private double segStartKm = 0, planPace = 0;
    // obiettivo della seduta (km o minuti) e avvisi già dati al 30, 50, 80 e 100%
    private double goalKm = 0, goalMin = 0;
    private int goalSeg = -1;   // fase "obiettivo" su cui contare le percentuali (riscaldamento escluso)
    private int goalStep = 0;
    // ripetute/scatti: le percentuali 30, 50, 80% si contano sul singolo tratto veloce in corso
    private boolean perRep = false;
    private int repSeg = -1, repStep = 0;
    // defaticamento come Samsung Health: finisce da solo quando il battito scende sotto questa soglia
    private int coolHr = 0;
    private long coolBelowSince = 0;
    private boolean autoEnding = false;
    // tecnica di corsa (corse facili): proposta a fine parte facile, l'utente sceglie toccando lo schermo
    private boolean tech = false, techAsked = false, techAtEnd = false;
    private long techUntil = 0; private int drillStep = 0, drillLeft = 0; private double drillKm = 0; private String techEndWhy = "";
    private static final String[] DRILL = {"Skip, ginocchia alte", "Recupera camminando", "Calciata, talloni ai glutei", "Recupera camminando",
        "Saltelli sugli avampiedi", "Recupera camminando", "Allungo: accelera piano piano", "Torna camminando", "Allungo", "Torna camminando", "Ultimo allungo", "Cammina e respira"};
    private static final int[] DRILL_S = {30, 30, 30, 30, 30, 30, 20, 40, 20, 40, 20, 30};
    private static final String[] DRILL_TIP = {"ginocchia in alto, passi corti e veloci, braccia attive", "", "talloni verso i glutei, busto dritto", "",
        "piccoli saltelli elastici sull'avampiede, caviglie rigide", "", "accelera fino a un ritmo veloce ma sciolto, senza sforzo massimo", "", "accelera, resta rilassato", "", "ultimo, sciolto e veloce", ""};
    // avviso "mancano 30 secondi" a fine riscaldamento e km contati dall'inizio dell'allenamento (riscaldamento escluso)
    private int warnedSeg = -1;
    // avviso fuori ritmo: direzione in attesa di conferma (1 lento, -1 veloce, 0 ok), da quando, ultima detta e quando
    private int paceCand = 0, paceSaid = 0, paceSeg = -1;
    private long paceCandSince = 0, paceSaidAt = -999;   // fase per cui è già stato dato l'avviso di fine imminente
    private double kmBase = 0;
    private double startLat = 0, startLon = 0, totPlanKm = 0; private boolean halfSaid = false; private double farWarnKm = 0;
    private long kmBaseSec = 0;
    // corse facili e lunghi guidati dal battito: tetto dal telefono, consigli a gradini (1 rallenta e respira, 2 cammina), conferma al rientro
    private int hrCap = 0, capStage = 0;
    private long capOver = 0, capIn = 0, capSaidAt = 0, capSec = 0, capOverSec = 0;
    private boolean zoneWarned = false; private long zoneIn = 0;
    // gel energetici: {s: secondi dall'inizio, km: km stimato (0 = solo a tempo), n, name, caf}; avviso a voce e vibrazione
    private JSONArray gels = null;
    private int gelIdx = 0;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String a = intent != null ? intent.getAction() : null;
        if (ACTION_START.equals(a)) start();
        else if (ACTION_PAUSE.equals(a)) pause();
        else if (ACTION_RESUME.equals(a)) resume();
        else if (ACTION_STOP.equals(a)) stop();
        else if (ACTION_TECH.equals(a)) techTap();
        return START_NOT_STICKY;
    }

    private void start() {
        if (S.running) return;
        if (S.recovering) finishRecovery();
        SharedPreferences p = getSharedPreferences("hf", MODE_PRIVATE);
        ref = null;
        try {
            JSONObject plan = new JSONObject(p.getString("plan", "{}"));
            S.title = plan.optString("title", "Corsa"); S.lo = plan.optInt("lo", -1); S.hi = plan.optInt("hi", -1); S.hrMax = plan.optInt("hrMax", 185);
            ref = plan.optJSONObject("ref");
            gels = plan.optJSONArray("gels");
            segs = plan.optJSONArray("segs"); planPace = paceOf(plan.optString("pace", "")); S.runType = plan.optString("runType", "");
            hrCap = plan.optInt("hrCap", 0); if (hrCap < 90 || hrCap > 200) hrCap = 0;
            tech = plan.optBoolean("tech", false);
        } catch (Exception e) { tech = false; S.title = "Corsa"; segs = null; gels = null; planPace = 0; S.runType = ""; hrCap = 0; }
        capStage = 0; capOver = 0; capIn = 0; capSaidAt = 0; capSec = 0; capOverSec = 0; zoneWarned = false; zoneIn = 0;
        gelIdx = 0; techAsked = false; techAtEnd = false; techUntil = 0; drillStep = 0; drillLeft = 0; S.techOffer = false; S.drill = false;
        S.hrLoB = 0; S.hrHiB = 0;
        if (S.lo >= 0) { double[] lo = {0, .6, .7, .8, .9}, hi = {.6, .7, .8, .9, 1.0};
            S.hrLoB = (int) Math.round(S.hrMax * lo[Math.min(4, S.lo)]); S.hrHiB = S.hi >= 4 ? 0 : (int) Math.round(S.hrMax * hi[Math.max(0, S.hi)]); }
        if (hrCap > 0) S.hrHiB = hrCap;   // corsa guidata dal battito: sullo schermo e a voce il tetto
        coolHr = (int) Math.round(S.hrMax * 0.65); coolBelowSince = 0; autoEnding = false; warnedSeg = -1; paceCand = 0; paceSaid = 0; paceSeg = -1; paceCandSince = 0; paceSaidAt = -999; kmBase = 0; kmBaseSec = 0;
        startLat = 0; startLon = 0; halfSaid = false; farWarnKm = 0; totPlanKm = planTotalKm();
        segIdx = 0; segStartSec = 0; segStartKm = 0; lastKmSec = 0; S.seg = ""; S.target = planPace; goalStep = 0; goalKm = 0; goalMin = 0; goalSeg = -1;
        try { goalKm = new JSONObject(p.getString("plan", "{}")).optDouble("km", 0); } catch (Exception ignored) {}
        if (goalKm <= 0 && segs != null) { double m = 0; boolean allTime = true;
            for (int i = 0; i < segs.length(); i++) { JSONObject g = segs.optJSONObject(i); if (g == null) continue; if (g.optDouble("min", 0) > 0) m += g.optDouble("min", 0); else allTime = false; }
            if (allTime) goalMin = m; }
        if (goalMin <= 0 && segs != null) {   // una sola fase a km dopo il riscaldamento (es. corsa con obiettivo): le percentuali contano solo quella
            int w = -1, n = 0; for (int i = 0; i < segs.length(); i++) { JSONObject g = segs.optJSONObject(i); if (g != null && "work".equals(g.optString("k", "work"))) { n++; w = i; } }
            if (n == 1 && segs.optJSONObject(w).optDouble("km", 0) > 0) { goalSeg = w; goalKm = segs.optJSONObject(w).optDouble("km", 0); } }
        int nPh = segs != null && segs.length() > 0 ? segs.length() : 0;
        S.phName = new String[nPh]; S.phSec = new long[nPh]; S.phKm = new double[nPh]; S.phHrSum = new long[nPh]; S.phHrN = new long[nPh]; S.phIdx = 0; S.lastKmVal = 0;
        // più tratti veloci (ripetute, scatti): li numero, "Scatto 1", "Recupero 1", "Scatto 2"…
        int nWork = 0; for (int i = 0; i < nPh; i++) { JSONObject g = segs.optJSONObject(i); if (g != null && "work".equals(g.optString("k", "work"))) nWork++; }
        perRep = nWork > 1; repSeg = -1; repStep = 0;
        String rep = S.runType.matches("(?i).*(scatt|sprint|allung).*") ? "Scatto" : "Ripetuta";
        int w = 0, r = 0;
        for (int i = 0; i < nPh; i++) { JSONObject g = segs.optJSONObject(i); String k = g != null ? g.optString("k", "work") : "work";
            S.phName[i] = nWork > 1 && "work".equals(k) ? rep + " " + (++w) : nWork > 1 && "recovery".equals(k) ? "Recupero " + (++r) : kindName(k); }
        if (S.title.isEmpty()) S.title = "Corsa";
        S.running = true; S.paused = false; S.autoPaused = false; S.finished = false; S.painAsked = false; S.error = ""; S.bpm = 0; S.maxHr = 0; S.samples = 0; S.sumHr = 0; S.activeSec = 0; S.km = 0; S.kcal = 0;
        S.zoneSec = new long[5]; S.startedAt = System.currentTimeMillis(); S.paceNow = 0; S.hrSrc = ""; S.strapSec = 0; S.watchSec = 0; S.lastBeat = 0;
        lastKm = 0; outSince = 0; rN = 0; rPos = 0; strapBpm = 0; wristBpm = 0; strapAt = 0; wristAt = 0; reconnects = 0;
        S.recovering = false; S.recLeft = 0; S.steps = 0; trk.clear(); rec.clear(); lat = 0; lon = 0; alt = Double.NaN; baro = Double.NaN;
        elevGain = -1; elevLoss = -1; stepsTot = -1; stopAt = 0; recSec = 0; frozen = null;
        strapAddr = p.getString("hrAddr", ""); S.strapName = p.getString("hrName", "");

        createChannel();
        int type = 0;
        if (Build.VERSION.SDK_INT >= 34) {
            type = ServiceInfo.FOREGROUND_SERVICE_TYPE_HEALTH | ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION;
            if (btAllowed()) type |= ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE;
        } else if (Build.VERSION.SDK_INT >= 29) type = ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION;
        ServiceCompat.startForeground(this, NOTIF, notif("Avvio…"), type);

        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "healthfit:watchrun");
        wl.acquire(6 * 60 * 60 * 1000L);

        ex = HealthServices.getClient(this).getExerciseClient();
        ex.setUpdateCallback(cb);
        // chiedo all'orologio quali dati sa misurare: posizione, passi e altitudine solo se ci sono (altrimenti l'avvio fallirebbe)
        Futures.addCallback(ex.getCapabilitiesAsync(), new FutureCallback<ExerciseCapabilities>() {
            @Override public void onSuccess(ExerciseCapabilities caps) {
                Set<DataType<?, ?>> sup = null;
                try { sup = caps.getExerciseTypeCapabilities(ExerciseType.RUNNING).getSupportedDataTypes(); } catch (Exception ignored) {}
                startExercise(sup);
            }
            @Override public void onFailure(@NonNull Throwable t) { startExercise(null); }
        }, ContextCompat.getMainExecutor(this));
        if (voice != null) voice.shutdown();
        voice = new Voice(this);
        h.postDelayed(() -> say("Corsa avviata"), 2500);
        startStrap();
        if (dyn != null) dyn.stop();
        dyn = new RunDynamics(this); dyn.start();
        h.removeCallbacks(tick); h.postDelayed(tick, 1000);
    }

    private void startExercise(Set<DataType<?, ?>> sup) {
        if (!S.running || ex == null) return;
        Set<DataType<?, ?>> types = new HashSet<>();
        types.add(DataType.HEART_RATE_BPM);
        types.add(DataType.DISTANCE_TOTAL);
        types.add(DataType.CALORIES_TOTAL);
        if (sup != null) {
            if (sup.contains(DataType.LOCATION)) types.add(DataType.LOCATION);
            if (sup.contains(DataType.STEPS_TOTAL)) types.add(DataType.STEPS_TOTAL);
            if (sup.contains(DataType.ABSOLUTE_ELEVATION)) types.add(DataType.ABSOLUTE_ELEVATION);
            if (sup.contains(DataType.ELEVATION_GAIN_TOTAL)) types.add(DataType.ELEVATION_GAIN_TOTAL);
            if (sup.contains(DataType.ELEVATION_LOSS_TOTAL)) types.add(DataType.ELEVATION_LOSS_TOTAL);
        }
        ExerciseConfig cfg = new ExerciseConfig.Builder(ExerciseType.RUNNING)
            .setDataTypes(types).setIsAutoPauseAndResumeEnabled(false).setIsGpsEnabled(true).build();
        Futures.addCallback(ex.startExerciseAsync(cfg), new FutureCallback<Void>() {
            @Override public void onSuccess(Void v) { vibrate(new long[]{0, 200}); }
            @Override public void onFailure(@NonNull Throwable t) { S.error = "Non riesco ad avviare: " + t.getMessage(); notifyUi(); }
        }, ContextCompat.getMainExecutor(this));
    }

    private final ExerciseUpdateCallback cb = new ExerciseUpdateCallback() {
        @Override public void onExerciseUpdateReceived(@NonNull ExerciseUpdate update) {
            DataPointContainer m = update.getLatestMetrics();
            List<SampleDataPoint<Double>> hr = m.getData(DataType.HEART_RATE_BPM);
            if (!hr.isEmpty()) { double b = hr.get(hr.size() - 1).getValue(); if (b > 25 && b < 240) { wristBpm = (int) Math.round(b); wristAt = System.currentTimeMillis(); pickHr(); } }
            if (S.recovering) return;   // dopo FINE serve solo il battito: distanza e calorie restano quelle della corsa
            CumulativeDataPoint<Double> d = m.getData(DataType.DISTANCE_TOTAL);
            if (d != null) S.km = d.getTotal() / 1000.0;
            CumulativeDataPoint<Double> c = m.getData(DataType.CALORIES_TOTAL);
            if (c != null) S.kcal = c.getTotal();
            List<SampleDataPoint<LocationData>> loc = m.getData(DataType.LOCATION);
            if (!loc.isEmpty()) { LocationData L = loc.get(loc.size() - 1).getValue(); lat = L.getLatitude(); lon = L.getLongitude(); if (startLat == 0 && startLon == 0 && lat != 0) { startLat = lat; startLon = lon; }
                double a = L.getAltitude(); if (!Double.isNaN(a) && a > -500 && a < 9000) alt = a; }
            List<SampleDataPoint<Double>> el = m.getData(DataType.ABSOLUTE_ELEVATION);
            if (!el.isEmpty()) { double a = el.get(el.size() - 1).getValue(); if (!Double.isNaN(a) && a > -500 && a < 9000) baro = a; }
            CumulativeDataPoint<Long> st = m.getData(DataType.STEPS_TOTAL);
            if (st != null) { stepsTot = st.getTotal(); S.steps = stepsTot; }
            CumulativeDataPoint<Double> eg = m.getData(DataType.ELEVATION_GAIN_TOTAL);
            if (eg != null) elevGain = eg.getTotal();
            CumulativeDataPoint<Double> eL = m.getData(DataType.ELEVATION_LOSS_TOTAL);
            if (eL != null) elevLoss = eL.getTotal();
        }
        @Override public void onLapSummaryReceived(@NonNull ExerciseLapSummary s) {}
        @Override public void onRegistered() {}
        @Override public void onRegistrationFailed(@NonNull Throwable t) { S.error = "Health Services: " + t.getMessage(); notifyUi(); }
        @Override public void onAvailabilityChanged(@NonNull DataType<?, ?> type, @NonNull Availability a) {}
    };

    /** Sceglie il battito da mostrare: la fascia se ha mandato un dato negli ultimi 5 secondi, altrimenti il polso. */
    private void pickHr() {
        long now = System.currentTimeMillis();
        if (strapBpm > 0 && now - strapAt < 5000) { S.bpm = strapBpm; S.lastBeat = strapAt; S.hrSrc = "fascia"; }
        else if (wristBpm > 0 && now - wristAt < 5000) { S.bpm = wristBpm; S.lastBeat = wristAt; S.hrSrc = "orologio"; }
    }

    // ---------- fascia cardio (servizio Bluetooth standard Heart Rate) ----------
    private boolean btAllowed() {
        if (Build.VERSION.SDK_INT >= 31)
            return checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
                && checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED;
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    /** Cerca la fascia salvata sul telefono (o, se non ce n'è una, la prima fascia cardio accesa vicino). */
    @SuppressLint("MissingPermission")
    private void startStrap() {
        if (!S.running || gatt != null || scanning) return;
        if (!btAllowed()) { S.strap = "Bluetooth non permesso: battito dal polso"; return; }
        try {
            BluetoothManager bm = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
            BluetoothAdapter ad = bm != null ? bm.getAdapter() : null;
            if (ad == null || !ad.isEnabled()) { S.strap = "Bluetooth spento: battito dal polso"; return; }
            scanner = ad.getBluetoothLeScanner();
            if (scanner == null) { S.strap = ""; return; }
            ScanFilter f = new ScanFilter.Builder().setServiceUuid(new ParcelUuid(HR_SERVICE)).build();
            ScanSettings st = new ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build();
            scanner.startScan(Collections.singletonList(f), st, scanCb);
            scanning = true; S.strap = "cerco la fascia…";
            h.postDelayed(scanTimeout, 15000);
        } catch (Exception e) { scanning = false; S.strap = ""; }
    }

    private final Runnable scanTimeout = new Runnable() { @SuppressLint("MissingPermission") @Override public void run() {
        stopScan();
        if (!S.running || gatt != null) return;
        // la fascia salvata a volte non si annuncia nella ricerca: provo a collegarla direttamente
        if (!strapAddr.isEmpty()) {
            try {
                BluetoothManager bm = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
                connect(bm.getAdapter().getRemoteDevice(strapAddr));
                return;
            } catch (Exception ignored) {}
        }
        S.strap = "fascia non trovata: battito dal polso";
        h.postDelayed(() -> startStrap(), 45000);   // riprova: magari la indossi dopo
    }};

    private final ScanCallback scanCb = new ScanCallback() {
        @Override public void onScanResult(int type, ScanResult r) {
            BluetoothDevice dev = r.getDevice();
            if (dev == null || gatt != null) return;
            if (!strapAddr.isEmpty() && !strapAddr.equalsIgnoreCase(dev.getAddress())) return;
            h.post(() -> { if (gatt == null && S.running) { stopScan(); h.removeCallbacks(scanTimeout); connect(dev); } });
        }
        @Override public void onScanFailed(int code) { scanning = false; }
    };

    @SuppressLint("MissingPermission")
    private void stopScan() {
        if (!scanning) return; scanning = false;
        try { if (scanner != null) scanner.stopScan(scanCb); } catch (Exception ignored) {}
    }

    @SuppressLint("MissingPermission")
    private void connect(BluetoothDevice dev) {
        try {
            strapDev = dev;
            try { String n = dev.getName(); if (n != null && !n.isEmpty()) S.strapName = n; } catch (Exception ignored) {}
            if (S.strapName.isEmpty()) S.strapName = "Fascia";
            if (gatt != null) { try { gatt.close(); } catch (Exception ignored) {} }
            S.strap = "collego " + S.strapName + "…";
            gatt = dev.connectGatt(this, false, gcb, BluetoothDevice.TRANSPORT_LE);
        } catch (Exception e) { gatt = null; S.strap = "fascia non collegata: battito dal polso"; }
    }

    private final BluetoothGattCallback gcb = new BluetoothGattCallback() {
        @SuppressLint("MissingPermission")
        @Override public void onConnectionStateChange(BluetoothGatt g, int status, int newState) {
            if (newState == BluetoothProfile.STATE_CONNECTED) { reconnects = 0; S.strap = S.strapName + " collegata"; g.discoverServices(); }
            else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                h.post(() -> {
                    try { g.close(); } catch (Exception ignored) {}
                    if (gatt == g) gatt = null;
                    if (!S.running) return;
                    S.strap = "fascia persa: battito dal polso";
                    if (reconnects < 40 && strapDev != null) { reconnects++;
                        h.postDelayed(() -> { if (S.running && gatt == null) connect(strapDev); }, Math.min(15000, 1500L * reconnects)); }
                });
            }
        }
        @SuppressLint("MissingPermission")
        @SuppressWarnings("deprecation")
        @Override public void onServicesDiscovered(BluetoothGatt g, int status) {
            BluetoothGattService s = g.getService(HR_SERVICE); if (s == null) return;
            BluetoothGattCharacteristic c = s.getCharacteristic(HR_MEASURE); if (c == null) return;
            g.setCharacteristicNotification(c, true);
            BluetoothGattDescriptor d = c.getDescriptor(CCC);
            if (d != null) {
                if (Build.VERSION.SDK_INT >= 33) g.writeDescriptor(d, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                else { d.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE); g.writeDescriptor(d); }
            }
        }
        @Override public void onCharacteristicChanged(@NonNull BluetoothGatt g, @NonNull BluetoothGattCharacteristic c, @NonNull byte[] v) { parse(v); }
        @SuppressWarnings("deprecation")
        @Override public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic c) { if (Build.VERSION.SDK_INT < 33) parse(c.getValue()); }
    };

    private void parse(byte[] v) {
        if (v == null || v.length < 2) return;
        int flags = v[0] & 0xff;
        int bpm = (flags & 1) != 0 && v.length >= 3 ? ((v[1] & 0xff) | ((v[2] & 0xff) << 8)) : (v[1] & 0xff);
        if (bpm > 25 && bpm < 240) { strapBpm = bpm; strapAt = System.currentTimeMillis(); }
    }

    @SuppressLint("MissingPermission")
    private void stopStrap() {
        stopScan(); h.removeCallbacks(scanTimeout);
        try { if (gatt != null) { gatt.disconnect(); gatt.close(); } } catch (Exception ignored) {}
        gatt = null; strapDev = null;
    }

    // ---------- ogni secondo ----------
    private int zoneOf(int b) { double pc = b / (double) S.hrMax; return pc < 0.6 ? 0 : pc < 0.7 ? 1 : pc < 0.8 ? 2 : pc < 0.9 ? 3 : 4; }

    private final Runnable tick = new Runnable() { @Override public void run() {
        if (S.recovering) { recoveryTick(); return; }
        if (!S.running) return;
        pickHr();
        if (!S.paused) checkAutoPause();
        if (!S.paused && !S.autoPaused) {
            S.activeSec++;
            if (System.currentTimeMillis() - S.lastBeat < 5000 && S.bpm > 0) {
                int z = zoneOf(S.bpm); S.sumHr += S.bpm; S.samples++; S.maxHr = Math.max(S.maxHr, S.bpm); S.zoneSec[z]++;
                if ("fascia".equals(S.hrSrc)) S.strapSec++; else S.watchSec++;
                checkZone(z);
            }
            int k = (int) Math.floor(S.km - kmBase);
            if (!"warmup".equals(curKind()) && k > lastKm && k >= 1) { lastKm = k; vibrate(new long[]{0, 120, 120, 120}); sayKm(k); }
            updatePace();
            if (S.drill && !techAtEnd) { segStartSec++; segStartKm += S.km - drillKm; }   // il defaticamento aspetta la fine della tecnica
            drillKm = S.km;
            updateSeg();
            techTick();
            checkPace();
            checkGoal();
            checkGels();
            checkTurn();
            if (S.phIdx < S.phSec.length) { S.phSec[S.phIdx] = S.activeSec - segStartSec; S.phKm[S.phIdx] = S.km - segStartKm;
                if (System.currentTimeMillis() - S.lastBeat < 5000 && S.bpm > 0) { S.phHrSum[S.phIdx] += S.bpm; S.phHrN[S.phIdx]++; } }
            if (S.activeSec % 5 == 0) addPoint();
        }
        if (S.activeSec % 5 == 0) updateNotif();
        notifyUi();
        h.postDelayed(this, 1000);
    }};

    /** Un punto del percorso ogni 5 secondi di corsa. */
    private void addPoint() {
        boolean fresh = System.currentTimeMillis() - S.lastBeat < 5000 && S.bpm > 0;
        double a = !Double.isNaN(baro) ? baro : alt;
        trk.add(new int[]{ (int) S.activeSec, (int) Math.round(S.km * 1000), fresh ? S.bpm : 0, Double.isNaN(a) ? -9999 : (int) Math.round(a),
            stepsTot >= 0 ? (int) stepsTot : -1, (int) Math.round(lat * 1e5), (int) Math.round(lon * 1e5) });
    }

    /** Dopo FINE: per un minuto registro come scende il battito (ogni 2 secondi). */
    private void recoveryTick() {
        pickHr();
        recSec++; S.recLeft = (int) Math.max(0, REC_SEC - recSec);
        boolean fresh = System.currentTimeMillis() - S.lastBeat < 5000 && S.bpm > 0;
        if (recSec % 2 == 0 && fresh) rec.add(new int[]{ (int) recSec, S.bpm });
        notifyUi();
        if (recSec % 5 == 0) updateNotif();
        if (recSec >= REC_SEC) { finishRecovery(); return; }
        h.postDelayed(tick, 1000);
    }

    /** Ritmo attuale: distanza percorsa negli ultimi 30 secondi di corsa (le pause non contano). */
    private void updatePace() {
        rSec[rPos] = S.activeSec; rKm[rPos] = S.km; rPos = (rPos + 1) % rSec.length; if (rN < rSec.length) rN++;
        int oldest = rN < rSec.length ? 0 : rPos;
        long ds = S.activeSec - rSec[oldest]; double dk = S.km - rKm[oldest];
        S.paceNow = ds >= 10 && dk >= 0.02 ? ds / dk : 0;   // sotto 20 metri in 30 secondi: fermo, nessun ritmo
    }

    private void checkZone(int z) {
        if (S.drill || S.techOffer) return;   // durante la tecnica il battito sale apposta
        if (capActive()) { checkCap(); return; }
        if (S.lo < 0) return;
        long now = System.currentTimeMillis();
        String kind = curKind();
        // sotto la zona conta solo nei tratti di allenamento (non in riscaldamento, recuperi e defaticamento)
        boolean out = z > S.hi || (S.lo >= 3 && z < S.lo && "work".equals(kind));
        if (!out) { outSince = 0;
            // dopo un avviso "sopra la zona": confermo quando è rientrato (10 secondi di fila)
            if (zoneWarned && z <= S.hi) { if (zoneIn == 0) zoneIn = now; if (now - zoneIn > 10000) { zoneWarned = false; zoneIn = 0; vibrate(new long[]{0, 120}); say("Bene, battito " + S.bpm + ", di nuovo nella zona"); } }
            return; }
        zoneIn = 0;
        if (outSince == 0) outSince = now;
        long limit = z > S.hi ? 20000 : 60000;
        if (now - outSince > limit && now - lastAlert > 45000) {
            lastAlert = now;
            // sopra la zona: due vibrazioni lunghe · sotto la zona: tre brevi
            vibrate(z > S.hi ? new long[]{0, 500, 200, 500} : new long[]{0, 150, 120, 150, 120, 150});
            if (z > S.hi) zoneWarned = true;
            say("Battito " + S.bpm + ", " + (z > S.hi ? "sopra la zona. " + slowTip(kind, now - outSince > 80000) : "puoi spingere un po' di più. ") + rangeWords());
        }
    }

    /** Come far scendere il battito, in base al tratto: ripetuta, recupero o corsa continua. */
    private String slowTip(String kind, boolean long_) {
        JSONObject g = segs != null ? segs.optJSONObject(segIdx) : null;
        if ("recovery".equals(kind)) return "Nel recupero cammina o corri pianissimo, butta fuori l'aria piano. ";
        if ("work".equals(kind) && !isEasy(g) && perRep) return "Tieni il ritmo della ripetuta ma respira lento, spalle sciolte. ";
        if (climbing()) return "In salita cammina a passo svelto, è normale. ";
        if (long_) return "Cammina 30 o 60 secondi finché scende, poi riparti piano. ";
        return "Rallenta" + (S.paceNow > 0 && S.paceNow < 720 ? " a circa " + paceWords(S.paceNow + 25) + " al chilometro" : "") + ", accorcia il passo e butta fuori l'aria piano. ";
    }

    /** Tetto di battito attivo: corsa facile o lungo, tranne i tratti veloci scritti nel piano (ritmo gara, soglia, allunghi…). */
    private boolean capActive() {
        if (hrCap <= 0) return false;
        JSONObject g = segs != null ? segs.optJSONObject(segIdx) : null;
        if (g == null || !"work".equals(g.optString("k", "work"))) return true;
        return !g.optString("l", "").toLowerCase(Locale.ITALY).matches(".*(ritmo gara|soglia|veloc|forte|progress|allung|ripet|tempo run|medio).*");
    }

    /** In salita: almeno 3 metri guadagnati negli ultimi 30 secondi. */
    private boolean climbing() {
        int n = trk.size(); if (n < 7) return false;
        int[] a = trk.get(n - 7), b = trk.get(n - 1);
        return a[3] != -9999 && b[3] != -9999 && b[3] - a[3] >= 3 && b[1] - a[1] >= 20;
    }

    /** Corsa guidata dal battito: 15 s sopra il tetto → rallenta, passo corto e respiro; un minuto dopo ancora sopra → cammina; rientro confermato. */
    private void checkCap() {
        long t = S.activeSec; int b = S.bpm;
        capSec++;
        if (b > hrCap) {
            capOverSec++; capIn = 0;
            if (capOver == 0) capOver = t;
            long over = t - capOver;
            if (capStage == 0 && over >= 15) {
                capStage = 1; capSaidAt = t; vibrate(new long[]{0, 500, 200, 500});
                say("Battito " + b + ", sopra " + hrCap + ". " + (climbing() ? "In salita cammina a passo svelto, è normale. "
                    : "Rallenta" + (S.paceNow > 0 && S.paceNow < 720 ? " a circa " + paceWords(S.paceNow + 30) + " al chilometro" : "") + " e accorcia il passo. ")
                    + "Respira lento: butta fuori l'aria piano, più a lungo di quando la prendi.");
            } else if (capStage == 1 && t - capSaidAt >= 60) {
                capStage = 2; capSaidAt = t; vibrate(new long[]{0, 500, 200, 500});
                say("Ancora " + b + ". Cammina 30 o 60 secondi finché scendi sotto " + (hrCap - 5) + ", poi riparti piano. Camminare va benissimo, il cuore si allena lo stesso.");
            } else if (capStage >= 2 && t - capSaidAt >= 90) {
                capSaidAt = t; vibrate(new long[]{0, 300});
                say("Battito " + b + ": cammina ancora un po', riparti quando scendi sotto " + (hrCap - 5));
            }
        } else {
            capOver = 0;
            if (capStage > 0 && b <= hrCap - (capStage >= 2 ? 5 : 3)) {
                if (capIn == 0) capIn = t;
                if (t - capIn >= 10) {
                    boolean walk = S.paceNow <= 0 || S.paceNow > 600;
                    vibrate(new long[]{0, 120}); capStage = 0; capIn = 0;
                    say("Bene, battito " + b + ", sotto " + hrCap + ". " + (walk ? "Riparti piano, a passi corti." : "Tieni questo ritmo."));
                }
            } else capIn = 0;
        }
    }

    /** Obiettivo della fase detto a voce: "Inizia scatto 2: 400 metri a 4 e 30, battiti tra 160 e 175". */
    private String phaseGoal(JSONObject g, int i) {
        String k = g.optString("k", "work"); double min = g.optDouble("min", 0), km = g.optDouble("km", 0), t = segTarget(g);
        StringBuilder sb = new StringBuilder("Inizia ").append(S.phName[i].toLowerCase(Locale.ITALY)).append(": ");
        if (km > 0) sb.append(km < 1 ? Math.round(km * 1000) + " metri" : kmWords(km) + " chilometri");
        else if (min > 0) sb.append(min < 1 ? Math.round(min * 60) + " secondi" : (Math.round(min * 10) / 10.0 == Math.round(min) ? String.valueOf(Math.round(min)) : String.format(Locale.ITALY, "%.1f", min).replace(",", " virgola ")) + " minuti");
        else sb.append("corsa libera");
        if (t > 0) sb.append(" a ").append(paceWords(t)).append(" al chilometro");
        else if (isEasy(g)) sb.append(", andatura facile, ritmo libero");
        if (t > 0 && isEasy(g)) sb.append(", andatura facile");
        if ("work".equals(k) && !isEasy(g)) { String r = rangeWords(); if (!r.isEmpty()) sb.append(", battiti: ").append(r.substring(0, 1).toLowerCase(Locale.ITALY)).append(r.substring(1)); }
        return sb.toString();
    }

    private String rangeWords() {
        return S.hrLoB > 0 && S.hrHiB > 0 ? "Stai tra " + S.hrLoB + " e " + S.hrHiB : S.hrHiB > 0 ? "Stai sotto i " + S.hrHiB : S.hrLoB > 0 ? "Stai sopra i " + S.hrLoB : "";
    }

    // ---------- voce ----------
    private void say(String msg) { if (voice != null && (S.running || S.recovering)) voice.say(msg); }
    private static String paceWords(double secPerKm) { long p = Math.round(secPerKm); return p % 60 == 0 ? String.valueOf(p / 60) : (p / 60) + " e " + (p % 60); }
    /** A ogni km: tempo, ritmo dell'ultimo km confrontato con l'obiettivo della fase, battito. */
    private void sayKm(int k) {
        long split = S.activeSec - lastKmSec; lastKmSec = S.activeSec;
        StringBuilder sb = new StringBuilder().append(k).append(k == 1 ? " chilometro" : " chilometri");
        sb.append(", tempo ").append((S.activeSec - kmBaseSec) / 60).append(" minuti");
        if (split > 120 && split < 1200) {
            sb.append(", ultimo chilometro ").append(paceWords(split));
            String kind = curKind();
            if (S.target > 0 && !"warmup".equals(kind) && !"cooldown".equals(kind) && (!isEasy(segs != null ? segs.optJSONObject(segIdx) : null) || paceOf(segs.optJSONObject(segIdx).optString("p", "")) > 0)) {
                long d = Math.round(split - S.target);
                if (Math.abs(d) <= 10) sb.append(", sei in linea con l'obiettivo");
                else if (d < 0) sb.append(", ").append(-d).append(" secondi più veloce dell'obiettivo, rallenta un po'");
                else if (capActive()) sb.append(", va bene, oggi conta il battito");
                else sb.append(", ").append(d).append(" secondi più lento dell'obiettivo, ").append(d > 25 ? "accelera" : "spingi un pochino");
            }
        }
        if (System.currentTimeMillis() - S.lastBeat < 5000 && S.bpm > 0) sb.append(", battito ").append(S.bpm);
        say(sb.toString());
    }

    /** Avanzamento verso l'obiettivo: al 30, 50 e 80% dice quanto manca con un incoraggiamento, al 100% che è fatta. */
    private void checkGoal() {
        if (perRep) { checkRep(); return; }
        if (goalSeg >= 0 && (segIdx < goalSeg || (segIdx > goalSeg && goalStep >= 4))) return;
        // la fase obiettivo appena chiusa (si è già passati al defaticamento) conta come 100%
        double done = goalSeg < 0 ? S.km : segIdx > goalSeg ? goalKm : S.km - segStartKm;
        double pc = goalKm > 0 ? done / goalKm : goalMin > 0 ? S.activeSec / (goalMin * 60) : 0;
        if (pc <= 0) return;
        int[] steps = {30, 50, 80, 100};
        if (goalStep >= steps.length || pc * 100 < steps[goalStep]) return;
        int st = steps[goalStep]; while (goalStep < steps.length && pc * 100 >= steps[goalStep]) goalStep++;
        String left = goalKm > 0 ? kmWords(Math.max(0, goalKm - done)) + " chilometri" : Math.max(1, Math.round(goalMin - S.activeSec / 60.0)) + " minuti";
        String msg = st == 30 ? "Sei al 30 per cento, mancano " + left + ". Ottimo inizio, continua così"
            : st == 50 ? "Metà fatta! Mancano " + left + ". Stai andando alla grande"
            : st == 80 ? "Sei all'80 per cento, mancano solo " + left + ". Ultimo sforzo, ce la fai"
            : "Obiettivo raggiunto! Bravissimo";
        if (st == 100 && (segs == null || segs.length() == 0)) { finishPlan("Obiettivo raggiunto, " + (goalKm > 0 ? kmWords(goalKm) + " chilometri" : Math.round(goalMin) + " minuti")); return; }   // corsa senza fasi: finita la distanza o il tempo chiudo
        if (st == 100) vibrate(new long[]{0, 200, 100, 200, 100, 400});
        say(msg);
    }

    /** Distanza totale prevista (riscaldamento e defaticamento compresi): fasi a km così come sono, fasi a tempo stimate col loro ritmo. 0 = non stimabile. */
    private double planTotalKm() {
        if (segs == null || segs.length() == 0) return goalKm;
        double t = 0;
        for (int i = 0; i < segs.length(); i++) { JSONObject g = segs.optJSONObject(i); if (g == null) return 0;
            double km = g.optDouble("km", 0), min = g.optDouble("min", 0);
            if (km > 0) { t += km; continue; }
            if (min <= 0) return 0;
            double ps = paceOf(g.optString("p", "")); if (ps <= 0) ps = planPace > 0 ? planPace : 0;
            if (ps <= 0) ps = "work".equals(g.optString("k", "work")) ? 330 : 400;   // ritmo sconosciuto: stima prudente
            t += min * 60 / ps; }
        return t; }
    private double homeKm() {
        if (startLat == 0 || lat == 0) return -1;
        float[] r = new float[1]; android.location.Location.distanceBetween(startLat, startLon, lat, lon, r); return r[0] / 1000.0; }
    /** Corse lunghe (da 8 km): a metà del totale dice quanto sei lontano da dove sei partito e, se fai andata e ritorno, di girare.
     *  Dopo la metà, se sei più lontano di quanto ti resta da correre (+1 km), avvisa che rischi di allungare il percorso. */
    private void checkTurn() {
        if (totPlanKm < 8 || autoEnding || S.km < 1) return;
        double home = homeKm(), left = totPlanKm - S.km;
        if (!halfSaid && S.km >= totPlanKm / 2) { halfSaid = true; farWarnKm = S.km;
            if (segIdx > 0 && S.activeSec - segStartSec < 6) { halfSaid = false; return; }
            vibrate(new long[]{0, 400, 150, 400});
            String m = "Metà percorso: " + kmWords(S.km) + " chilometri fatti, ne mancano " + kmWords(Math.max(0, left)) + ".";
            if (home >= 0) m += home < left * 0.3 ? " Sei vicino al punto di partenza." : " Sei a " + kmWords(home) + " chilometri in linea d'aria dalla partenza: se fai andata e ritorno, gira adesso.";
            else m += " Se fai andata e ritorno, gira adesso.";
            say(m); return; }
        if (halfSaid && home >= 0 && left > 0.5 && home > left + 1 && S.km - farWarnKm >= 2) { farWarnKm = S.km;
            vibrate(new long[]{0, 300, 150, 300});
            say("Attenzione: sei a " + kmWords(home) + " chilometri dalla partenza e te ne mancano " + kmWords(left) + " di allenamento. Avvicinati a casa."); }
    }
    /** Gel: al minuto previsto (o al km stimato, se arriva prima) vibra a lungo e dice "Prendi il gel N adesso, con un sorso d'acqua".
     *  Aspetta qualche secondo se è appena cambiata fase (per non sovrapporre i messaggi) e tace quando la corsa si sta chiudendo. */
    private void checkGels() {
        if (gels == null || gelIdx >= gels.length() || autoEnding) return;
        JSONObject g = gels.optJSONObject(gelIdx); if (g == null) { gelIdx++; return; }
        long s = g.optLong("s", 0); double km = g.optDouble("km", 0);
        boolean due = (s > 0 && S.activeSec >= s) || (km > 0 && S.km > 0.2 && S.km >= km);
        if (!due) return;
        if (segIdx > 0 && S.activeSec - segStartSec < 6) return;
        gelIdx++;
        String name = g.optString("name", "").trim();
        vibrate(new long[]{0, 500, 200, 500, 200, 500});
        say("Prendi il gel " + g.optInt("n", gelIdx) + (name.isEmpty() ? "" : ", " + name) + ", adesso, con un sorso d'acqua");
    }
    /** Fine del piano: lo dice, vibra forte e chiude la corsa da sola (poi parte il minuto di recupero del battito). */
    private void finishPlan(String what) {
        if (autoEnding || S.techOffer || S.drill) return;
        if (tech && !techAsked) { techEndWhy = what; offerTech(true, what + ". Bravo!"); return; }
        autoEnding = true;
        vibrate(new long[]{0, 300, 150, 300, 150, 300});
        say(what + ". Allenamento completato, bravo! Chiudo la corsa");
        h.postDelayed(this::stop, 4000);
    }
    /** Fuori ritmo rispetto all'obiettivo della fase (oltre 5 s/km per 8 secondi di fila): vibra e lo dice, così non serve guardare
     *  l'orologio. Ripete al massimo ogni 40 secondi finché resta fuori e avvisa quando rientra. Mai senza ritmo obiettivo. */
    private void checkPace() {
        String kind = curKind();
        if (paceSeg != segIdx) { paceSeg = segIdx; paceCand = 0; paceSaid = 0; paceCandSince = S.activeSec; }
        if (S.drill || S.target <= 0 || "warmup".equals(kind) || "cooldown".equals(kind) || S.activeSec - segStartSec < 30 || S.paceNow <= 0) return;
        double p = S.paceNow, t = S.target;
        int dir = p > t + 5 ? 1 : p < t - 5 ? -1 : 0;
        if (dir > 0 && capActive()) dir = 0;   // corsa guidata dal battito: più lento del ritmo va bene
        if (dir != paceCand) { paceCand = dir; paceCandSince = S.activeSec; return; }
        if (S.activeSec - paceCandSince < 8) return;
        boolean change = dir != paceSaid, repeat = dir != 0 && S.activeSec - paceSaidAt >= 40;
        if (!change && !repeat) return;
        if (change && dir != 0 && paceSaid != 0 && S.activeSec - paceSaidAt < 15) return;   // da lento a veloce in un attimo: aspetto
        paceSaid = dir; paceSaidAt = S.activeSec;
        if (dir > 0) { vibrate(new long[]{0, 150, 120, 150, 120, 150}); say("Più veloce: sei a " + paceWords(p) + ", obiettivo " + paceWords(t)); }
        else if (dir < 0) { vibrate(new long[]{0, 500, 200, 500}); say("Rallenta: sei a " + paceWords(p) + ", obiettivo " + paceWords(t)); }
        else { vibrate(new long[]{0, 120}); say("Ritmo giusto, " + paceWords(p)); }
    }

    /** Percentuali sul singolo scatto/ripetuta (la fine la annuncia già il cambio di fase). */
    private void checkRep() {
        JSONObject g = segs != null ? segs.optJSONObject(segIdx) : null;
        if (g == null || !"work".equals(g.optString("k", "work")) || isEasy(g)) return;
        if (repSeg != segIdx) { repSeg = segIdx; repStep = 0; }
        double km = g.optDouble("km", 0), min = g.optDouble("min", 0);
        double pc = km > 0 ? (S.km - segStartKm) / km : min > 0 ? (S.activeSec - segStartSec) / (min * 60) : 0;
        int[] steps = {30, 50, 80};
        if (pc <= 0 || repStep >= steps.length || pc * 100 < steps[repStep]) return;
        int st = steps[repStep]; while (repStep < steps.length && pc * 100 >= steps[repStep]) repStep++;
        String left = km > 0 ? (km - (S.km - segStartKm) < 1 ? Math.max(10, Math.round((km - (S.km - segStartKm)) * 1000 / 10) * 10) + " metri" : kmWords(km - (S.km - segStartKm)) + " chilometri")
            : secWords(Math.max(5, Math.round(min * 60 - (S.activeSec - segStartSec))));
        say(st == 30 ? "30 per cento, mancano " + left : st == 50 ? "Metà fatta, mancano " + left : "80 per cento, mancano " + left + ", ultimo sforzo");
    }
    private static String secWords(long sec) { return sec <= 90 ? sec + " secondi" : (sec / 60 == 1 ? "1 minuto" : (sec / 60) + " minuti") + (sec % 60 < 15 ? "" : " e " + (sec % 60) + " secondi"); }
    private static String kmWords(double km) { String t = String.format(Locale.ITALY, "%.1f", km); return t.endsWith(",0") ? t.substring(0, t.length() - 2) : t.replace(",", " virgola "); }

    // ---------- fasi della seduta ----------
    static double paceOf(String t) {
        try { java.util.regex.Matcher m = java.util.regex.Pattern.compile("(\\d+)[:'](\\d{1,2})").matcher(t == null ? "" : t);
            if (m.find()) { double v = Integer.parseInt(m.group(1)) * 60 + Integer.parseInt(m.group(2)); return v >= 150 && v <= 1200 ? v : 0; } } catch (Exception ignored) {}
        return 0;
    }
    private static String kindName(String k) {
        return "warmup".equals(k) ? "Riscaldamento" : "recovery".equals(k) ? "Recupero" : "cooldown".equals(k) ? "Defaticamento" : "Allenamento";
    }
    private String curKind() { JSONObject g = segs != null ? segs.optJSONObject(segIdx) : null; return g != null ? g.optString("k", "work") : "work"; }
    /** Fase ad andatura facile: recupero, riscaldamento, defaticamento o tratto scritto come "facile/lento" nel piano. */
    private static boolean isEasy(JSONObject g) {
        if (g == null) return false; String k = g.optString("k", "work");
        return !"work".equals(k) || g.optString("l", "").toLowerCase(Locale.ITALY).matches(".*(facil|lent|recuper|defatic|cammin|jogging|easy).*");
    }
    /** Ritmo obiettivo della fase: quello scritto nel piano; senza, il ritmo medio della seduta solo per il tratto veloce di una corsa continua.
     *  Andatura facile senza ritmo e ripetute senza ritmo: nessun obiettivo, quindi mai "stai andando più lento". */
    private double segTarget(JSONObject g) { double t = g != null ? paceOf(g.optString("p", "")) : 0;
        return t > 0 ? t : (!isEasy(g) && !perRep ? planPace : 0); }

    /** Passa alla fase successiva quando finisce il tempo o la distanza di quella in corso e lo dice a voce, come Samsung Health. */
    private void updateSeg() {
        if (segs == null || segs.length() == 0) { S.seg = S.runType.isEmpty() ? S.title : S.runType; S.segInfo = S.target > 0 ? "🎯 obiettivo " + fmtPace(S.target) + "/km" : ""; return; }
        JSONObject g = segs.optJSONObject(segIdx); if (g == null) return;
        double min = g.optDouble("min", 0), km = g.optDouble("km", 0);
        long secIn = S.activeSec - segStartSec; double kmIn = S.km - segStartKm;
        boolean last = segIdx >= segs.length() - 1;
        boolean done = !last && (min > 0 ? secIn >= Math.round(min * 60) : km > 0 && kmIn >= km);
        if (done) {
            String was = g.optString("k", "work");
            segIdx++; segStartSec = S.activeSec; segStartKm = S.km; S.phIdx = segIdx; S.lastKmVal = S.km;
            g = segs.optJSONObject(segIdx); min = g.optDouble("min", 0); km = g.optDouble("km", 0); secIn = 0; kmIn = 0;
            S.target = segTarget(g);
            String now = g.optString("k", "work"), lab = g.optString("l", "");
            // finito il riscaldamento i km ripartono da zero: 1, 2, 3… sono quelli dell'allenamento
            if ("warmup".equals(was) && !"warmup".equals(now)) { kmBase = S.km; kmBaseSec = S.activeSec; lastKm = 0; lastKmSec = S.activeSec; }
            vibrate(new long[]{0, 400, 150, 400});
            StringBuilder sb = new StringBuilder(S.phName[segIdx - 1]).append(" finito. ");
            int ch = coolHrOf(g);
            if ("cooldown".equals(now) && segIdx == segs.length() - 1 && km <= 0 && (ch > 0 || min <= 0))
                sb.append("Inizia il defaticamento: corri piano o cammina, finisce da solo quando il battito scende sotto ").append(ch > 0 ? ch : coolHr);
            else sb.append(phaseGoal(g, segIdx));
            if ("cooldown".equals(now) && tech && !techAsked) { offerTech(false, sb.toString()); return; }
            say(sb.toString());
        } else if (segIdx == 0 && S.activeSec == 1) S.target = segTarget(g);
        else if (segIdx == 0 && S.activeSec == 4) say(phaseGoal(g, 0));   // obiettivo della prima fase, dopo "Corsa avviata"
        else if (warnedSeg != segIdx && !last) checkEndSoon(g, min, km, secIn, kmIn);
        String left = min > 0 ? " · ancora " + fmtPace(Math.max(0, Math.round(min * 60) - secIn)) : km > 0 ? String.format(Locale.ITALY, " · ancora %.1f km", Math.max(0, km - kmIn)) : "";
        S.seg = S.phName[segIdx] + (S.runType.isEmpty() ? "" : " – " + S.runType);
        String info = ((last ? "" : left) + (S.target > 0 ? " · obiettivo " + fmtPace(S.target) + "/km" : "")).replaceFirst("^ · ", "");
        boolean cool = "cooldown".equals(g.optString("k", "work")) && last;
        // il defaticamento segue il piano: a km finisce a quella distanza, a minuti a quel tempo;
        // il battito decide solo se il piano dice "fino a N bpm" (o se non c'è né distanza né tempo)
        int planHr = cool ? coolHrOf(g) : 0;
        boolean coolByKm = cool && km > 0, coolByHr = cool && !coolByKm && (planHr > 0 || min <= 0), coolByMin = cool && !coolByKm && !coolByHr;
        int hrStop = planHr > 0 ? planHr : coolHr;
        if (cool) info = coolByHr ? "finisce sotto ♥" + hrStop : left.replaceFirst("^ · ", "");
        S.segInfo = info;
        // ultima fase senza defaticamento (es. 16 km di allenamento): finita la distanza o il tempo del piano, la corsa si chiude
        if (!cool && last && !autoEnding && (min > 0 ? secIn >= Math.round(min * 60) : km > 0 && kmIn >= km))
            finishPlan(S.phName[segIdx] + " finito" + (km > 0 ? ", " + kmWords(km) + " chilometri" : ""));
        if (cool && !autoEnding) {
            boolean fresh = System.currentTimeMillis() - S.lastBeat < 5000 && S.bpm > 0;
            boolean end = false; String why = "";
            if (coolByKm) { end = kmIn >= km; why = ", " + kmWords(km) + " chilometri fatti"; }
            else if (coolByMin) end = secIn >= Math.round(min * 60);
            else if (secIn >= 60) {
                // battito sotto la soglia per 15 secondi (dopo almeno 1 minuto), oppure, senza battito, quando passa il tempo previsto
                if (fresh && S.bpm < hrStop) { if (coolBelowSince == 0) coolBelowSince = S.activeSec; } else coolBelowSince = 0;
                if (coolBelowSince > 0 && S.activeSec - coolBelowSince >= 15) { end = true; why = ", battito sceso a " + S.bpm; }
                else if (!fresh && min > 0 && secIn >= Math.round(min * 60)) end = true;
            }
            if (end) finishPlan("Defaticamento finito" + why);
        }
    }
    /** Propone la tecnica di corsa: tocca lo schermo per farla, altrimenti si va avanti da soli. */
    private void offerTech(boolean atEnd, String before) {
        techAsked = true; techAtEnd = atEnd; S.techOffer = true; techUntil = S.activeSec + (atEnd ? 30 : 45);
        vibrate(new long[]{0, 200, 120, 200, 120, 600});
        say(before + " Se vuoi, ora 6 minuti di tecnica di corsa: tocca lo schermo dell'orologio. Altrimenti " + (atEnd ? "chiudo la corsa tra poco" : "continua col defaticamento"));
    }
    private void techTap() {
        if (!S.running) return;
        if (S.techOffer) { S.techOffer = false; S.drill = true; drillStep = 0; drillLeft = DRILL_S[0]; vibrate(new long[]{0, 400}); sayDrill(); }
        else if (S.drill) { S.drill = false; vibrate(new long[]{0, 300}); endDrill("Tecnica interrotta"); }
        notifyUi();
    }
    private void sayDrill() { String t = DRILL_TIP[drillStep]; say(DRILL[drillStep] + ", " + DRILL_S[drillStep] + " secondi" + (t.isEmpty() ? "" : ": " + t)); }
    private void endDrill(String what) {
        S.drill = false;
        if (techAtEnd) { autoEnding = true; say(what + ". Allenamento completato, bravo! Chiudo la corsa"); h.postDelayed(this::stop, 4000); }
        else say(what + ". Ora il defaticamento: corri piano o cammina");
    }
    /** Ogni secondo: scadenza della proposta e passi della tecnica (nome e secondi sullo schermo al posto della fase). */
    private void techTick() {
        if (S.techOffer) {
            if (S.activeSec >= techUntil) { S.techOffer = false;
                if (techAtEnd) { autoEnding = true; say("Va bene, niente tecnica oggi. Chiudo la corsa"); h.postDelayed(this::stop, 3000); }
                else say("Va bene, continua col defaticamento"); }
            else { S.seg = "Tecnica di corsa?"; S.segInfo = "👆 tocca per farla · " + (techUntil - S.activeSec) + " s"; }
            return;
        }
        if (!S.drill) return;
        if (--drillLeft <= 0) {
            if (++drillStep >= DRILL.length) { vibrate(new long[]{0, 300, 150, 300}); endDrill("Tecnica finita"); return; }
            drillLeft = DRILL_S[drillStep]; vibrate(new long[]{0, 350}); sayDrill();
        } else if (drillLeft == 3) vibrate(new long[]{0, 80});
        S.seg = "Tecnica " + (drillStep + 1) + "/" + DRILL.length; S.segInfo = DRILL[drillStep] + " · " + drillLeft + " s";
    }
    /** Battiti "fino a N bpm" scritti nel piano per la fase (campo hr o testo), 0 = non indicati. */
    private static int coolHrOf(JSONObject g) {
        if (g == null) return 0;
        // campo "h" mandato dal telefono (es. "fino a 115 bpm"), oppure il testo della fase
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(\\d{2,3})").matcher(g.optString("h", ""));
        if (!m.find()) { m = java.util.regex.Pattern.compile("(\\d{2,3})\\s*bpm").matcher(g.optString("l", "").toLowerCase(Locale.ITALY)); if (!m.find()) return 0; }
        int x = Integer.parseInt(m.group(1)); return x >= 80 && x <= 200 ? x : 0;
    }
    /** Avviso prima della fine di una fase facile: 30 secondi a fine riscaldamento, 15 secondi prima di uno scatto/ripetuta.
     *  A km la stima viene dal ritmo attuale (o medio della fase). */
    private void checkEndSoon(JSONObject g, double min, double km, long secIn, double kmIn) {
        JSONObject nx = segs.optJSONObject(segIdx + 1); if (nx == null) return;
        String k = g.optString("k", "work"), nk = nx.optString("k", "work");
        int lead;
        if ("warmup".equals(k)) { if ("warmup".equals(nk)) return; lead = 30; }   // riscaldamento in più tratti: avviso solo sull'ultimo
        else if (isEasy(g) && "work".equals(nk) && !isEasy(nx)) lead = 15;
        else return;
        double left;
        if (min > 0) { if (min * 60 < lead * 2) return; left = Math.round(min * 60) - secIn; }
        else if (km > 0) {
            double pace = S.paceNow > 0 ? S.paceNow : kmIn > 0.05 ? secIn / kmIn : 0;
            if (pace <= 0 || secIn < 15) return;
            left = (km - kmIn) * pace;
        } else return;
        if (left > lead || left <= 0) return;
        warnedSeg = segIdx;
        vibrate(new long[]{0, 250, 120, 250, 120, 250});
        if (lead == 30) say((min > 0 ? "Mancano 30 secondi" : "Circa 30 secondi") + " alla fine del riscaldamento, preparati");
        else say("15 secondi a " + S.phName[segIdx + 1].toLowerCase(Locale.ITALY) + ", preparati");
    }
    private static String fmtPace(double sec) { long p = Math.round(sec); return (p / 60) + ":" + (p % 60 < 10 ? "0" : "") + (p % 60); }

    /** Pausa o ripresa (pulsante a schermo o tasto dell'orologio). */
    static void togglePause(Context c) { Intent i = new Intent(c, RunService.class); i.setAction(S.paused ? ACTION_RESUME : ACTION_PAUSE); c.startService(i); }

    /** Pausa automatica da fermo: niente movimento per 5 secondi → pausa; 2 secondi di movimento → si riparte.
     *  Il movimento lo legge l'accelerometro dell'orologio (vale anche la camminata). Non nei recuperi e nel defaticamento,
     *  dove stare fermi fa parte dell'allenamento. */
    private void checkAutoPause() {
        if (dyn == null || dyn.lastMove() == 0) return;
        long now = System.currentTimeMillis(); String k = curKind();
        boolean allowed = S.activeSec >= 20 && !autoEnding && !S.drill && !S.techOffer && !"recovery".equals(k) && !"cooldown".equals(k);
        if (!S.autoPaused) {
            if (allowed && now - dyn.lastMove() > 5000) { S.autoPaused = true; S.paceNow = 0; rN = 0; rPos = 0; vibrate(new long[]{0, 300}); say("Pausa automatica"); updateNotif(); }
        } else if (!allowed || (now - dyn.lastMove() < 700 && now - dyn.moveStart() >= 2000)) {
            S.autoPaused = false; vibrate(new long[]{0, 120, 100, 120}); say("Si riparte"); updateNotif();
        }
    }

    private void pause() { if (!S.running || S.paused || ex == null) return; S.autoPaused = false; S.paused = true; S.paceNow = 0; rN = 0; rPos = 0; ex.pauseExerciseAsync(); if (dyn != null) dyn.setActive(false); vibrate(new long[]{0, 300}); say("Corsa in pausa"); updateNotif(); notifyUi(); }
    private void resume() { if (!S.running || !S.paused || ex == null) return; S.paused = false; S.autoPaused = false; ex.resumeExerciseAsync(); if (dyn != null) dyn.setActive(true); vibrate(new long[]{0, 120, 100, 120}); say("Si riparte"); updateNotif(); notifyUi(); }

    private void stop() {
        if (S.recovering) { finishRecovery(); return; }   // FINE durante il recupero: salto la misura
        if (!S.running) { stopSelf(); return; }
        h.removeCallbacksAndMessages(null);
        stopAt = System.currentTimeMillis();
        if (S.activeSec % 5 != 0) addPoint();
        if (dyn != null) dyn.stop();
        say(String.format(Locale.ITALY, "Corsa finita: %s chilometri in %d minuti", String.format(Locale.ITALY, "%.1f", S.km).replace(",", " virgola "), S.activeSec / 60)
            + (S.samples > 0 ? ", battito medio " + Math.round((double) S.sumHr / S.samples) : "") + ". Misuro il recupero per un minuto");
        frozen = summary();
        S.running = false; S.paused = false; S.recovering = true; S.recLeft = REC_SEC; recSec = 0; rec.clear();
        boolean fresh = System.currentTimeMillis() - S.lastBeat < 5000 && S.bpm > 0;
        if (fresh) rec.add(new int[]{ 0, S.bpm });
        vibrate(new long[]{0, 300, 150, 300});
        updateNotif(); notifyUi();
        h.postDelayed(tick, 1000);
    }

    /** Fine della misura del recupero (o salto): chiudo l'allenamento e mando tutto al telefono. */
    private void finishRecovery() {
        if (!S.recovering) return;
        h.removeCallbacksAndMessages(null);
        say("Recupero misurato, riepilogo inviato al telefono");
        S.recovering = false; S.finished = true; S.recLeft = 0;
        try { if (ex != null) ex.endExerciseAsync(); } catch (Exception ignored) {}
        stopStrap();
        try { if (wl != null && wl.isHeld()) wl.release(); } catch (Exception ignored) {}
        String json;
        try {
            JSONObject o = frozen != null ? frozen : summary();
            JSONArray r = new JSONArray(); for (int[] x : rec) r.put(new JSONArray().put(x[0]).put(x[1])); o.put("rec", r);
            json = o.toString();
        } catch (Exception e) { json = "{}"; }
        // il messaggio all'orologio ha un limite di circa 100 KB: se il percorso è lunghissimo lo alleggerisco
        if (json.length() > 90000) { try { JSONObject o = new JSONObject(json); o.put("tr", track(400)); json = o.toString(); } catch (Exception ignored) {} }
        // la corsa del piano è fatta: la prossima volta l'orologio parte da "Corsa libera" finché il telefono non ne manda un'altra
        getSharedPreferences("hf", MODE_PRIVATE).edit().putString("unsent", json).remove("plan").apply();
        sendToPhone(this, json);
        vibrate(new long[]{0, 200});
        notifyUi();
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE);
        // lascio il tempo di finire la frase prima di chiudere
        h.postDelayed(() -> { if (S.running || S.recovering) return; if (voice != null) { voice.shutdown(); voice = null; } stopSelf(); }, 8000);
    }

    private JSONObject summary() {
        JSONObject o = new JSONObject();
        try {
            o.put("title", S.title); o.put("startedAt", S.startedAt); o.put("seconds", S.activeSec);
            o.put("totalSec", Math.max(S.activeSec, ((stopAt > 0 ? stopAt : System.currentTimeMillis()) - S.startedAt) / 1000));
            o.put("km", Math.round(S.km * 100) / 100.0); o.put("kcal", Math.round(S.kcal));
            o.put("avgHr", S.samples > 0 ? Math.round((double) S.sumHr / S.samples) : 0); o.put("maxHr", S.maxHr);
            JSONArray z = new JSONArray(); for (long v : S.zoneSec) z.put(v); o.put("zoneSec", z);
            o.put("hrSrc", S.strapSec > 0 && S.watchSec > 0 ? "mixed" : S.strapSec > 0 ? "strap" : "watch");
            o.put("hrMax", S.hrMax);
            if (hrCap > 0) { o.put("hrCap", hrCap); o.put("capSec", capSec); o.put("capOver", capOverSec); }
            if (stepsTot >= 0) o.put("steps", stepsTot);
            if (elevGain >= 0) o.put("elevGain", Math.round(elevGain));
            if (elevLoss >= 0) o.put("elevLoss", Math.round(elevLoss));
            o.put("tr", track(900));
            JSONObject dj = dyn != null ? dyn.summary() : null; if (dj != null) o.put("dyn", dj);
            if (ref != null) o.put("ref", ref);
            o.put("source", "watch");
        } catch (Exception ignored) {}
        return o;
    }

    /** Percorso a colonne (al massimo n punti: se sono di più ne tengo uno ogni k, più l'ultimo). */
    private JSONObject track(int n) {
        JSONObject t = new JSONObject();
        try {
            int k = Math.max(1, (int) Math.ceil(trk.size() / (double) n));
            String[] keys = {"t", "m", "h", "a", "s", "la", "lo"};
            JSONArray[] cols = new JSONArray[keys.length];
            for (int c = 0; c < keys.length; c++) cols[c] = new JSONArray();
            for (int i = 0; i < trk.size(); i++) {
                if (i % k != 0 && i != trk.size() - 1) continue;
                int[] p = trk.get(i);
                for (int c = 0; c < keys.length; c++) cols[c].put(p[c]);
            }
            for (int c = 0; c < keys.length; c++) t.put(keys[c], cols[c]);
        } catch (Exception ignored) {}
        return t;
    }

    /** Manda il riepilogo al telefono (se non è raggiungibile resta salvato e riprova all'apertura dell'app). */
    static void sendToPhone(Context ctx, String json) {
        final byte[] data = json.getBytes(StandardCharsets.UTF_8);
        Wearable.getNodeClient(ctx).getConnectedNodes().addOnSuccessListener(nodes -> {
            for (Node n : nodes) {
                Wearable.getMessageClient(ctx).sendMessage(n.getId(), "/healthfit/result", data)
                    .addOnSuccessListener(r -> ctx.getSharedPreferences("hf", MODE_PRIVATE).edit().remove("unsent").apply());
            }
        });
    }

    private void vibrate(long[] pat) {
        try { Vibrator vb = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE); if (vb == null) return;
            vb.vibrate(VibrationEffect.createWaveform(pat, -1)); } catch (Exception ignored) {}
    }
    static void notifyUi() { if (listener != null) { try { listener.onUpdate(); } catch (Exception ignored) {} } }

    private void createChannel() {
        NotificationChannel ch = new NotificationChannel(CHANNEL, "Corsa in corso", NotificationManager.IMPORTANCE_LOW);
        ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
    }
    private Notification notif(String text) {
        Intent open = new Intent(this, WatchActivity.class); open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new NotificationCompat.Builder(this, CHANNEL).setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("HealthFit · " + S.title).setContentText(text).setOngoing(true).setOnlyAlertOnce(true)
            .setContentIntent(pi).setCategory(NotificationCompat.CATEGORY_SERVICE).build();
    }
    private void updateNotif() {
        if (S.recovering) { ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).notify(NOTIF, notif("Recupero del battito: ancora " + S.recLeft + " s" + (S.bpm > 0 ? " · " + S.bpm + " bpm" : ""))); return; }
        long m = S.activeSec / 60, s = S.activeSec % 60;
        String t = (S.paused || S.autoPaused ? "⏸ " : "") + m + ":" + (s < 10 ? "0" : "") + s + (S.bpm > 0 ? " · " + S.bpm + " bpm" : "") + (S.km > 0.05 ? String.format(Locale.ITALY, " · %.2f km", S.km) : "");
        ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).notify(NOTIF, notif(t));
    }

    @Override public void onDestroy() { h.removeCallbacksAndMessages(null); if (dyn != null) dyn.stop(); if (S.running || S.recovering) stopStrap(); if (voice != null) voice.shutdown(); super.onDestroy(); }
}
