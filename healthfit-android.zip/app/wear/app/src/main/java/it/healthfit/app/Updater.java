package it.healthfit.app;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInstaller;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * Aggiornamento dall'orologio, senza PC: legge l'ultima versione pubblicata su GitHub,
 * scarica HealthFit-orologio.apk e lo installa (basta confermare con un tocco sul polso).
 */
final class Updater {
    interface Status { void on(String msg, boolean busy); }
    static final String LATEST = "https://api.github.com/repos/health-fitness-app/health-fitness/releases/latest";
    static final String ASSET = "HealthFit-orologio.apk";
    static volatile boolean busy = false;

    static long current(Context c) {
        try { return c.getPackageManager().getPackageInfo(c.getPackageName(), 0).getLongVersionCode(); } catch (Exception e) { return 0; }
    }

    static void run(Context ctx, Status st) {
        if (busy) return;
        final Context c = ctx.getApplicationContext(); final Handler h = new Handler(Looper.getMainLooper());
        if (!c.getPackageManager().canRequestPackageInstalls()) {   // una volta sola: "consenti da questa fonte"
            st.on("Consenti a HealthFit di installare app, poi torna qui e tocca di nuovo AGGIORNA", false);
            try { Intent i = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + c.getPackageName())); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); c.startActivity(i); } catch (Exception ignored) {}
            return;
        }
        busy = true; st.on("Cerco la nuova versione…", true);
        new Thread(() -> {
            String msg; boolean ok = false;
            try {
                JSONObject rel = new JSONObject(new String(get(LATEST), StandardCharsets.UTF_8));
                long n = 0; try { n = Long.parseLong(rel.optString("tag_name", "").replaceAll("\\D", "")); } catch (Exception ignored) {}
                long cur = current(c);
                String url = null; JSONArray as = rel.optJSONArray("assets");
                for (int i = 0; as != null && i < as.length(); i++) { JSONObject a = as.optJSONObject(i); if (a != null && ASSET.equals(a.optString("name"))) url = a.optString("browser_download_url"); }
                if (n <= cur || url == null) msg = "Hai già l'ultima versione (1." + cur + ") ✓";
                else {
                    final long nn = n; h.post(() -> st.on("Scarico la versione 1." + nn + "…", true));
                    install(c, url, n); ok = true; msg = "Conferma l'installazione sull'orologio";
                }
            } catch (Exception e) { msg = "Aggiornamento non riuscito: " + (e.getMessage() == null ? "rete assente" : e.getMessage()); }
            busy = false; final String m = msg; final boolean o = ok; h.post(() -> st.on(m, o));
        }).start();
    }

    private static HttpURLConnection open(String u) throws Exception {
        HttpURLConnection k = (HttpURLConnection) new URL(u).openConnection();
        k.setConnectTimeout(15000); k.setReadTimeout(30000); k.setInstanceFollowRedirects(true);
        k.setRequestProperty("User-Agent", "HealthFit-Watch"); k.setRequestProperty("Accept", "application/vnd.github+json, */*");
        if (k.getResponseCode() >= 400) throw new Exception("GitHub risponde " + k.getResponseCode());
        return k;
    }
    private static byte[] get(String u) throws Exception {
        HttpURLConnection k = open(u);
        try (InputStream in = k.getInputStream()) { ByteArrayOutputStream b = new ByteArrayOutputStream(); byte[] buf = new byte[8192]; int r; while ((r = in.read(buf)) > 0) b.write(buf, 0, r); return b.toByteArray(); }
    }

    /** Scarica l'APK direttamente dentro una sessione di installazione: Android chiede poi la conferma. */
    private static void install(Context c, String url, long n) throws Exception {
        PackageInstaller pi = c.getPackageManager().getPackageInstaller();
        PackageInstaller.SessionParams sp = new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);
        sp.setAppPackageName(c.getPackageName());
        int id = pi.createSession(sp);
        try (PackageInstaller.Session s = pi.openSession(id)) {
            HttpURLConnection k = open(url);
            try (InputStream in = k.getInputStream(); OutputStream out = s.openWrite("healthfit.apk", 0, -1)) {
                byte[] buf = new byte[65536]; int r; while ((r = in.read(buf)) > 0) out.write(buf, 0, r); s.fsync(out);
            }
            Intent i = new Intent(c, Done.class);
            PendingIntent p = PendingIntent.getBroadcast(c, id, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_MUTABLE);
            s.commit(p.getIntentSender());
        } catch (Exception e) { try { pi.abandonSession(id); } catch (Exception ignored) {} throw e; }
    }

    /** Risposta del sistema: se serve la conferma dell'utente apre la schermata "Installa". */
    public static class Done extends BroadcastReceiver {
        @Override public void onReceive(Context c, Intent i) {
            int st = i.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE);
            if (st == PackageInstaller.STATUS_PENDING_USER_ACTION) {
                @SuppressWarnings("deprecation") Intent confirm = i.getParcelableExtra(Intent.EXTRA_INTENT);
                if (confirm != null) { confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); try { c.startActivity(confirm); } catch (Exception ignored) {} }
            } else if (st != PackageInstaller.STATUS_SUCCESS) {
                c.getSharedPreferences("hf", Context.MODE_PRIVATE).edit().putString("updErr", "Installazione non riuscita: " + i.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE)).apply();
                RunService.notifyUi();
            }
        }
    }
}
