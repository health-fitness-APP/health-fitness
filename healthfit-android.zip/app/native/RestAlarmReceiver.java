package it.healthfit.app;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;

/** Scatta a fine riposo: bip come nell'app (volume sveglia), vibrazione e notifica "si riparte". */
public class RestAlarmReceiver extends BroadcastReceiver {
    private static final int RATE = 22050;

    @Override public void onReceive(Context ctx, Intent intent) {
        boolean sound = intent.getBooleanExtra("sound", true), vibrate = intent.getBooleanExtra("vibrate", true);
        final PendingResult pr = goAsync();
        PowerManager pm = (PowerManager) ctx.getSystemService(Context.POWER_SERVICE);
        final PowerManager.WakeLock wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "healthfit:rest");
        wl.acquire(6000);
        notifyDone(ctx);
        if (vibrate) vibrate(ctx);
        AudioTrack t = null;
        if (sound) { try { t = beeps(); t.play(); } catch (Exception ignored) { t = null; } }
        final AudioTrack track = t;
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            try { if (track != null) { track.stop(); track.release(); } } catch (Exception ignored) { }
            try { if (wl.isHeld()) wl.release(); } catch (Exception ignored) { }
            pr.finish();
        }, 2600);
    }

    private static void notifyDone(Context ctx) {
        try {
            RestTimerPlugin.channels(ctx);
            Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(ctx, RestTimerPlugin.CH_DONE) : new Notification.Builder(ctx);
            b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("Riposo finito: si riparte! 💪")
                .setContentText("Tocca per tornare all'allenamento")
                .setCategory(Notification.CATEGORY_ALARM)
                .setPriority(Notification.PRIORITY_HIGH)
                .setAutoCancel(true).setTimeoutAfter(120000)
                .setContentIntent(RestTimerPlugin.openApp(ctx));
            ((NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE)).notify(RestTimerPlugin.NOTIF_ID, b.build());
        } catch (Exception ignored) { }
    }

    private static void vibrate(Context ctx) {
        try {
            Vibrator v = (Vibrator) ctx.getSystemService(Context.VIBRATOR_SERVICE);
            if (v == null) return;
            long[] pat = { 0, 400, 150, 400, 150, 400 };
            AudioAttributes aa = new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build();
            v.vibrate(VibrationEffect.createWaveform(pat, -1), aa);
        } catch (Exception ignored) { }
    }

    /** Sei bip a onda quadra (3 a 880 Hz, 3 a 1175 Hz), uguali a quelli dell'app web. */
    private static AudioTrack beeps() {
        float[] at = { 0f, 0.35f, 0.7f, 1.2f, 1.55f, 1.9f };
        int n = (int) (RATE * 2.25f);
        short[] pcm = new short[n];
        for (float s : at) {
            double f = s < 1f ? 880 : 1175;
            int i0 = (int) (s * RATE), len = (int) (0.25f * RATE);
            for (int k = 0; k < len && i0 + k < n; k++) {
                double tt = (double) k / RATE;
                double env = Math.min(1.0, tt / 0.02) * Math.max(0.0, 1.0 - Math.max(0.0, tt - 0.03) / 0.22);
                double sq = Math.sin(2 * Math.PI * f * tt) >= 0 ? 1 : -1;
                pcm[i0 + k] = (short) (sq * env * 0.45 * Short.MAX_VALUE);
            }
        }
        AudioAttributes aa = new AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
        AudioFormat fmt = new AudioFormat.Builder().setSampleRate(RATE)
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build();
        AudioTrack t = new AudioTrack(aa, fmt, n * 2, AudioTrack.MODE_STATIC, android.media.AudioManager.AUDIO_SESSION_ID_GENERATE);
        t.write(pcm, 0, n);
        return t;
    }
}
