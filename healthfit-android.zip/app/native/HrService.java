package it.healthfit.app;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.location.Location;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.speech.tts.UtteranceProgressListener;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.speech.tts.TextToSpeech;

import androidx.core.app.NotificationCompat;
import androidx.core.app.ServiceCompat;

import java.util.Locale;
import java.util.UUID;

/**
 * HealthFit: registra la corsa con la fascia cardio anche a schermo spento.
 * Tiene collegata la fascia (servizio Bluetooth standard Heart Rate), misura la distanza con il GPS,
 * conta il tempo in ogni zona e avvisa a voce e con vibrazione se si esce dalla zona obiettivo.
 */
public class HrService extends Service {
    public static final String ACTION_START = "it.healthfit.HR_START";
    public static final String ACTION_STOP = "it.healthfit.HR_STOP";
    public static final String ACTION_PAUSE = "it.healthfit.HR_PAUSE";
    public static final String ACTION_RESUME = "it.healthfit.HR_RESUME";

    static final UUID HR_SERVICE = UUID.fromString("0000180d-0000-1000-8000-00805f9b34fb");
    static final UUID HR_MEASURE = UUID.fromString("00002a37-0000-1000-8000-00805f9b34fb");
    static final UUID CCC = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
    static final String CHANNEL = "healthfit_run";
    static final int NOTIF_ID = 4711;

    /** Stato condiviso con il plugin (letto anche quando l'app torna in primo piano). */
    public static final class State {
        public boolean running, paused, connected;
        public String title = "Corsa", deviceName = "";
        public int bpm, maxHr, zoneLo = -1, zoneHi = -1, hrMax = 185;
        public long lastBeat, samples, sumHr, elapsedSec;
        public double km;
        public long[] zoneSec = new long[5];
        public long startedAt;
    }
    public static final State S = new State();
    public interface Listener { void onTick(State s); }
    public static Listener listener;

    private final Handler h = new Handler(Looper.getMainLooper());
    private BluetoothGatt gatt;
    private String address;
    private LocationManager lm;
    private Location last;
    private TextToSpeech tts;
    private boolean ttsReady, alerts = true, gps = true;
    private PowerManager.WakeLock wl;
    private long outSince = 0, lastAlert = 0;
    private int lastKmSpoken = 0, reconnects = 0;
    // abbassa la musica (Spotify, YouTube…) mentre l'app parla, poi la riporta al volume normale
    private AudioManager am;
    private AudioFocusRequest focusReq;
    private int speaking = 0;
    private final AudioManager.OnAudioFocusChangeListener focusL = fc -> {};

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String a = intent != null ? intent.getAction() : null;
        if (ACTION_START.equals(a)) start(intent);
        else if (ACTION_PAUSE.equals(a)) { S.paused = true; last = null; notifyUpdate(true); }
        else if (ACTION_RESUME.equals(a)) { S.paused = false; notifyUpdate(true); }
        else if (ACTION_STOP.equals(a)) { stopAll(); }
        return START_STICKY;
    }

    private void start(Intent it) {
        address = it.getStringExtra("address");
        S.title = it.getStringExtra("title") != null ? it.getStringExtra("title") : "Corsa";
        S.zoneLo = it.getIntExtra("lo", -1); S.zoneHi = it.getIntExtra("hi", -1); S.hrMax = it.getIntExtra("hrMax", 185);
        alerts = it.getBooleanExtra("alerts", true); gps = it.getBooleanExtra("gps", true);
        S.running = true; S.paused = false; S.bpm = 0; S.maxHr = 0; S.samples = 0; S.sumHr = 0; S.elapsedSec = 0; S.km = 0;
        S.zoneSec = new long[5]; S.startedAt = System.currentTimeMillis(); lastKmSpoken = 0; reconnects = 0; last = null;

        createChannel();
        int type = 0;
        if (Build.VERSION.SDK_INT >= 29) {
            type = ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE;
            if (gps) type |= ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION;
        }
        ServiceCompat.startForeground(this, NOTIF_ID, buildNotif("Avvio…"), type);

        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "healthfit:run");
        wl.acquire(6 * 60 * 60 * 1000L);

        am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        tts = new TextToSpeech(this, st -> { if (st == TextToSpeech.SUCCESS) {
            tts.setLanguage(Locale.ITALIAN);
            tts.setAudioAttributes(new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build());
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String id) {}
                @Override public void onDone(String id) { h.post(() -> { speaking = Math.max(0, speaking - 1); if (speaking == 0) releaseFocus(); }); }
                @SuppressWarnings("deprecation")
                @Override public void onError(String id) { onDone(id); }
            });
            ttsReady = true; } });
        if (address != null && !address.isEmpty()) connectGatt();
        if (gps) startGps();
        h.removeCallbacks(tick); h.postDelayed(tick, 1000);
    }

    // ---------- fascia cardio ----------
    @SuppressLint("MissingPermission")
    private void connectGatt() {
        try {
            BluetoothManager bm = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
            BluetoothAdapter ad = bm.getAdapter();
            if (ad == null || !ad.isEnabled()) return;
            BluetoothDevice dev = ad.getRemoteDevice(address);
            S.deviceName = dev.getName() != null ? dev.getName() : "Fascia";
            if (gatt != null) { try { gatt.close(); } catch (Exception ignored) {} }
            gatt = dev.connectGatt(this, false, cb, BluetoothDevice.TRANSPORT_LE);
        } catch (Exception e) { /* riprova al prossimo giro */ }
    }

    private final BluetoothGattCallback cb = new BluetoothGattCallback() {
        @SuppressLint("MissingPermission")
        @Override public void onConnectionStateChange(BluetoothGatt g, int status, int newState) {
            if (newState == BluetoothProfile.STATE_CONNECTED) { S.connected = true; reconnects = 0; g.discoverServices(); }
            else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                S.connected = false;
                if (S.running && reconnects < 40) { reconnects++; h.postDelayed(() -> { if (S.running) connectGatt(); }, Math.min(15000, 1500L * reconnects)); }
            }
        }
        @SuppressLint("MissingPermission")
        @Override public void onServicesDiscovered(BluetoothGatt g, int status) {
            BluetoothGattService s = g.getService(HR_SERVICE); if (s == null) return;
            BluetoothGattCharacteristic c = s.getCharacteristic(HR_MEASURE); if (c == null) return;
            g.setCharacteristicNotification(c, true);
            BluetoothGattDescriptor d = c.getDescriptor(CCC);
            if (d != null) {
                if (Build.VERSION.SDK_INT >= 33) g.writeDescriptor(d, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                else { d.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE); g.writeDescriptor(d); }
            }
        }
        @Override public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic c, byte[] v) { parse(v); }
        @SuppressWarnings("deprecation")
        @Override public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic c) { if (Build.VERSION.SDK_INT < 33) parse(c.getValue()); }
    };

    private void parse(byte[] v) {
        if (v == null || v.length < 2) return;
        int flags = v[0] & 0xff;
        int bpm = (flags & 1) != 0 && v.length >= 3 ? ((v[1] & 0xff) | ((v[2] & 0xff) << 8)) : (v[1] & 0xff);
        if (bpm > 25 && bpm < 240) { S.bpm = bpm; S.lastBeat = System.currentTimeMillis(); }
    }

    // ---------- GPS ----------
    @SuppressLint("MissingPermission")
    private void startGps() {
        try {
            lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 0, locL, Looper.getMainLooper());
        } catch (Exception e) { /* senza GPS si continua con il solo battito */ }
    }
    private final LocationListener locL = new LocationListener() {
        @Override public void onLocationChanged(Location l) {
            if (!S.running || S.paused) { last = null; return; }
            if (l.hasAccuracy() && l.getAccuracy() > 25) return;
            if (last != null) { double d = last.distanceTo(l) / 1000.0; if (d > 0.002 && d < 0.15) S.km += d; }
            last = l;
        }
        @Override public void onStatusChanged(String p, int s, Bundle b) {}
        @Override public void onProviderEnabled(String p) {}
        @Override public void onProviderDisabled(String p) {}
    };

    // ---------- ogni secondo ----------
    private int zoneOf(int b) { double pc = b / (double) S.hrMax; return pc < 0.6 ? 0 : pc < 0.7 ? 1 : pc < 0.8 ? 2 : pc < 0.9 ? 3 : 4; }
    private final Runnable tick = new Runnable() { @Override public void run() {
        if (!S.running) return;
        if (!S.paused) {
            S.elapsedSec++;
            boolean fresh = System.currentTimeMillis() - S.lastBeat < 5000;
            if (fresh && S.bpm > 0) {
                int z = zoneOf(S.bpm); S.sumHr += S.bpm; S.samples++; S.maxHr = Math.max(S.maxHr, S.bpm); S.zoneSec[z]++;
                checkZone(z);
            }
            int kmInt = (int) Math.floor(S.km);
            if (kmInt > lastKmSpoken && kmInt >= 1) { lastKmSpoken = kmInt; speakKm(kmInt); }
        }
        if (S.elapsedSec % 5 == 0 || S.paused) notifyUpdate(false);
        if (listener != null) { try { listener.onTick(S); } catch (Exception ignored) {} }
        h.postDelayed(this, 1000);
    }};

    private void checkZone(int z) {
        if (S.zoneLo < 0 || !alerts) return;
        long now = System.currentTimeMillis();
        boolean hard = S.zoneLo >= 3;
        if (z > S.zoneHi) {
            if (outSince == 0) outSince = now;
            if (now - outSince > 20000) alert(hard ? "Battito molto alto, rallenta un attimo" : "Rallenta, sei sopra la zona facile");
        } else if (hard && z < S.zoneLo) {
            if (outSince == 0) outSince = now;
            if (now - outSince > 60000) alert("Puoi spingere un po' di più");
        } else outSince = 0;
    }
    private void alert(String msg) {
        long now = System.currentTimeMillis(); if (now - lastAlert < 45000) return; lastAlert = now;
        vibrate(); say(msg);
    }
    private void speakKm(int k) {
        long sec = S.elapsedSec; String pace = "";
        if (S.km > 0.2) { long p = Math.round(sec / S.km); pace = ", ritmo medio " + (p / 60) + " e " + (p % 60); }
        say(k + (k == 1 ? " chilometro" : " chilometri") + pace + (S.bpm > 0 ? ", battito " + S.bpm : ""));
    }
    private void say(String msg) {
        if (!ttsReady) return;
        if (speaking == 0) requestFocus();
        speaking++;
        tts.speak(msg, TextToSpeech.QUEUE_ADD, null, "hf" + System.currentTimeMillis());
    }
    @SuppressWarnings("deprecation")
    private void requestFocus() {
        try {
            if (am == null) return;
            if (Build.VERSION.SDK_INT >= 26) {
                focusReq = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                    .setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                    .setOnAudioFocusChangeListener(focusL).build();
                am.requestAudioFocus(focusReq);
            } else am.requestAudioFocus(focusL, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK);
        } catch (Exception ignored) {}
    }
    @SuppressWarnings("deprecation")
    private void releaseFocus() {
        try {
            if (am == null) return;
            if (Build.VERSION.SDK_INT >= 26) { if (focusReq != null) am.abandonAudioFocusRequest(focusReq); }
            else am.abandonAudioFocus(focusL);
        } catch (Exception ignored) {}
    }
    @SuppressWarnings("deprecation")
    private void vibrate() {
        try { Vibrator vb = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE); if (vb == null) return;
            long[] pat = {0, 300, 150, 300};
            if (Build.VERSION.SDK_INT >= 26) vb.vibrate(VibrationEffect.createWaveform(pat, -1)); else vb.vibrate(pat, -1);
        } catch (Exception ignored) {}
    }

    // ---------- notifica fissa ----------
    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Corsa in corso", NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("Registrazione della corsa con la fascia cardio");
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
    }
    private Notification buildNotif(String text) {
        Intent open = new Intent(this, MainActivity.class); open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("HealthFit · " + S.title)
            .setContentText(text).setOngoing(true).setOnlyAlertOnce(true).setContentIntent(pi)
            .setCategory(NotificationCompat.CATEGORY_SERVICE).build();
    }
    private void notifyUpdate(boolean force) {
        long m = S.elapsedSec / 60, s = S.elapsedSec % 60;
        String t = (S.paused ? "⏸ In pausa · " : "") + m + ":" + (s < 10 ? "0" : "") + s
            + (S.bpm > 0 && System.currentTimeMillis() - S.lastBeat < 5000 ? " · " + S.bpm + " bpm" : (S.connected ? "" : " · fascia non collegata"))
            + (S.km > 0.05 ? String.format(Locale.ITALY, " · %.2f km", S.km) : "");
        ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).notify(NOTIF_ID, buildNotif(t));
    }

    @SuppressLint("MissingPermission")
    private void stopAll() {
        S.running = false; h.removeCallbacks(tick);
        try { if (lm != null) lm.removeUpdates(locL); } catch (Exception ignored) {}
        try { if (gatt != null) { gatt.disconnect(); gatt.close(); } } catch (Exception ignored) {}
        gatt = null; S.connected = false;
        try { if (tts != null) tts.shutdown(); } catch (Exception ignored) {}
        speaking = 0; releaseFocus();
        try { if (wl != null && wl.isHeld()) wl.release(); } catch (Exception ignored) {}
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    @Override public void onDestroy() { if (S.running) stopAll(); super.onDestroy(); }
}
