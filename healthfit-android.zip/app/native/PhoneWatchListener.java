package it.healthfit.app;

import android.content.Context;
import android.content.SharedPreferences;

import com.google.android.gms.wearable.MessageEvent;
import com.google.android.gms.wearable.WearableListenerService;

import org.json.JSONArray;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;

/** Riceve dal Galaxy Watch il riepilogo della corsa (anche con l'app chiusa) e lo tiene finché HealthFit lo salva. */
public class PhoneWatchListener extends WearableListenerService {
    @Override public void onMessageReceived(MessageEvent ev) {
        if (!"/healthfit/result".equals(ev.getPath())) return;
        try {
            JSONObject o = new JSONObject(new String(ev.getData(), StandardCharsets.UTF_8));
            SharedPreferences p = getSharedPreferences("hf_watch", Context.MODE_PRIVATE);
            JSONArray a = new JSONArray(p.getString("results", "[]"));
            a.put(o); p.edit().putString("results", a.toString()).apply();
            if (WatchBridgePlugin.instance != null) WatchBridgePlugin.instance.emit(o);
        } catch (Exception ignored) {}
    }
}
