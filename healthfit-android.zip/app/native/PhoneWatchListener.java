package it.healthfit.app;

import android.content.Context;
import android.content.SharedPreferences;

import com.google.android.gms.wearable.DataEvent;
import com.google.android.gms.wearable.DataEventBuffer;
import com.google.android.gms.wearable.DataItem;
import com.google.android.gms.wearable.MessageEvent;
import com.google.android.gms.wearable.WearableListenerService;

import org.json.JSONArray;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;

/** Riceve dal Galaxy Watch il riepilogo della corsa (anche con l'app chiusa) e lo tiene finché HealthFit lo salva; legge ad alta voce i messaggi della corsa. */
public class PhoneWatchListener extends WearableListenerService {
    @Override public void onMessageReceived(MessageEvent ev) {
        if ("/healthfit/say".equals(ev.getPath())) { WatchSpeaker.say(this, new String(ev.getData(), StandardCharsets.UTF_8)); return; }
        if (!"/healthfit/result".equals(ev.getPath())) return;
        keep(new String(ev.getData(), StandardCharsets.UTF_8));
    }

    /** Misure 24 ore arrivate come dato sincronizzato (Wear OS le consegna anche se al momento il telefono non era raggiungibile). */
    @Override public void onDataChanged(DataEventBuffer events) {
        for (DataEvent e : events) {
            try {
                if (e.getType() != DataEvent.TYPE_CHANGED) continue;
                DataItem it = e.getDataItem();
                if (!"/healthfit/passive".equals(it.getUri().getPath()) || it.getData() == null) continue;
                keep(new String(it.getData(), StandardCharsets.UTF_8));
            } catch (Exception ignored) {}
        }
    }

    private synchronized void keep(String json) {
        try {
            JSONObject o = new JSONObject(json);
            SharedPreferences p = getSharedPreferences("hf_watch", Context.MODE_PRIVATE);
            if ("passive".equals(o.optString("kind"))) {
                // stesso pacchetto arrivato due volte (messaggio + dato): lo tengo una volta sola; tengo solo il più recente in coda
                long at = o.optLong("at", 0);
                if (at > 0 && at <= p.getLong("passiveAt", 0)) return;
                p.edit().putLong("passiveAt", at).putLong("passiveRx", System.currentTimeMillis()).apply();
                JSONArray a0 = new JSONArray(p.getString("results", "[]")), a = new JSONArray();
                for (int i = 0; i < a0.length(); i++) { JSONObject x = a0.optJSONObject(i); if (x != null && !"passive".equals(x.optString("kind"))) a.put(x); }
                a.put(o); p.edit().putString("results", a.toString()).apply();
            } else {
                JSONArray a = new JSONArray(p.getString("results", "[]"));
                a.put(o); p.edit().putString("results", a.toString()).apply();
            }
            if (WatchBridgePlugin.instance != null) WatchBridgePlugin.instance.emit(o);
        } catch (Exception ignored) {}
    }
}
