package it.healthfit.app;

import android.Manifest;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;

import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;

/** Sveglia di fine riposo: suona e vibra anche con l'app in background o lo schermo spento. */
@CapacitorPlugin(
    name = "RestTimer",
    permissions = { @Permission(alias = "notif", strings = { Manifest.permission.POST_NOTIFICATIONS }) }
)
public class RestTimerPlugin extends Plugin {
    static final String CH_COUNT = "hf_rest_count", CH_DONE = "hf_rest_done";
    static final int NOTIF_ID = 4711;

    @PluginMethod public void isAvailable(PluginCall call) {
        JSObject r = new JSObject(); r.put("available", true); r.put("version", 1); call.resolve(r);
    }

    @PluginMethod public void requestPerms(PluginCall call) {
        if (Build.VERSION.SDK_INT >= 33 && getPermissionState("notif") != PermissionState.GRANTED) {
            requestPermissionForAlias("notif", call, "permsCb");
        } else permsCb(call);
    }
    @PermissionCallback private void permsCb(PluginCall call) {
        JSObject r = new JSObject();
        r.put("notif", Build.VERSION.SDK_INT < 33 || getPermissionState("notif") == PermissionState.GRANTED);
        call.resolve(r);
    }

    /** at = fine del riposo (millisecondi epoch); sound/vibrate = cosa fare allo scadere. */
    @PluginMethod public void schedule(PluginCall call) {
        Long at = call.getLong("at");
        if (at == null) { call.reject("at mancante"); return; }
        boolean sound = call.getBoolean("sound", true), vibrate = call.getBoolean("vibrate", true);
        Context ctx = getContext();
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi = alarmIntent(ctx, sound, vibrate);
        am.cancel(pi);
        boolean exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms();
        try {
            if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
        } catch (SecurityException e) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi); exact = false;
        }
        showCountdown(ctx, at);
        JSObject r = new JSObject(); r.put("ok", true); r.put("exact", exact); call.resolve(r);
    }

    @PluginMethod public void cancel(PluginCall call) {
        Context ctx = getContext();
        ((AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE)).cancel(alarmIntent(ctx, true, true));
        ((NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE)).cancel(NOTIF_ID);
        call.resolve();
    }

    private static PendingIntent alarmIntent(Context ctx, boolean sound, boolean vibrate) {
        Intent i = new Intent(ctx, RestAlarmReceiver.class);
        i.putExtra("sound", sound); i.putExtra("vibrate", vibrate);
        return PendingIntent.getBroadcast(ctx, 0, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    static void channels(Context ctx) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationChannel c = new NotificationChannel(CH_COUNT, "Recupero in corso", NotificationManager.IMPORTANCE_LOW);
        c.setShowBadge(false);
        nm.createNotificationChannel(c);
        // il suono e la vibrazione li fa l'app (si possono spegnere dall'app), il canale resta muto
        NotificationChannel d = new NotificationChannel(CH_DONE, "Fine del recupero", NotificationManager.IMPORTANCE_HIGH);
        d.setSound(null, null); d.enableVibration(false); d.setShowBadge(false);
        nm.createNotificationChannel(d);
    }

    static PendingIntent openApp(Context ctx) {
        Intent open = new Intent(ctx, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(ctx, 1, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private static void showCountdown(Context ctx, long at) {
        try {
            channels(ctx);
            Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(ctx, CH_COUNT) : new Notification.Builder(ctx);
            b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("⏱ Recupero")
                .setContentText("Ti avviso io quando è ora di ripartire")
                .setWhen(at).setShowWhen(true).setUsesChronometer(true)
                .setOngoing(true).setOnlyAlertOnce(true)
                .setContentIntent(openApp(ctx));
            if (Build.VERSION.SDK_INT >= 24) b.setChronometerCountDown(true);
            ((NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE)).notify(NOTIF_ID, b.build());
        } catch (Exception ignored) { }
    }

    /** Bip brevi subito, al volume della sveglia (fine esercizio di stretching/riscaldamento, timer del plank). n = numero di bip (1-4). */
    @PluginMethod public void beep(PluginCall call) {
        final int n = Math.max(1, Math.min(4, call.getInt("n", 3)));
        new Thread(() -> {
            AudioTrack t = null;
            try {
                final int rate = 22050; float step = 0.28f, len = 0.18f, last = 0.4f;
                int total = (int) (rate * (step * (n - 1) + last + 0.05f));
                short[] pcm = new short[total];
                for (int b = 0; b < n; b++) {
                    double f = b < n - 1 ? 880 : 1175; float L = b < n - 1 ? len : last;
                    int i0 = (int) (b * step * rate), cnt = (int) (L * rate);
                    for (int k = 0; k < cnt && i0 + k < total; k++) {
                        double tt = (double) k / rate;
                        double env = Math.min(1.0, tt / 0.02) * Math.max(0.0, 1.0 - Math.max(0.0, tt - 0.03) / (L - 0.03));
                        double sq = Math.sin(2 * Math.PI * f * tt) >= 0 ? 1 : -1;
                        pcm[i0 + k] = (short) (sq * env * 0.45 * Short.MAX_VALUE);
                    }
                }
                AudioAttributes aa = new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
                AudioFormat fmt = new AudioFormat.Builder().setSampleRate(rate)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build();
                t = new AudioTrack(aa, fmt, total * 2, AudioTrack.MODE_STATIC, android.media.AudioManager.AUDIO_SESSION_ID_GENERATE);
                t.write(pcm, 0, total); t.play();
                Thread.sleep((long) (1000L * total / rate) + 150);
            } catch (Exception ignored) { }
            try { if (t != null) { t.stop(); t.release(); } } catch (Exception ignored) { }
        }).start();
        JSObject r = new JSObject(); r.put("ok", true); call.resolve(r);
    }
}
