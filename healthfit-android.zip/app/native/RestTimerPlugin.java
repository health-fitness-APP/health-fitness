package it.healthfit.app;

import android.Manifest;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;

/** Sveglia di fine riposo: suona e vibra anche con l'app in background o lo schermo spento. */
@CapacitorPlugin(
    name = "RestTimer",
    permissions = { @Permission(alias = "notif", strings = { Manifest.permission.POST_NOTIFICATIONS }) }
)
public class RestTimerPlugin extends Plugin {
    static final String CH_COUNT = "hf_rest_count", CH_DONE = "hf_rest_done";
    static final int NOTIF_ID = 4711;

    @PluginMethod public void isAvailable(PluginCall call) {
        JSObject r = new JSObject(); r.put("available", true); r.put("version", 1); call.resolve(r);
    }

    @PluginMethod public void requestPerms(PluginCall call) {
        if (Build.VERSION.SDK_INT >= 33 && getPermissionState("notif") != PermissionState.GRANTED) {
            requestPermissionForAlias("notif", call, "permsCb");
        } else permsCb(call);
    }
    @PermissionCallback private void permsCb(PluginCall call) {
        JSObject r = new JSObject();
        r.put("notif", Build.VERSION.SDK_INT < 33 || getPermissionState("notif") == PermissionState.GRANTED);
        call.resolve(r);
    }

    /** at = fine del riposo (millisecondi epoch); sound/vibrate = cosa fare allo scadere. */
    @PluginMethod public void schedule(PluginCall call) {
        Long at = call.getLong("at");
        if (at == null) { call.reject("at mancante"); return; }
        boolean sound = call.getBoolean("sound", true), vibrate = call.getBoolean("vibrate", true);
        Context ctx = getContext();
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi = alarmIntent(ctx, sound, vibrate);
        am.cancel(pi);
        boolean exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms();
        try {
            if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
        } catch (SecurityException e) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi); exact = false;
        }
        showCountdown(ctx, at);
        JSObject r = new JSObject(); r.put("ok", true); r.put("exact", exact); call.resolve(r);
    }

    @PluginMethod public void cancel(PluginCall call) {
        Context ctx = getContext();
        ((AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE)).cancel(alarmIntent(ctx, true, true));
        ((NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE)).cancel(NOTIF_ID);
        call.resolve();
    }

    private static PendingIntent alarmIntent(Context ctx, boolean sound, boolean vibrate) {
        Intent i = new Intent(ctx, RestAlarmReceiver.class);
        i.putExtra("sound", sound); i.putExtra("vibrate", vibrate);
        return PendingIntent.getBroadcast(ctx, 0, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    static void channels(Context ctx) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationChannel c = new NotificationChannel(CH_COUNT, "Recupero in corso", NotificationManager.IMPORTANCE_LOW);
        c.setShowBadge(false);
        nm.createNotificationChannel(c);
        // il suono e la vibrazione li fa l'app (si possono spegnere dall'app), il canale resta muto
        NotificationChannel d = new NotificationChannel(CH_DONE, "Fine del recupero", NotificationManager.IMPORTANCE_HIGH);
        d.setSound(null, null); d.enableVibration(false); d.setShowBadge(false);
        nm.createNotificationChannel(d);
    }

    static PendingIntent openApp(Context ctx) {
        Intent open = new Intent(ctx, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(ctx, 1, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private static void showCountdown(Context ctx, long at) {
        try {
            channels(ctx);
            Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(ctx, CH_COUNT) : new Notification.Builder(ctx);
            b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("⏱ Recupero")
                .setContentText("Ti avviso io quando è ora di ripartire")
                .setWhen(at).setShowWhen(true).setUsesChronometer(true)
                .setOngoing(true).setOnlyAlertOnce(true)
                .setContentIntent(openApp(ctx));
            if (Build.VERSION.SDK_INT >= 24) b.setChronometerCountDown(true);
            ((NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE)).notify(NOTIF_ID, b.build());
        } catch (Exception ignored) { }
    }
}
