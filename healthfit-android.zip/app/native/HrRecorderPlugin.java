package it.healthfit.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelUuid;
import android.os.PowerManager;
import android.provider.Settings;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@CapacitorPlugin(
    name = "HrRecorder",
    permissions = {
        @Permission(alias = "bt", strings = { Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT }),
        @Permission(alias = "loc", strings = { Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION }),
        @Permission(alias = "notif", strings = { Manifest.permission.POST_NOTIFICATIONS })
    }
)
public class HrRecorderPlugin extends Plugin {

    @Override public void load() {
        HrService.listener = s -> notifyListeners("tick", toJs(s));
    }

    private String[] neededAliases() {
        List<String> a = new ArrayList<>();
        a.add("loc");
        if (Build.VERSION.SDK_INT >= 31) a.add("bt");
        if (Build.VERSION.SDK_INT >= 33) a.add("notif");
        return a.toArray(new String[0]);
    }
    private boolean allGranted() {
        for (String al : neededAliases()) if (getPermissionState(al) != PermissionState.GRANTED) return false;
        return true;
    }

    @PluginMethod public void isAvailable(PluginCall call) {
        JSObject r = new JSObject(); r.put("available", true); r.put("version", 1); call.resolve(r);
    }

    @PluginMethod public void requestPerms(PluginCall call) {
        if (allGranted()) { JSObject r = new JSObject(); r.put("granted", true); call.resolve(r); return; }
        requestPermissionForAliases(neededAliases(), call, "permsCb");
    }
    @PermissionCallback private void permsCb(PluginCall call) {
        JSObject r = new JSObject(); r.put("granted", allGranted()); call.resolve(r);
    }

    /** Cerca le fasce cardio vicine (servizio standard Heart Rate) per 8 secondi. */
    @SuppressLint("MissingPermission")
    @PluginMethod public void scan(PluginCall call) {
        if (!allGranted()) { requestPermissionForAliases(neededAliases(), call, "scanAfterPerms"); return; }
        doScan(call);
    }
    @PermissionCallback private void scanAfterPerms(PluginCall call) {
        if (!allGranted()) { call.reject("Permessi Bluetooth o posizione negati"); return; }
        doScan(call);
    }
    @SuppressLint("MissingPermission")
    private void doScan(PluginCall call) {
        BluetoothManager bm = (BluetoothManager) getContext().getSystemService(Context.BLUETOOTH_SERVICE);
        BluetoothAdapter ad = bm != null ? bm.getAdapter() : null;
        if (ad == null || !ad.isEnabled()) { call.reject("Accendi il Bluetooth"); return; }
        BluetoothLeScanner sc = ad.getBluetoothLeScanner();
        if (sc == null) { call.reject("Bluetooth non disponibile"); return; }
        final Map<String, JSObject> found = new LinkedHashMap<>();
        final ScanCallback scb = new ScanCallback() {
            @Override public void onScanResult(int type, ScanResult res) {
                String addr = res.getDevice().getAddress(); String name = res.getDevice().getName();
                if (name == null && res.getScanRecord() != null) name = res.getScanRecord().getDeviceName();
                JSObject o = new JSObject(); o.put("address", addr); o.put("name", name != null ? name : "Fascia cardio"); o.put("rssi", res.getRssi());
                found.put(addr, o);
            }
        };
        List<ScanFilter> f = new ArrayList<>();
        f.add(new ScanFilter.Builder().setServiceUuid(new ParcelUuid(HrService.HR_SERVICE)).build());
        ScanSettings st = new ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build();
        try { sc.startScan(f, st, scb); } catch (Exception e) { call.reject("Errore nella ricerca: " + e.getMessage()); return; }
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            try { sc.stopScan(scb); } catch (Exception ignored) {}
            JSArray arr = new JSArray(); for (JSObject o : found.values()) arr.put(o);
            JSObject r = new JSObject(); r.put("devices", arr); call.resolve(r);
        }, 8000);
    }

    @PluginMethod public void start(PluginCall call) {
        if (!allGranted()) { requestPermissionForAliases(neededAliases(), call, "startAfterPerms"); return; }
        doStart(call);
    }
    @PermissionCallback private void startAfterPerms(PluginCall call) {
        if (!allGranted()) { call.reject("Permessi negati: servono Bluetooth, posizione e notifiche"); return; }
        doStart(call);
    }
    private void doStart(PluginCall call) {
        Intent i = new Intent(getContext(), HrService.class); i.setAction(HrService.ACTION_START);
        i.putExtra("address", call.getString("address", ""));
        i.putExtra("title", call.getString("title", "Corsa"));
        i.putExtra("lo", call.getInt("lo", -1).intValue()); i.putExtra("hi", call.getInt("hi", -1).intValue());
        i.putExtra("hrMax", call.getInt("hrMax", 185).intValue());
        i.putExtra("alerts", call.getBoolean("alerts", true).booleanValue()); i.putExtra("gps", call.getBoolean("gps", true).booleanValue());
        if (Build.VERSION.SDK_INT >= 26) getContext().startForegroundService(i); else getContext().startService(i);
        call.resolve(toJs(HrService.S));
    }
    private void send(String action) { Intent i = new Intent(getContext(), HrService.class); i.setAction(action); getContext().startService(i); }
    @PluginMethod public void pause(PluginCall call) { send(HrService.ACTION_PAUSE); call.resolve(); }
    @PluginMethod public void resume(PluginCall call) { send(HrService.ACTION_RESUME); call.resolve(); }
    @PluginMethod public void stop(PluginCall call) {
        JSObject r = toJs(HrService.S);
        if (HrService.S.running) send(HrService.ACTION_STOP);
        call.resolve(r);
    }
    @PluginMethod public void state(PluginCall call) { call.resolve(toJs(HrService.S)); }

    /** Batteria: le corse lunghe a schermo spento funzionano meglio senza ottimizzazione. */
    @PluginMethod public void batteryStatus(PluginCall call) {
        PowerManager pm = (PowerManager) getContext().getSystemService(Context.POWER_SERVICE);
        JSObject r = new JSObject(); r.put("unrestricted", Build.VERSION.SDK_INT < 23 || pm.isIgnoringBatteryOptimizations(getContext().getPackageName())); call.resolve(r);
    }
    @SuppressLint("BatteryLife")
    @PluginMethod public void requestBattery(PluginCall call) {
        try {
            Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
            i.setData(Uri.parse("package:" + getContext().getPackageName())); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
        } catch (Exception e) {
            Intent i = new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); getContext().startActivity(i);
        }
        call.resolve();
    }

    static JSObject toJs(HrService.State s) {
        JSObject o = new JSObject();
        o.put("running", s.running); o.put("paused", s.paused); o.put("connected", s.connected);
        o.put("title", s.title); o.put("device", s.deviceName);
        boolean fresh = System.currentTimeMillis() - s.lastBeat < 5000;
        o.put("bpm", fresh ? s.bpm : 0); o.put("maxHr", s.maxHr);
        o.put("avgHr", s.samples > 0 ? Math.round((double) s.sumHr / s.samples) : 0);
        o.put("samples", s.samples); o.put("seconds", s.elapsedSec); o.put("km", Math.round(s.km * 1000) / 1000.0);
        JSArray z = new JSArray(); for (long v : s.zoneSec) z.put(v); o.put("zoneSec", z);
        o.put("startedAt", s.startedAt);
        return o;
    }
}
