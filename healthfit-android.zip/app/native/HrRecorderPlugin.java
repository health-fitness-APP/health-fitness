package it.healthfit.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.ScanRecord;
import android.util.SparseArray;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelUuid;
import android.os.PowerManager;
import android.provider.Settings;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Set;
import java.util.UUID;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@CapacitorPlugin(
    name = "HrRecorder",
    permissions = {
        @Permission(alias = "bt", strings = { Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT }),
        @Permission(alias = "loc", strings = { Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION }),
        @Permission(alias = "notif", strings = { Manifest.permission.POST_NOTIFICATIONS })
    }
)
public class HrRecorderPlugin extends Plugin {

    @Override public void load() {
        HrService.listener = s -> notifyListeners("tick", toJs(s));
    }

    private String[] neededAliases() {
        List<String> a = new ArrayList<>();
        a.add("loc");
        if (Build.VERSION.SDK_INT >= 31) a.add("bt");
        if (Build.VERSION.SDK_INT >= 33) a.add("notif");
        return a.toArray(new String[0]);
    }
    private boolean allGranted() {
        for (String al : neededAliases()) if (getPermissionState(al) != PermissionState.GRANTED) return false;
        return true;
    }

    @PluginMethod public void isAvailable(PluginCall call) {
        JSObject r = new JSObject(); r.put("available", true); r.put("version", 1); call.resolve(r);
    }

    @PluginMethod public void requestPerms(PluginCall call) {
        if (allGranted()) { JSObject r = new JSObject(); r.put("granted", true); call.resolve(r); return; }
        requestPermissionForAliases(neededAliases(), call, "permsCb");
    }
    @PermissionCallback private void permsCb(PluginCall call) {
        JSObject r = new JSObject(); r.put("granted", allGranted()); call.resolve(r);
    }

    /** Cerca le fasce cardio vicine (servizio standard Heart Rate) per 8 secondi. */
    @SuppressLint("MissingPermission")
    @PluginMethod public void scan(PluginCall call) {
        if (!allGranted()) { requestPermissionForAliases(neededAliases(), call, "scanAfterPerms"); return; }
        doScan(call);
    }
    @PermissionCallback private void scanAfterPerms(PluginCall call) {
        if (!allGranted()) { call.reject("Permessi Bluetooth o posizione negati"); return; }
        doScan(call);
    }
    @SuppressLint("MissingPermission")
    private void doScan(PluginCall call) {
        BluetoothManager bm = (BluetoothManager) getContext().getSystemService(Context.BLUETOOTH_SERVICE);
        BluetoothAdapter ad = bm != null ? bm.getAdapter() : null;
        if (ad == null || !ad.isEnabled()) { call.reject("Accendi il Bluetooth"); return; }
        BluetoothLeScanner sc = ad.getBluetoothLeScanner();
        if (sc == null) { call.reject("Bluetooth non disponibile"); return; }
        final Map<String, JSObject> found = new LinkedHashMap<>();
        final ScanCallback scb = new ScanCallback() {
            @Override public void onScanResult(int type, ScanResult res) {
                String addr = res.getDevice().getAddress(); String name = res.getDevice().getName();
                if (name == null && res.getScanRecord() != null) name = res.getScanRecord().getDeviceName();
                JSObject o = new JSObject(); o.put("address", addr); o.put("name", name != null ? name : "Fascia cardio"); o.put("rssi", res.getRssi());
                found.put(addr, o);
            }
        };
        List<ScanFilter> f = new ArrayList<>();
        f.add(new ScanFilter.Builder().setServiceUuid(new ParcelUuid(HrService.HR_SERVICE)).build());
        ScanSettings st = new ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build();
        try { sc.startScan(f, st, scb); } catch (Exception e) { call.reject("Errore nella ricerca: " + e.getMessage()); return; }
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            try { sc.stopScan(scb); } catch (Exception ignored) {}
            JSArray arr = new JSArray(); for (JSObject o : found.values()) arr.put(o);
            JSObject r = new JSObject(); r.put("devices", arr); call.resolve(r);
        }, 8000);
    }

    @PluginMethod public void start(PluginCall call) {
        if (!allGranted()) { requestPermissionForAliases(neededAliases(), call, "startAfterPerms"); return; }
        doStart(call);
    }
    @PermissionCallback private void startAfterPerms(PluginCall call) {
        if (!allGranted()) { call.reject("Permessi negati: servono Bluetooth, posizione e notifiche"); return; }
        doStart(call);
    }
    private void doStart(PluginCall call) {
        Intent i = new Intent(getContext(), HrService.class); i.setAction(HrService.ACTION_START);
        i.putExtra("address", call.getString("address", ""));
        i.putExtra("title", call.getString("title", "Corsa"));
        i.putExtra("lo", call.getInt("lo", -1).intValue()); i.putExtra("hi", call.getInt("hi", -1).intValue());
        i.putExtra("hrMax", call.getInt("hrMax", 185).intValue());
        i.putExtra("alerts", call.getBoolean("alerts", true).booleanValue()); i.putExtra("gps", call.getBoolean("gps", true).booleanValue());
        if (Build.VERSION.SDK_INT >= 26) getContext().startForegroundService(i); else getContext().startService(i);
        call.resolve(toJs(HrService.S));
    }
    private void send(String action) { Intent i = new Intent(getContext(), HrService.class); i.setAction(action); getContext().startService(i); }
    @PluginMethod public void pause(PluginCall call) { send(HrService.ACTION_PAUSE); call.resolve(); }
    @PluginMethod public void resume(PluginCall call) { send(HrService.ACTION_RESUME); call.resolve(); }
    @PluginMethod public void stop(PluginCall call) {
        JSObject r = toJs(HrService.S);
        if (HrService.S.running) { r.put("tr", trackJs(HrService.S, 900)); r.put("totalSec", (System.currentTimeMillis() - HrService.S.startedAt) / 1000); }
        if (HrService.S.running) send(HrService.ACTION_STOP);
        call.resolve(r);
    }
    @PluginMethod public void state(PluginCall call) { call.resolve(toJs(HrService.S)); }

    // ================= prova di un dispositivo Bluetooth (bilancia, metro…) =================
    private static String hex(byte[] b) { if (b == null) return ""; StringBuilder sb = new StringBuilder(); for (byte x : b) sb.append(String.format("%02x ", x & 0xff)); return sb.toString().trim(); }
    private static String advInfo(ScanRecord r) {
        if (r == null) return "";
        StringBuilder sb = new StringBuilder();
        SparseArray<byte[]> m = r.getManufacturerSpecificData();
        if (m != null) for (int i = 0; i < m.size(); i++) sb.append("produttore ").append(Integer.toHexString(m.keyAt(i))).append(": ").append(hex(m.valueAt(i))).append("; ");
        if (r.getServiceData() != null) for (Map.Entry<ParcelUuid, byte[]> e : r.getServiceData().entrySet()) sb.append("servizio ").append(e.getKey().toString().substring(4, 8)).append(": ").append(hex(e.getValue())).append("; ");
        if (r.getServiceUuids() != null) { sb.append("servizi annunciati: "); for (ParcelUuid u : r.getServiceUuids()) sb.append(u.toString().substring(4, 8)).append(" "); }
        return sb.toString().trim();
    }

    /** Elenca tutti i dispositivi Bluetooth vicini (8 secondi), con i dati che inviano negli annunci. */
    @SuppressLint("MissingPermission")
    @PluginMethod public void explore(PluginCall call) {
        if (!allGranted()) { requestPermissionForAliases(neededAliases(), call, "exploreAfterPerms"); return; }
        doExplore(call);
    }
    @PermissionCallback private void exploreAfterPerms(PluginCall call) { if (!allGranted()) { call.reject("Permessi negati"); return; } doExplore(call); }
    @SuppressLint("MissingPermission")
    private void doExplore(PluginCall call) {
        BluetoothManager bm = (BluetoothManager) getContext().getSystemService(Context.BLUETOOTH_SERVICE);
        BluetoothAdapter ad = bm != null ? bm.getAdapter() : null;
        if (ad == null || !ad.isEnabled()) { call.reject("Accendi il Bluetooth"); return; }
        BluetoothLeScanner sc = ad.getBluetoothLeScanner(); if (sc == null) { call.reject("Bluetooth non disponibile"); return; }
        final Map<String, JSObject> found = new LinkedHashMap<>();
        final ScanCallback scb = new ScanCallback() { @Override public void onScanResult(int t, ScanResult res) {
            String name = res.getDevice().getName(); if (name == null && res.getScanRecord() != null) name = res.getScanRecord().getDeviceName();
            JSObject o = new JSObject(); o.put("address", res.getDevice().getAddress()); o.put("name", name != null ? name : "(senza nome)"); o.put("rssi", res.getRssi()); o.put("adv", advInfo(res.getScanRecord()));
            found.put(res.getDevice().getAddress(), o); } };
        ScanSettings st = new ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build();
        try { sc.startScan(null, st, scb); } catch (Exception e) { call.reject("Errore nella ricerca: " + e.getMessage()); return; }
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            try { sc.stopScan(scb); } catch (Exception ignored) {}
            List<JSObject> list = new ArrayList<>(found.values());
            list.sort((a, b) -> Integer.compare(b.optInt("rssi", -200), a.optInt("rssi", -200)));
            JSArray arr = new JSArray(); for (JSObject o : list) arr.put(o);
            JSObject r = new JSObject(); r.put("devices", arr); call.resolve(r);
        }, 8000);
    }

    /** Si collega a un dispositivo, elenca servizi e caratteristiche, attiva le notifiche e registra tutto quello che arriva (anche negli annunci). */
    @SuppressLint("MissingPermission")
    @PluginMethod public void inspect(PluginCall call) {
        final String addr = call.getString("address", "");
        final int secs = Math.max(10, Math.min(60, call.getInt("seconds", 25).intValue()));
        BluetoothManager bm = (BluetoothManager) getContext().getSystemService(Context.BLUETOOTH_SERVICE);
        BluetoothAdapter ad = bm != null ? bm.getAdapter() : null;
        if (ad == null || !ad.isEnabled() || addr.isEmpty()) { call.reject("Bluetooth spento o dispositivo mancante"); return; }
        final List<String> log = new ArrayList<>(); final long t0 = System.currentTimeMillis();
        // bilancia FFB0 (Lepulse/FitDays): se arrivano i dati della persona rispondo all'A1 con il profilo, così misura anche le impedenze
        final JSObject prof = call.getObject("profile", null);
        final int pH = prof != null ? prof.optInt("height", 0) : 0, pAge = prof != null ? prof.optInt("age", 0) : 0;
        final boolean pMale = prof == null || prof.optBoolean("male", true);
        final LinkedList<byte[]> toWrite = new LinkedList<>();
        final boolean[] hs = { false, false }; final int[] anchor = { 0 }; final boolean[] busy = { false }; final int[] tries = { 0 };
        final Set<String> seenAdv = new HashSet<>();
        final Handler h = new Handler(Looper.getMainLooper());
        // annunci del dispositivo (molte bilance mandano il peso così)
        final BluetoothLeScanner sc = ad.getBluetoothLeScanner();
        final ScanCallback adv = new ScanCallback() { @Override public void onScanResult(int t, ScanResult res) {
            String a = advInfo(res.getScanRecord()); if (!a.isEmpty() && seenAdv.add(a)) synchronized (log) { log.add(String.format("%5.1fs annuncio: %s", (System.currentTimeMillis() - t0) / 1000.0, a)); } } };
        if (sc != null) try { List<ScanFilter> f = new ArrayList<>(); f.add(new ScanFilter.Builder().setDeviceAddress(addr).build());
            sc.startScan(f, new ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build(), adv); } catch (Exception e) { log.add("(ascolto annunci non disponibile)"); }
        // collegamento GATT
        final LinkedList<BluetoothGattDescriptor> toEnable = new LinkedList<>();
        BluetoothDevice dev = ad.getRemoteDevice(addr);
        final BluetoothGatt[] g = new BluetoothGatt[1];
        g[0] = dev.connectGatt(getContext(), false, new BluetoothGattCallback() {
            @Override public void onConnectionStateChange(BluetoothGatt gt, int status, int ns) {
                synchronized (log) { log.add(ns == BluetoothProfile.STATE_CONNECTED ? "✓ collegato" : "scollegato (stato " + status + ")"); }
                if (ns == BluetoothProfile.STATE_CONNECTED) gt.discoverServices();
            }
            @Override public void onServicesDiscovered(BluetoothGatt gt, int status) {
                for (BluetoothGattService sv : gt.getServices()) {
                    synchronized (log) { log.add("• servizio " + sv.getUuid().toString().substring(4, 8)); }
                    for (BluetoothGattCharacteristic c : sv.getCharacteristics()) {
                        int p = c.getProperties(); StringBuilder fl = new StringBuilder();
                        if ((p & BluetoothGattCharacteristic.PROPERTY_READ) != 0) fl.append("lettura ");
                        if ((p & BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0) fl.append("notifiche ");
                        if ((p & BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0) fl.append("indicazioni ");
                        if ((p & (BluetoothGattCharacteristic.PROPERTY_WRITE | BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE)) != 0) fl.append("scrittura ");
                        synchronized (log) { log.add("   – " + c.getUuid().toString().substring(4, 8) + " (" + fl.toString().trim() + ")"); }
                        if ((p & (BluetoothGattCharacteristic.PROPERTY_NOTIFY | BluetoothGattCharacteristic.PROPERTY_INDICATE)) != 0) {
                            gt.setCharacteristicNotification(c, true);
                            BluetoothGattDescriptor d = c.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb"));
                            if (d != null) toEnable.add(d);
                        }
                    }
                }
                synchronized (log) { log.add("…ora fai una misura: registro i dati per " + secs + " secondi"); }
                next(gt);
            }
            @SuppressWarnings("deprecation")
            private void next(BluetoothGatt gt) {
                BluetoothGattDescriptor d = toEnable.poll();
                if (d == null) { byte[] w; synchronized (toWrite) { w = toWrite.poll(); } busy[0] = w != null; if (w != null) write(gt, w); return; }
                busy[0] = true;
                boolean ind = (d.getCharacteristic().getProperties() & BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0;
                byte[] v = ind ? BluetoothGattDescriptor.ENABLE_INDICATION_VALUE : BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE;
                if (Build.VERSION.SDK_INT >= 33) gt.writeDescriptor(d, v); else { d.setValue(v); gt.writeDescriptor(d); }
            }
            @Override public void onDescriptorWrite(BluetoothGatt gt, BluetoothGattDescriptor d, int status) { next(gt); }
            @Override public void onCharacteristicWrite(BluetoothGatt gt, BluetoothGattCharacteristic c, int status) { next(gt); }
            @Override public void onCharacteristicChanged(BluetoothGatt gt, BluetoothGattCharacteristic c, byte[] v) { add(c, v); scale(gt, c, v); }
            @SuppressWarnings("deprecation")
            @Override public void onCharacteristicChanged(BluetoothGatt gt, BluetoothGattCharacteristic c) { if (Build.VERSION.SDK_INT < 33) { byte[] v = c.getValue(); add(c, v); scale(gt, c, v); } }
            /** trama da 20 byte: seq, lunghezza, 00, comando, dati, somma dei byte 3..18 & 0x1f */
            private byte[] frame(int seq, int len, int cmd, int... data) {
                byte[] f = new byte[20]; f[0] = (byte) seq; f[1] = (byte) len; f[3] = (byte) cmd;
                for (int i = 0; i < data.length && i < 15; i++) f[4 + i] = (byte) data[i];
                int sum = 0; for (int i = 3; i < 19; i++) sum += f[i] & 0xff; f[19] = (byte) (sum & 0x1f); return f;
            }
            private void scale(BluetoothGatt gt, BluetoothGattCharacteristic c, byte[] v) {
                if (pH <= 0 || v == null || v.length < 4 || !c.getUuid().toString().startsWith("0000ffb3")) return;
                int cmd = v[3] & 0xff;
                if (cmd == 0xa1 && !hs[0]) {
                    hs[0] = true; anchor[0] = v[0] & 0xff;
                    long ts = System.currentTimeMillis() / 1000; int sa = (pMale ? 0x80 : 0) | (Math.max(10, Math.min(99, pAge > 0 ? pAge : 35)) & 0x7f);
                    int hh = Math.max(100, Math.min(220, pH));
                    synchronized (toWrite) {
                        toWrite.add(frame(0, 3, 0xb0, anchor[0]));
                        toWrite.add(frame(1, 0x10, 0xba, 0x66, 0x66, 0x66, 0x66, 0, 0x78, 0, 0, 0, 0, 0xac, 0x17, 0x70, 0x98, 0x2f));
                        int[] p = { (int) (ts >> 24) & 0xff, (int) (ts >> 16) & 0xff, (int) (ts >> 8) & 0xff, (int) ts & 0xff, 0, 0x78, 0, 0, 0, 0, hh, 0, 0, sa, 0x2f };
                        toWrite.add(frame(2, 0x10, 0xba, p)); toWrite.add(frame(3, 0x10, 0xba, p));
                    }
                    synchronized (log) { log.add(String.format("%5.1fs ⇠ profilo inviato alla bilancia (%d cm, %d anni)", (System.currentTimeMillis() - t0) / 1000.0, hh, sa & 0x7f)); }
                    if (!busy[0]) next(gt);
                } else if (cmd == 0xa3 && !hs[1]) {
                    hs[1] = true; synchronized (toWrite) { toWrite.add(frame(4, 3, 0xb0, (anchor[0] + 4) & 0xff)); } if (!busy[0]) next(gt);
                }
            }
            @SuppressWarnings("deprecation")
            private void write(BluetoothGatt gt, byte[] w) {
                BluetoothGattService sv = gt.getService(UUID.fromString("0000ffb0-0000-1000-8000-00805f9b34fb"));
                BluetoothGattCharacteristic ch = sv != null ? sv.getCharacteristic(UUID.fromString("0000ffb1-0000-1000-8000-00805f9b34fb")) : null;
                if (ch == null) { busy[0] = false; return; }
                int type = (ch.getProperties() & BluetoothGattCharacteristic.PROPERTY_WRITE) != 0 ? BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT : BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE;
                synchronized (log) { log.add(String.format("%5.1fs ⇠ ffb1: %s", (System.currentTimeMillis() - t0) / 1000.0, hex(w))); }
                boolean ok;
                if (Build.VERSION.SDK_INT >= 33) ok = gt.writeCharacteristic(ch, w, type) == BluetoothGatt.GATT_SUCCESS;
                else { ch.setWriteType(type); ch.setValue(w); ok = gt.writeCharacteristic(ch); }
                if (!ok && tries[0]++ < 10) synchronized (toWrite) { toWrite.addFirst(w); }
                if (!ok || type == BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE) new Handler(Looper.getMainLooper()).postDelayed(() -> next(gt), ok ? 60 : 150);
            }
            private void add(BluetoothGattCharacteristic c, byte[] v) { synchronized (log) { log.add(String.format("%5.1fs ⇢ %s: %s", (System.currentTimeMillis() - t0) / 1000.0, c.getUuid().toString().substring(4, 8), hex(v))); } }
        }, BluetoothDevice.TRANSPORT_LE);
        h.postDelayed(() -> {
            try { if (sc != null) sc.stopScan(adv); } catch (Exception ignored) {}
            try { if (g[0] != null) { g[0].disconnect(); g[0].close(); } } catch (Exception ignored) {}
            JSArray arr = new JSArray(); synchronized (log) { for (String x : log) arr.put(x); }
            JSObject r = new JSObject(); r.put("name", dev.getName() != null ? dev.getName() : ""); r.put("log", arr); call.resolve(r);
        }, secs * 1000L);
    }

    /** Batteria: le corse lunghe a schermo spento funzionano meglio senza ottimizzazione. */
    @PluginMethod public void batteryStatus(PluginCall call) {
        PowerManager pm = (PowerManager) getContext().getSystemService(Context.POWER_SERVICE);
        JSObject r = new JSObject(); r.put("unrestricted", Build.VERSION.SDK_INT < 23 || pm.isIgnoringBatteryOptimizations(getContext().getPackageName())); call.resolve(r);
    }
    @SuppressLint("BatteryLife")
    @PluginMethod public void requestBattery(PluginCall call) {
        try {
            Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
            i.setData(Uri.parse("package:" + getContext().getPackageName())); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
        } catch (Exception e) {
            Intent i = new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); getContext().startActivity(i);
        }
        call.resolve();
    }

    /** Percorso a colonne per il riepilogo (al massimo n punti). */
    static JSObject trackJs(HrService.State s, int n) {
        JSObject t = new JSObject();
        String[] keys = {"t", "m", "h", "a", "s", "la", "lo"};
        JSArray[] cols = new JSArray[keys.length];
        for (int c = 0; c < keys.length; c++) cols[c] = new JSArray();
        synchronized (s.track) {
            int k = Math.max(1, (int) Math.ceil(s.track.size() / (double) n));
            for (int i = 0; i < s.track.size(); i++) {
                if (i % k != 0 && i != s.track.size() - 1) continue;
                int[] p = s.track.get(i);
                for (int c = 0; c < keys.length; c++) cols[c].put(p[c]);
            }
        }
        for (int c = 0; c < keys.length; c++) t.put(keys[c], cols[c]);
        return t;
    }

    static JSObject toJs(HrService.State s) {
        JSObject o = new JSObject();
        o.put("running", s.running); o.put("paused", s.paused); o.put("connected", s.connected);
        o.put("title", s.title); o.put("device", s.deviceName);
        boolean fresh = System.currentTimeMillis() - s.lastBeat < 5000;
        o.put("bpm", fresh ? s.bpm : 0); o.put("maxHr", s.maxHr);
        o.put("avgHr", s.samples > 0 ? Math.round((double) s.sumHr / s.samples) : 0);
        o.put("samples", s.samples); o.put("seconds", s.elapsedSec); o.put("km", Math.round(s.km * 1000) / 1000.0);
        JSArray z = new JSArray(); for (long v : s.zoneSec) z.put(v); o.put("zoneSec", z);
        o.put("startedAt", s.startedAt);
        return o;
    }
}
