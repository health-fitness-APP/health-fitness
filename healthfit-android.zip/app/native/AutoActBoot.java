package it.healthfit.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

/** Dopo il riavvio del telefono (o un aggiornamento dell'app) rimette il riconoscimento delle attività e il controllo dello sci, senza aprire HealthFit. */
public class AutoActBoot extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent intent) {
        try {
            SharedPreferences p = AutoActPlugin.prefs(c);
            boolean act = p.getBoolean("act", false), ski = p.getBoolean("ski", false);
            if (act) { try { AutoActPlugin.startTransitions(c); } catch (Exception ignored) {} }
            if (act || ski) AutoActPlugin.alarm(c, true);
        } catch (Exception ignored) {}
    }
}
