package it.healthfit.app;

import android.Manifest;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;
import com.google.android.gms.location.ActivityRecognition;
import com.google.android.gms.location.ActivityTransition;
import com.google.android.gms.location.ActivityTransitionRequest;
import com.google.android.gms.location.DetectedActivity;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;

/**
 * Rilevamento automatico senza Samsung Health:
 *  - camminata, corsa e bici dal sensore di movimento di Android (Activity Recognition, basso consumo);
 *  - sci: ogni mezz'ora guarda l'ultima posizione già nota al telefono (niente GPS acceso) e,
 *    se sei nella zona delle piste, propone di avviare / chiudere / registrare la giornata.
 */
@CapacitorPlugin(
    name = "AutoAct",
    permissions = {
        @Permission(alias = "act", strings = { "android.permission.ACTIVITY_RECOGNITION" }),
        @Permission(alias = "loc", strings = { Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION }),
        @Permission(alias = "bgloc", strings = { "android.permission.ACCESS_BACKGROUND_LOCATION" }),
        @Permission(alias = "notif", strings = { "android.permission.POST_NOTIFICATIONS" })
    }
)
public class AutoActPlugin extends Plugin {
    static final String PREFS = "healthfit_auto", CH = "healthfit_auto";
    static final String A_TRANS = "it.healthfit.app.AUTO_TRANS", A_CHECK = "it.healthfit.app.SKI_CHECK";

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE); }

    static void channel(Context c) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CH, "Attività automatiche", NotificationManager.IMPORTANCE_DEFAULT);
            ch.setDescription("Sci sulle piste, camminate, corse e bici riconosciute da sole");
            ((NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
    }

    private boolean granted(String alias) {
        if (alias.equals("act") && Build.VERSION.SDK_INT < 29) return true;
        if (alias.equals("bgloc") && Build.VERSION.SDK_INT < 29) return true;
        if (alias.equals("notif") && Build.VERSION.SDK_INT < 33) return true;
        return getPermissionState(alias) == PermissionState.GRANTED;
    }

    /** {act:bool, ski:bool, lat, lon, km} — chiede i permessi che servono, poi attiva o spegne. */
    @PluginMethod public void config(PluginCall call) {
        boolean act = Boolean.TRUE.equals(call.getBoolean("act", false)), ski = Boolean.TRUE.equals(call.getBoolean("ski", false));
        List<String> need = new ArrayList<>();
        if (act && !granted("act")) need.add("act");
        if (ski && !granted("loc")) need.add("loc");
        if ((act || ski) && !granted("notif")) need.add("notif");
        if (!need.isEmpty() && !Boolean.TRUE.equals(call.getBoolean("silent", false))) { requestPermissionForAliases(need.toArray(new String[0]), call, "afterPerms"); return; }
        afterPerms(call);
    }
    @PermissionCallback private void afterPerms(PluginCall call) {
        boolean ski = Boolean.TRUE.equals(call.getBoolean("ski", false));
        // la posizione "sempre" va chiesta da sola, dopo quella normale (Android 11+ apre le impostazioni)
        if (ski && granted("loc") && !granted("bgloc") && !Boolean.TRUE.equals(call.getBoolean("silent", false)) && !Boolean.TRUE.equals(call.getBoolean("bgAsked", false))) {
            call.getData().put("bgAsked", true);
            requestPermissionForAlias("bgloc", call, "afterPerms"); return;
        }
        apply(call);
    }
    private void apply(PluginCall call) {
        Context c = getContext();
        boolean act = Boolean.TRUE.equals(call.getBoolean("act", false)) && granted("act");
        boolean ski = Boolean.TRUE.equals(call.getBoolean("ski", false)) && granted("loc");
        SharedPreferences.Editor e = prefs(c).edit();
        e.putBoolean("act", act).putBoolean("ski", ski);
        Double la = call.getDouble("lat"), lo = call.getDouble("lon"), km = call.getDouble("km");
        if (la != null) e.putFloat("lat", la.floatValue());
        if (lo != null) e.putFloat("lon", lo.floatValue());
        if (km != null) e.putFloat("km", km.floatValue());
        e.apply();
        channel(c);
        String err = "";
        try { if (act) startTransitions(c); else stopTransitions(c); } catch (Exception ex) { err = "movimento: " + ex.getMessage(); }
        try { alarm(c, ski || act); } catch (Exception ex) { err += " sci: " + ex.getMessage(); }
        JSObject r = new JSObject();
        r.put("act", act); r.put("ski", ski); r.put("bg", granted("bgloc")); r.put("err", err);
        call.resolve(r);
    }

    static PendingIntent transPi(Context c) {
        Intent i = new Intent(c, AutoActReceiver.class); i.setAction(A_TRANS);
        int fl = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 31 ? PendingIntent.FLAG_MUTABLE : 0);
        return PendingIntent.getBroadcast(c, 7101, i, fl);
    }
    @SuppressWarnings("MissingPermission")
    static void startTransitions(Context c) {
        List<ActivityTransition> t = new ArrayList<>();
        int[] types = { DetectedActivity.WALKING, DetectedActivity.RUNNING, DetectedActivity.ON_BICYCLE, DetectedActivity.STILL, DetectedActivity.IN_VEHICLE };
        for (int ty : types) {
            t.add(new ActivityTransition.Builder().setActivityType(ty).setActivityTransition(ActivityTransition.ACTIVITY_TRANSITION_ENTER).build());
            t.add(new ActivityTransition.Builder().setActivityType(ty).setActivityTransition(ActivityTransition.ACTIVITY_TRANSITION_EXIT).build());
        }
        ActivityRecognition.getClient(c).requestActivityTransitionUpdates(new ActivityTransitionRequest(t), transPi(c));
    }
    @SuppressWarnings("MissingPermission")
    static void stopTransitions(Context c) {
        try { ActivityRecognition.getClient(c).removeActivityTransitionUpdates(transPi(c)); } catch (Exception ignored) {}
    }
    static void alarm(Context c, boolean on) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        Intent i = new Intent(c, AutoActReceiver.class); i.setAction(A_CHECK);
        PendingIntent pi = PendingIntent.getBroadcast(c, 7102, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        am.cancel(pi);
        if (on) am.setInexactRepeating(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + 60_000L, AlarmManager.INTERVAL_HALF_HOUR, pi);
    }

    /** Attività riconosciute e richieste di apertura in attesa (le consegna una volta sola). */
    @PluginMethod public void pending(PluginCall call) {
        SharedPreferences p = prefs(getContext());
        JSObject r = new JSObject();
        try { r.put("acts", new JSArray(p.getString("acts", "[]"))); } catch (Exception e) { r.put("acts", new JSArray()); }
        r.put("open", p.getString("open", ""));
        r.put("act", p.getBoolean("act", false)); r.put("ski", p.getBoolean("ski", false)); r.put("bg", granted("bgloc"));
        p.edit().putString("acts", "[]").putString("open", "").apply();
        call.resolve(r);
    }
    /** Passi del telefono per giorno {"2026-11-21": 6230, …}: legge il contapassi adesso e restituisce gli ultimi giorni. */
    @PluginMethod public void steps(PluginCall call) {
        if (!granted("act")) { JSObject r = new JSObject(); r.put("days", new JSObject()); r.put("ok", false); call.resolve(r); return; }
        Steps.snapshot(getContext(), () -> {
            JSObject r = new JSObject(); r.put("ok", true);
            try { r.put("days", new JSObject(prefs(getContext()).getString("steps", "{}"))); } catch (Exception e) { r.put("days", new JSObject()); }
            call.resolve(r);
        });
    }

    /** La giornata di sci di oggi è registrata (a mano o dal telefono): niente più domande oggi. */
    @PluginMethod public void skiDone(PluginCall call) {
        prefs(getContext()).edit().putString("skiDay", call.getString("day", AutoActReceiver.today())).apply();
        call.resolve();
    }
    static void addAct(Context c, String type, long start, long end) {
        SharedPreferences p = prefs(c);
        try {
            JSONArray a = new JSONArray(p.getString("acts", "[]"));
            org.json.JSONObject o = new org.json.JSONObject(); o.put("type", type); o.put("start", start); o.put("end", end);
            a.put(o);
            while (a.length() > 60) a.remove(0);
            p.edit().putString("acts", a.toString()).apply();
        } catch (Exception ignored) {}
    }
}
