package it.healthfit.app;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Legge ad alta voce sul telefono i messaggi della corsa mandati dal Galaxy Watch, abbassando la musica (Spotify…) e poi riportandola su. */
final class WatchSpeaker {
    private static WatchSpeaker inst;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final AudioManager am;
    private final List<String> queue = new ArrayList<>();
    private TextToSpeech tts;
    private boolean ready = false;
    private int speaking = 0;
    private AudioFocusRequest focusReq;
    private final AudioManager.OnAudioFocusChangeListener focusL = fc -> {};
    // il motore della voce si spegne dopo 10 minuti senza messaggi
    private final Runnable idle = this::shutdown;

    static synchronized void say(Context c, String msg) {
        if (inst == null) inst = new WatchSpeaker(c.getApplicationContext());
        final WatchSpeaker w = inst; w.h.post(() -> w.speak(msg));
    }

    private WatchSpeaker(Context ctx) {
        am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
        tts = new TextToSpeech(ctx, st -> h.post(() -> { if (st != TextToSpeech.SUCCESS || tts == null) return;
            tts.setLanguage(Locale.ITALIAN);
            tts.setAudioAttributes(attrs());
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String id) {}
                @Override public void onDone(String id) { h.post(() -> { speaking = Math.max(0, speaking - 1); if (speaking == 0) releaseFocus(); }); }
                @SuppressWarnings("deprecation")
                @Override public void onError(String id) { onDone(id); }
            });
            ready = true;
            for (String m : queue) speak(m);
            queue.clear(); }));
    }

    private static AudioAttributes attrs() {
        return new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build();
    }

    private void speak(String msg) {
        h.removeCallbacks(idle); h.postDelayed(idle, 10 * 60 * 1000L);
        if (!ready) { queue.add(msg); return; }
        if (speaking == 0) requestFocus();
        speaking++;
        tts.speak(msg, TextToSpeech.QUEUE_ADD, null, "hfw" + System.nanoTime());
    }

    @SuppressWarnings("deprecation")
    private void requestFocus() {
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                focusReq = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                    .setAudioAttributes(attrs()).setOnAudioFocusChangeListener(focusL).build();
                am.requestAudioFocus(focusReq);
            } else am.requestAudioFocus(focusL, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK);
        } catch (Exception ignored) {}
    }
    @SuppressWarnings("deprecation")
    private void releaseFocus() {
        try {
            if (Build.VERSION.SDK_INT >= 26) { if (focusReq != null) am.abandonAudioFocusRequest(focusReq); }
            else am.abandonAudioFocus(focusL);
        } catch (Exception ignored) {}
    }

    private void shutdown() {
        synchronized (WatchSpeaker.class) { if (inst == this) inst = null; }
        try { if (tts != null) tts.shutdown(); } catch (Exception ignored) {}
        tts = null; ready = false; speaking = 0; releaseFocus();
    }
}
