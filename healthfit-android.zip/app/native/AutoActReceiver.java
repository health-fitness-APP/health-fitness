package it.healthfit.app;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.os.SystemClock;

import com.google.android.gms.location.ActivityTransition;
import com.google.android.gms.location.ActivityTransitionEvent;
import com.google.android.gms.location.ActivityTransitionResult;
import com.google.android.gms.location.DetectedActivity;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class AutoActReceiver extends BroadcastReceiver {
    static final int N_SKI = 7201;
    static final TimeZone ROME = TimeZone.getTimeZone("Europe/Rome");
    static final long MIN_MS = 10 * 60 * 1000L;

    static String today() { SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd", Locale.ITALY); f.setTimeZone(ROME); return f.format(new Date()); }
    static int minuteOfDay() { Calendar c = Calendar.getInstance(ROME); return c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE); }

    @Override public void onReceive(Context c, Intent intent) {
        String a = intent.getAction();
        try {
            if (AutoActPlugin.A_TRANS.equals(a) && ActivityTransitionResult.hasResult(intent)) onTransitions(c, ActivityTransitionResult.extractResult(intent));
            else if (AutoActPlugin.A_CHECK.equals(a)) {
                skiCheck(c);
                if (AutoActPlugin.prefs(c).getBoolean("act", false)) { final PendingResult pr = goAsync(); Steps.snapshot(c, () -> pr.finish()); }
            }
        } catch (Exception ignored) {}
    }

    // ---------- camminata, corsa, bici ----------
    private static String name(int t) { return t == DetectedActivity.WALKING ? "walk" : t == DetectedActivity.RUNNING ? "run" : t == DetectedActivity.ON_BICYCLE ? "bike" : null; }
    private void onTransitions(Context c, ActivityTransitionResult res) {
        if (res == null) return;
        SharedPreferences p = AutoActPlugin.prefs(c);
        if (!p.getBoolean("act", false)) return;
        for (ActivityTransitionEvent ev : res.getTransitionEvents()) {
            long at = System.currentTimeMillis() - (SystemClock.elapsedRealtimeNanos() - ev.getElapsedRealTimeNanos()) / 1_000_000L;
            String cur = p.getString("cur", ""); long since = p.getLong("curAt", 0);
            String nm = name(ev.getActivityType());
            boolean enter = ev.getTransitionType() == ActivityTransition.ACTIVITY_TRANSITION_ENTER;
            // chiude l'attività in corso quando finisce o quando ne comincia un'altra (fermo, in auto…)
            if (!cur.isEmpty() && (enter || cur.equals(nm))) {
                if (at - since >= MIN_MS && !HrService.S.running) AutoActPlugin.addAct(c, cur, since, at);
                p.edit().putString("cur", "").putLong("curAt", 0).apply(); cur = "";
            }
            if (enter && nm != null) p.edit().putString("cur", nm).putLong("curAt", at).apply();
        }
    }

    // ---------- sci ----------
    private static Location lastKnown(Context c) {
        LocationManager lm = (LocationManager) c.getSystemService(Context.LOCATION_SERVICE);
        Location best = null;
        for (String pr : new String[] { "fused", LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER, LocationManager.PASSIVE_PROVIDER }) {
            try { @SuppressWarnings("MissingPermission") Location l = lm.getLastKnownLocation(pr); if (l != null && (best == null || l.getTime() > best.getTime())) best = l; } catch (Exception ignored) {}
        }
        return best;
    }
    private void skiCheck(Context c) {
        SharedPreferences p = AutoActPlugin.prefs(c);
        if (!p.getBoolean("ski", false)) return;
        String day = today(); int m = minuteOfDay();
        boolean skiing = HrService.S.running && "Sci".equals(HrService.S.title);
        if (skiing) {
            if (m >= 16 * 60 + 45 && m < 20 * 60 && !day.equals(p.getString("askEnd", ""))) {
                p.edit().putString("askEnd", day).putString("open", "sci").apply();
                notify(c, "Hai finito di sciare?", "Tocca e poi «Fine giornata»: calcolo discese, dislivello e calorie.", false);
            }
            return;
        }
        if (HrService.S.running || day.equals(p.getString("skiDay", ""))) return;
        Location l = lastKnown(c);
        boolean fresh = l != null && System.currentTimeMillis() - l.getTime() < 3 * 3600 * 1000L;
        boolean inZone = false;
        if (fresh) {
            float[] d = new float[1];
            Location.distanceBetween(l.getLatitude(), l.getLongitude(), p.getFloat("lat", 44.938f), p.getFloat("lon", 6.751f), d);
            inZone = d[0] <= p.getFloat("km", 12f) * 1000f;
        }
        if (inZone && m >= 8 * 60 && m < 16 * 60) p.edit().putString("zoneDay", day).apply();
        if (inZone && m >= 8 * 60 + 30 && m < 12 * 60 + 30 && !day.equals(p.getString("askStart", ""))) {
            p.edit().putString("askStart", day).apply();
            notify(c, "⛷️ Sei sulle piste?", "Tocca «Avvia» e metti il telefono in tasca: registro la giornata di sci.", true);
        } else if (m >= 16 * 60 + 30 && m < 20 * 60 && day.equals(p.getString("zoneDay", "")) && !day.equals(p.getString("askForgot", ""))) {
            p.edit().putString("askForgot", day).putString("open", "forgot").apply();
            notify(c, "Hai sciato oggi?", "Non hai registrato la giornata: tocca per scriverla in un attimo.", false);
        }
    }

    static void notify(Context c, String title, String text, boolean startBtn) {
        AutoActPlugin.channel(c);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, AutoActPlugin.CH) : new Notification.Builder(c);
        b.setSmallIcon(android.R.drawable.ic_menu_mylocation).setContentTitle(title).setContentText(text)
            .setStyle(new Notification.BigTextStyle().bigText(text))
            .setAutoCancel(true).setContentIntent(RestTimerPlugin.openApp(c));
        if (startBtn && Build.VERSION.SDK_INT >= 26) {
            Intent s = new Intent(c, HrService.class); s.setAction(HrService.ACTION_START);
            s.putExtra("address", ""); s.putExtra("title", "Sci"); s.putExtra("alerts", false); s.putExtra("gps", true);
            s.putExtra("voice", false); s.putExtra("hours", 12); s.putExtra("gpsMs", 2000);
            PendingIntent pi = PendingIntent.getForegroundService(c, 7103, s, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            b.addAction(new Notification.Action.Builder(null, "▶ Avvia", pi).build());
        }
        ((NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE)).notify(N_SKI, b.build());
    }
}
