package it.healthfit.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONObject;

import java.util.Iterator;

/** Contapassi del telefono (sensore hardware, consumo quasi nullo): somma i passi tra una lettura e l'altra, per giorno. */
final class Steps {
    private Steps() {}
    static void snapshot(Context c, Runnable done) {
        final Handler h = new Handler(Looper.getMainLooper());
        try {
            final SensorManager sm = (SensorManager) c.getSystemService(Context.SENSOR_SERVICE);
            final Sensor s = sm == null ? null : sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
            if (s == null) { done.run(); return; }
            final boolean[] fin = { false };
            final SensorEventListener[] ls = new SensorEventListener[1];
            final Runnable end = () -> { if (fin[0]) return; fin[0] = true; try { sm.unregisterListener(ls[0]); } catch (Exception ignored) {} done.run(); };
            ls[0] = new SensorEventListener() {
                @Override public void onSensorChanged(SensorEvent e) { if (fin[0]) return; add(c, (long) e.values[0]); end.run(); }
                @Override public void onAccuracyChanged(Sensor sensor, int a) {}
            };
            sm.registerListener(ls[0], s, SensorManager.SENSOR_DELAY_NORMAL);
            h.postDelayed(end, 4000);
        } catch (Exception e) { done.run(); }
    }
    static synchronized void add(Context c, long cnt) {
        SharedPreferences p = AutoActPlugin.prefs(c);
        long last = p.getLong("stepLast", -1);
        String day = AutoActReceiver.today();
        long delta = last < 0 ? 0 : (cnt >= last ? cnt - last : cnt);   // dopo un riavvio il contatore riparte da zero
        if (delta > 60000) delta = 0;
        try {
            JSONObject o = new JSONObject(p.getString("steps", "{}"));
            o.put(day, o.optLong(day, 0) + delta);
            if (o.length() > 21) { String min = null; for (Iterator<String> it = o.keys(); it.hasNext(); ) { String k = it.next(); if (min == null || k.compareTo(min) < 0) min = k; } if (min != null) o.remove(min); }
            p.edit().putLong("stepLast", cnt).putString("steps", o.toString()).apply();
        } catch (Exception ignored) {}
    }
}
