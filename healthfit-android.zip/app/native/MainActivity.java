package it.healthfit.app;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(HrRecorderPlugin.class);
        registerPlugin(WatchBridgePlugin.class);
        registerPlugin(HcWorkoutPlugin.class);
        registerPlugin(RestTimerPlugin.class);
        super.onCreate(savedInstanceState);
    }
}
