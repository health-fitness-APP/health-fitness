package it.healthfit.app;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import com.getcapacitor.BridgeActivity;
import com.getcapacitor.Plugin;
import java.io.PrintWriter;
import java.io.StringWriter;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        catchCrashes();
        reg(HrRecorderPlugin.class);
        reg(WatchBridgePlugin.class);
        // usa le API di Health Connect integrate in Android 14: su Android 13 o prima non va nemmeno caricato
        if (Build.VERSION.SDK_INT >= 34) reg(HcWorkoutPlugin.class);
        reg(RestTimerPlugin.class);
        reg(AutoActPlugin.class);
        super.onCreate(savedInstanceState);
        showLastCrash();
    }

    private void reg(Class<? extends Plugin> c) {
        try { registerPlugin(c); } catch (Throwable t) { Log.e("HealthFit", "plugin " + c.getSimpleName(), t); }
    }

    /** Se l'app si chiude per un errore, lo salva: alla riapertura lo mostra per poterlo copiare. */
    private void catchCrashes() {
        final Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
        final Context app = getApplicationContext();
        Thread.setDefaultUncaughtExceptionHandler((th, ex) -> {
            try {
                StringWriter sw = new StringWriter(); ex.printStackTrace(new PrintWriter(sw));
                String s = "Android " + Build.VERSION.RELEASE + " (" + Build.VERSION.SDK_INT + ") " + Build.MODEL + "\n" + sw;
                if (s.length() > 4000) s = s.substring(0, 4000);
                app.getSharedPreferences("hfcrash", Context.MODE_PRIVATE).edit().putString("t", s).commit();
            } catch (Throwable ignored) {}
            if (prev != null) prev.uncaughtException(th, ex);
        });
    }

    private void showLastCrash() {
        try {
            final SharedPreferences p = getSharedPreferences("hfcrash", Context.MODE_PRIVATE);
            final String t = p.getString("t", null);
            if (t == null) return;
            p.edit().remove("t").apply();
            new AlertDialog.Builder(this)
                .setTitle("HealthFit si era chiusa per un errore")
                .setMessage("Copia questo testo e mandalo a chi ti ha dato l'app:\n\n" + t)
                .setPositiveButton("Copia", (d, w) -> {
                    try { ((ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("errore HealthFit", t)); } catch (Throwable ignored) {}
                })
                .setNegativeButton("Chiudi", null)
                .show();
        } catch (Throwable ignored) {}
    }
}
