package it.healthfit.app;

import android.health.connect.AggregateRecordsRequest;
import android.health.connect.AggregateRecordsResponse;
import android.health.connect.HealthConnectException;
import android.health.connect.HealthConnectManager;
import android.health.connect.ReadRecordsRequestUsingFilters;
import android.health.connect.ReadRecordsResponse;
import android.health.connect.TimeInstantRangeFilter;
import android.health.connect.datatypes.ActiveCaloriesBurnedRecord;
import android.health.connect.datatypes.AggregationType;
import android.health.connect.datatypes.TotalCaloriesBurnedRecord;
import android.health.connect.datatypes.units.Energy;
import android.health.connect.datatypes.DataOrigin;
import android.health.connect.datatypes.DistanceRecord;
import android.health.connect.datatypes.ExerciseLap;
import android.health.connect.datatypes.ExerciseRoute;
import android.health.connect.datatypes.ExerciseSegment;
import android.health.connect.datatypes.ExerciseSegmentType;
import android.health.connect.datatypes.ExerciseSessionRecord;
import android.health.connect.datatypes.Record;
import android.health.connect.datatypes.SpeedRecord;
import android.health.connect.datatypes.units.Length;
import android.os.Build;
import android.os.OutcomeReceiver;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * Dettagli veri degli allenamenti da Health Connect (Android 14+):
 * tempo attivo senza pause e distanza della sola app che ha registrato l'allenamento
 * (Samsung Health), più giri, velocità e percorso GPS quando disponibili.
 * Il plugin Health generico calcola invece fine-inizio (pause comprese) e somma la distanza di tutte le app.
 */
@CapacitorPlugin(name = "HcWorkout")
public class HcWorkoutPlugin extends Plugin {

    private final ExecutorService work = Executors.newSingleThreadExecutor();
    private final ExecutorService cb = Executors.newCachedThreadPool();

    @PluginMethod
    public void isAvailable(PluginCall call) {
        JSObject r = new JSObject();
        r.put("available", Build.VERSION.SDK_INT >= 34);
        r.put("version", 2);
        call.resolve(r);
    }

    private static final String[] EXTRA = {
        "android.permission.health.READ_SPEED",
        "android.permission.health.READ_EXERCISE_ROUTES"
    };

    /** Chiede i permessi in più (velocità e percorso) usati per la distanza esatta. */
    @PluginMethod
    public void requestExtra(PluginCall call) {
        JSObject r = new JSObject();
        List<String> miss = new ArrayList<>();
        for (String p : EXTRA)
            if (getContext().checkSelfPermission(p) != android.content.pm.PackageManager.PERMISSION_GRANTED) miss.add(p);
        if (!miss.isEmpty() && Build.VERSION.SDK_INT >= 34 && getActivity() != null) {
            try { getActivity().requestPermissions(miss.toArray(new String[0]), 4711); } catch (Exception ignored) {}
        }
        r.put("missing", miss.size());
        call.resolve(r);
    }

    @PluginMethod
    public void sessions(PluginCall call) {
        if (Build.VERSION.SDK_INT < 34) { call.reject("Serve Android 14 o successivo", "unsupported"); return; }
        final String from = call.getString("startDate"), to = call.getString("endDate");
        work.execute(() -> {
            try {
                HealthConnectManager hc = getContext().getSystemService(HealthConnectManager.class);
                if (hc == null) { call.reject("Health Connect non disponibile", "unavailable"); return; }
                Instant a = from != null ? Instant.parse(from) : Instant.now().minusSeconds(10L * 86400);
                Instant b = to != null ? Instant.parse(to) : Instant.now();
                JSArray out = new JSArray();
                long token = -1;
                for (int page = 0; page < 10; page++) {
                    ReadRecordsRequestUsingFilters.Builder<ExerciseSessionRecord> rb =
                        new ReadRecordsRequestUsingFilters.Builder<>(ExerciseSessionRecord.class)
                            .setTimeRangeFilter(range(a, b)).setPageSize(100);
                    if (token != -1) rb.setPageToken(token);
                    ReadRecordsResponse<ExerciseSessionRecord> resp = read(hc, rb.build());
                    for (ExerciseSessionRecord s : resp.getRecords()) out.put(describe(hc, s));
                    token = resp.getNextPageToken();
                    if (token == -1) break;
                }
                JSObject r = new JSObject();
                r.put("sessions", out);
                call.resolve(r);
            } catch (Exception e) {
                call.reject(String.valueOf(e.getMessage()), "error");
            }
        });
    }

    private JSObject describe(HealthConnectManager hc, ExerciseSessionRecord s) {
        JSObject o = new JSObject();
        Instant st = s.getStartTime(), en = s.getEndTime();
        String pkg = s.getMetadata().getDataOrigin().getPackageName();
        DataOrigin origin = new DataOrigin.Builder().setPackageName(pkg).build();
        o.put("id", s.getMetadata().getId());
        o.put("origin", pkg);
        o.put("type", s.getExerciseType());
        o.put("startDate", st.toString());
        o.put("endDate", en.toString());
        long totalMs = en.toEpochMilli() - st.toEpochMilli();
        o.put("totalSec", totalMs / 1000.0);

        // pause dai segmenti
        List<long[]> pauses = new ArrayList<>();
        long pauseMs = 0;
        try {
            for (ExerciseSegment g : s.getSegments()) {
                int t = g.getSegmentType();
                if (t == ExerciseSegmentType.EXERCISE_SEGMENT_TYPE_PAUSE || t == ExerciseSegmentType.EXERCISE_SEGMENT_TYPE_REST) {
                    long p0 = g.getStartTime().toEpochMilli(), p1 = g.getEndTime().toEpochMilli();
                    pauses.add(new long[]{p0, p1});
                    pauseMs += Math.max(0, p1 - p0);
                }
            }
            o.put("segments", s.getSegments().size());
        } catch (Exception ignored) {}
        o.put("pauseSec", pauseMs / 1000.0);

        // tempo attivo calcolato da Health Connect (esclude le pause)
        try {
            Long d = aggregate(hc, ExerciseSessionRecord.EXERCISE_DURATION_TOTAL, st, en, origin);
            if (d != null && d > 0) o.put("hcDurSec", Math.min(d, totalMs) / 1000.0);
            if (d != null && d > 0 && d < totalMs - 20000) o.put("activeSec", d / 1000.0);
        } catch (Exception ignored) {}
        if (!o.has("activeSec") && pauseMs > 0) o.put("activeSec", Math.max(0, totalMs - pauseMs) / 1000.0);

        // giri
        try {
            double lapsM = 0; int n = 0;
            long lapMs = 0;
            for (ExerciseLap l : s.getLaps()) { Length len = l.getLength(); if (len != null) { lapsM += len.getInMeters(); n++; }
                lapMs += Math.max(0, l.getEndTime().toEpochMilli() - l.getStartTime().toEpochMilli()); }
            if (lapMs > 60000 && lapMs < totalMs - 20000) o.put("lapsSec", lapMs / 1000.0);
            o.put("laps", s.getLaps().size());
            if (n > 0 && lapsM > 0) o.put("lapsM", lapsM);
        } catch (Exception ignored) {}

        // distanza della sola app dell'allenamento, e di tutte le app
        try {
            Length l = aggregate(hc, DistanceRecord.DISTANCE_TOTAL, st, en, origin);
            if (l != null && l.getInMeters() > 0) o.put("distOriginM", l.getInMeters());
        } catch (Exception e) { o.put("distOriginErr", String.valueOf(e.getMessage())); }
        try {
            Length l = aggregate(hc, DistanceRecord.DISTANCE_TOTAL, st, en, null);
            if (l != null && l.getInMeters() > 0) o.put("distAllM", l.getInMeters());
        } catch (Exception ignored) {}

        // calorie registrate dalla sola app dell'allenamento (kcal)
        try {
            Energy e = aggregate(hc, ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL, st, en, origin);
            if (e != null && e.getInCalories() > 0) o.put("activeKcal", e.getInCalories() / 1000.0);
        } catch (Exception ignored) {}
        try {
            Energy e = aggregate(hc, TotalCaloriesBurnedRecord.ENERGY_TOTAL, st, en, origin);
            if (e != null && e.getInCalories() > 0) o.put("totalKcal", e.getInCalories() / 1000.0);
        } catch (Exception ignored) {}

        // distanza dalla velocità registrata (esclude le pause)
        try {
            ReadRecordsResponse<SpeedRecord> sp = read(hc,
                new ReadRecordsRequestUsingFilters.Builder<>(SpeedRecord.class)
                    .setTimeRangeFilter(range(st, en)).addDataOrigins(origin).setPageSize(1000).build());
            List<long[]> pts = new ArrayList<>(); // [ms, mm/s]
            for (SpeedRecord r : sp.getRecords())
                for (SpeedRecord.SpeedRecordSample x : r.getSamples())
                    pts.add(new long[]{x.getTime().toEpochMilli(), Math.round(x.getSpeed().getInMetersPerSecond() * 1000)});
            pts.sort((p, q) -> Long.compare(p[0], q[0]));
            double m = 0;
            for (int i = 0; i + 1 < pts.size(); i++) {
                long t0 = pts.get(i)[0], dt = Math.min(30000, pts.get(i + 1)[0] - t0);
                if (dt <= 0 || inPause(t0, pauses)) continue;
                m += pts.get(i)[1] / 1000.0 * dt / 1000.0;
            }
            if (pts.size() > 10 && m > 0) o.put("speedM", m);
            long movMs = 0;
            for (int i = 0; i + 1 < pts.size(); i++) {
                long t0 = pts.get(i)[0], dt = Math.min(30000, pts.get(i + 1)[0] - t0);
                if (dt > 0 && pts.get(i)[1] >= 700 && !inPause(t0, pauses)) movMs += dt; // >= 0,7 m/s: in movimento
            }
            if (pts.size() > 10 && movMs > 60000) o.put("movingSec", movMs / 1000.0);
            o.put("speedSamples", pts.size());
        } catch (Exception ignored) {}

        // percorso GPS (solo se l'utente ha dato il permesso al percorso)
        try {
            if (s.hasRoute()) {
                ExerciseRoute route = s.getRoute();
                o.put("hasRoute", true);
                if (route != null) {
                    List<ExerciseRoute.Location> L = route.getRouteLocations();
                    double m = 0;
                    for (int i = 1; i < L.size(); i++) {
                        ExerciseRoute.Location p = L.get(i - 1), q = L.get(i);
                        if (inPause(p.getTime().toEpochMilli(), pauses)) continue;
                        m += hav(p.getLatitude(), p.getLongitude(), q.getLatitude(), q.getLongitude());
                    }
                    if (L.size() > 10 && m > 0) o.put("routeM", m);
                }
            }
        } catch (Exception ignored) {}
        return o;
    }

    private static boolean inPause(long t, List<long[]> pauses) {
        for (long[] p : pauses) if (t >= p[0] && t < p[1]) return true;
        return false;
    }

    private static double hav(double la1, double lo1, double la2, double lo2) {
        double R = 6371000, dLa = Math.toRadians(la2 - la1), dLo = Math.toRadians(lo2 - lo1);
        double x = Math.sin(dLa / 2) * Math.sin(dLa / 2)
            + Math.cos(Math.toRadians(la1)) * Math.cos(Math.toRadians(la2)) * Math.sin(dLo / 2) * Math.sin(dLo / 2);
        return 2 * R * Math.asin(Math.min(1, Math.sqrt(x)));
    }

    private static TimeInstantRangeFilter range(Instant a, Instant b) {
        return new TimeInstantRangeFilter.Builder().setStartTime(a).setEndTime(b).build();
    }

    private <T extends Record> ReadRecordsResponse<T> read(HealthConnectManager hc, ReadRecordsRequestUsingFilters<T> req) throws Exception {
        CompletableFuture<ReadRecordsResponse<T>> f = new CompletableFuture<>();
        hc.readRecords(req, cb, new OutcomeReceiver<ReadRecordsResponse<T>, HealthConnectException>() {
            @Override public void onResult(ReadRecordsResponse<T> r) { f.complete(r); }
            @Override public void onError(HealthConnectException e) { f.completeExceptionally(e); }
        });
        return f.get(20, TimeUnit.SECONDS);
    }

    private <T> T aggregate(HealthConnectManager hc, AggregationType<T> type, Instant a, Instant b, DataOrigin origin) throws Exception {
        AggregateRecordsRequest.Builder<T> rb = new AggregateRecordsRequest.Builder<T>(range(a, b)).addAggregationType(type);
        if (origin != null) rb.addDataOriginsFilter(origin);
        CompletableFuture<AggregateRecordsResponse<T>> f = new CompletableFuture<>();
        hc.aggregate(rb.build(), cb, new OutcomeReceiver<AggregateRecordsResponse<T>, HealthConnectException>() {
            @Override public void onResult(AggregateRecordsResponse<T> r) { f.complete(r); }
            @Override public void onError(HealthConnectException e) { f.completeExceptionally(e); }
        });
        return f.get(20, TimeUnit.SECONDS).get(type);
    }
}
