package it.healthfit.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.AudioAttributes;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.telephony.SmsManager;

import java.util.Locale;

/**
 * Durante la giornata di sci registrata dal telefono:
 *  - batteria: avviso al 30% e al 15% (col freddo il telefono si spegne prima);
 *  - caduta: colpo forte seguito da immobilità → "Stai bene?" con suono e vibrazione per 60 secondi;
 *    se non rispondi e hai indicato un contatto, gli manda un SMS con la tua posizione.
 */
public class SkiGuard implements SensorEventListener {
    static final String CH = "healthfit_sos", A_OK = "it.healthfit.app.SOS_OK", A_HELP = "it.healthfit.app.SOS_HELP";
    static final int N_BATT = 7301, N_SOS = 7302;
    private static SkiGuard cur;

    private final Context c;
    private final Handler h = new Handler(Looper.getMainLooper());
    private SensorManager sm;
    private int battWarn = 100;
    private long impactAt = 0, stillFrom = 0, lastMove = 0, alarmAt = 0;
    private Ringtone ring; private boolean testMode;

    private SkiGuard(Context c) { this.c = c.getApplicationContext(); }

    static void start(Context c) {
        stop();
        cur = new SkiGuard(c);
        cur.begin();
    }
    static void test(Context c) { if (cur == null) { cur = new SkiGuard(c); cur.h.removeCallbacksAndMessages(null); } cur.testMode = true; cur.h.post(cur::askOk); }
    static void stop() { if (cur != null) { cur.end(); cur = null; } }

    private void begin() {
        channel(c);
        try {
            sm = (SensorManager) c.getSystemService(Context.SENSOR_SERVICE);
            Sensor acc = sm != null ? sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) : null;
            // 50 letture al secondo, consegnate a gruppi ogni 5 secondi: il telefono resta addormentato tra un gruppo e l'altro
            if (acc != null && fallOn(c)) sm.registerListener(this, acc, 20000, 5_000_000);
        } catch (Exception ignored) {}
        h.postDelayed(batt, 60_000);
    }
    private void end() {
        h.removeCallbacksAndMessages(null);
        try { if (sm != null) sm.unregisterListener(this); } catch (Exception ignored) {}
        stopAlarm();
    }

    static SharedPreferences prefs(Context c) { return AutoActPlugin.prefs(c); }
    static boolean fallOn(Context c) { return prefs(c).getBoolean("fall", true); }

    // ---------- batteria ----------
    private final Runnable batt = new Runnable() { @Override public void run() {
        try {
            Intent b = c.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            int lv = b != null ? b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) : -1, sc = b != null ? b.getIntExtra(BatteryManager.EXTRA_SCALE, 100) : 100;
            boolean chg = b != null && b.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0;
            int pc = lv >= 0 ? Math.round(lv * 100f / sc) : -1;
            int step = pc <= 15 ? 15 : pc <= 30 ? 30 : 100;
            if (pc >= 0 && !chg && step < battWarn) {
                battWarn = step;
                note(N_BATT, "🔋 Batteria al " + pc + "%",
                    step == 15 ? "Col freddo il telefono può spegnersi da un momento all'altro: tienilo in una tasca interna e, se puoi, collegalo a una batteria esterna. La registrazione continua finché resta acceso."
                               : "Col freddo si scarica in fretta: tasca interna vicino al corpo, risparmio energetico attivo, niente foto e video lunghi.", false);
            }
        } catch (Exception ignored) {}
        h.postDelayed(this, 60_000);
    }};

    // ---------- caduta ----------
    @Override public void onSensorChanged(SensorEvent e) {
        float x = e.values[0], y = e.values[1], z = e.values[2];
        double g = Math.sqrt(x * x + y * y + z * z) / 9.81;
        long t = e.timestamp / 1_000_000L;   // millisecondi dall'avvio
        if (alarmAt > 0) return;
        if (g > 3.5) { impactAt = t; stillFrom = 0; return; }
        if (impactAt == 0) return;
        if (t - impactAt > 40_000) { impactAt = 0; return; }   // ti sei mosso: niente
        if (t - impactAt < 3000) return;                         // lascio passare il rimbalzo
        if (Math.abs(g - 1) > 0.25) { lastMove = t; stillFrom = 0; return; }
        if (stillFrom == 0) stillFrom = t;
        if (t - stillFrom >= 25_000) { impactAt = 0; stillFrom = 0; h.post(this::askOk); }
    }
    @Override public void onAccuracyChanged(Sensor s, int a) {}

    private void askOk() {
        if (alarmAt > 0) return;
        alarmAt = System.currentTimeMillis();
        String who = prefs(c).getString("sosName", "");
        boolean canSms = !prefs(c).getString("sosNum", "").isEmpty() && c.checkSelfPermission(android.Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
        Notification.Builder b = builder("Sei caduto? Stai bene?", canSms ? "Se non rispondi entro 60 secondi avviso " + (who.isEmpty() ? "il tuo contatto" : who) + " con la tua posizione." : "Tocca «Sto bene». Per avvisare qualcuno da solo, metti un contatto nella pagina Sci.");
        b.setOngoing(true).setCategory(Notification.CATEGORY_ALARM).setPriority(Notification.PRIORITY_MAX);
        b.addAction(new Notification.Action.Builder(null, "✓ Sto bene", act(A_OK, 1)).build());
        if (canSms) b.addAction(new Notification.Action.Builder(null, "🆘 Avvisa adesso", act(A_HELP, 2)).build());
        b.setFullScreenIntent(RestTimerPlugin.openApp(c), true);
        nm().notify(N_SOS, b.build());
        try { ring = RingtoneManager.getRingtone(c, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM));
            if (ring != null) { if (Build.VERSION.SDK_INT >= 28) ring.setLooping(true); ring.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build()); ring.play(); } } catch (Exception ignored) {}
        try { Vibrator v = (Vibrator) c.getSystemService(Context.VIBRATOR_SERVICE); if (v != null && Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(new long[]{0, 800, 400}, 0)); } catch (Exception ignored) {}
        h.postDelayed(() -> { if (alarmAt <= 0) return;
            if (testMode) { alarmAt = 0; stopAlarm(); testMode = false; nm().cancel(N_SOS); note(N_SOS + 1, "Prova finita", "In una caduta vera adesso avrei mandato l'SMS con la posizione" + (prefs(c).getString("sosNum", "").isEmpty() ? " (prima metti un contatto)." : "."), false); return; }
            help(c, true); }, 60_000);
    }
    private void stopAlarm() {
        try { if (ring != null) ring.stop(); } catch (Exception ignored) {}
        ring = null;
        try { Vibrator v = (Vibrator) c.getSystemService(Context.VIBRATOR_SERVICE); if (v != null) v.cancel(); } catch (Exception ignored) {}
    }
    static void ok(Context c) {
        if (cur != null) { cur.alarmAt = 0; cur.testMode = false; cur.stopAlarm(); cur.h.removeCallbacksAndMessages(null); if (HrService.S.running) cur.h.postDelayed(cur.batt, 60_000); }
        ((NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE)).cancel(N_SOS);
    }
    static void help(Context c, boolean auto) {
        boolean test = cur != null && cur.testMode;
        if (cur != null) { cur.alarmAt = 0; cur.stopAlarm(); cur.testMode = false; }
        if (test) { ((NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE)).cancel(N_SOS); return; }
        String num = prefs(c).getString("sosNum", ""), who = prefs(c).getString("sosName", "");
        NotificationManager m = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE); m.cancel(N_SOS);
        if (num.isEmpty() || c.checkSelfPermission(android.Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) return;
        String pos = HrService.S.lat != 0 ? String.format(Locale.US, "https://maps.google.com/?q=%.5f,%.5f", HrService.S.lat, HrService.S.lon) : "posizione non disponibile";
        String alt = !Double.isNaN(HrService.S.alt) ? " (quota " + Math.round(HrService.S.alt) + " m)" : "";
        String msg = (auto ? "HealthFit: possibile caduta sugli sci, nessuna risposta da 60 secondi. " : "HealthFit: richiesta di aiuto sugli sci. ") + "Posizione" + alt + ": " + pos;
        try { SmsManager sm = Build.VERSION.SDK_INT >= 31 ? c.getSystemService(SmsManager.class) : SmsManager.getDefault();
            sm.sendMultipartTextMessage(num, null, sm.divideMessage(msg), null, null);
            Notification.Builder b = builder(c, "🆘 Ho avvisato " + (who.isEmpty() ? num : who), "Gli ho mandato la tua posizione per SMS. Se stai bene, chiamalo per tranquillizzarlo.");
            m.notify(N_SOS + 1, b.build());
        } catch (Exception e) {
            m.notify(N_SOS + 1, builder(c, "SMS non inviato", "Non sono riuscito a mandare l'SMS: " + e.getMessage()).build());
        }
    }

    // ---------- notifiche ----------
    static void channel(Context c) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CH, "Sicurezza sugli sci", NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("Batteria bassa e possibile caduta durante la giornata di sci");
            ((NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
    }
    private NotificationManager nm() { return (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE); }
    private static Notification.Builder builder(Context c, String title, String text) {
        channel(c);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, CH) : new Notification.Builder(c);
        return b.setSmallIcon(android.R.drawable.ic_dialog_alert).setContentTitle(title).setContentText(text)
            .setStyle(new Notification.BigTextStyle().bigText(text)).setAutoCancel(true).setContentIntent(RestTimerPlugin.openApp(c));
    }
    private Notification.Builder builder(String title, String text) { return builder(c, title, text); }
    private void note(int id, String title, String text, boolean ongoing) { nm().notify(id, builder(title, text).setOngoing(ongoing).build()); }
    private PendingIntent act(String a, int rq) {
        Intent i = new Intent(c, Act.class); i.setAction(a);
        return PendingIntent.getBroadcast(c, 7310 + rq, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    /** Pulsanti della notifica "Stai bene?". */
    public static class Act extends BroadcastReceiver {
        @Override public void onReceive(Context c, Intent i) {
            if (A_OK.equals(i.getAction())) ok(c);
            else if (A_HELP.equals(i.getAction())) help(c, false);
        }
    }
}
