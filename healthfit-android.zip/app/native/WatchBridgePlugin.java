package it.healthfit.app;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;

import androidx.core.content.ContextCompat;
import androidx.wear.remote.interactions.RemoteActivityHelper;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.google.android.gms.wearable.Node;
import com.google.android.gms.wearable.Wearable;

import org.json.JSONArray;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;

/** Ponte con l'app HealthFit sul Galaxy Watch: manda la corsa da fare e riceve il riepilogo. */
@CapacitorPlugin(name = "WatchBridge")
public class WatchBridgePlugin extends Plugin {
    static WatchBridgePlugin instance;

    @Override public void load() { instance = this; }

    void emit(JSONObject o) { try { notifyListeners("watchResult", JSObject.fromJSONObject(o)); } catch (Exception ignored) {} }

    /** Elenco degli orologi collegati. */
    @PluginMethod public void nodes(PluginCall call) {
        Wearable.getNodeClient(getContext()).getConnectedNodes()
            .addOnSuccessListener(ns -> { JSArray a = new JSArray(); for (Node n : ns) { JSObject o = new JSObject(); o.put("id", n.getId()); o.put("name", n.getDisplayName()); a.put(o); }
                JSObject r = new JSObject(); r.put("nodes", a); call.resolve(r); })
            .addOnFailureListener(e -> call.reject("Wear OS non disponibile: " + e.getMessage()));
    }

    /** Manda la corsa all'orologio e apre l'app HealthFit sul polso. */
    @PluginMethod public void sendRun(PluginCall call) {
        final String plan = call.getString("plan", "{}");
        final Context ctx = getContext();
        Wearable.getNodeClient(ctx).getConnectedNodes().addOnSuccessListener(ns -> {
            if (ns.isEmpty()) { call.reject("Nessun orologio collegato al telefono"); return; }
            byte[] data = plan.getBytes(StandardCharsets.UTF_8);
            RemoteActivityHelper rah = new RemoteActivityHelper(ctx, ContextCompat.getMainExecutor(ctx));
            for (Node n : ns) {
                Wearable.getMessageClient(ctx).sendMessage(n.getId(), "/healthfit/run", data);
                try {
                    Intent i = new Intent(Intent.ACTION_VIEW).addCategory(Intent.CATEGORY_BROWSABLE).setData(Uri.parse("healthfit://run"));
                    rah.startRemoteActivity(i, n.getId());
                } catch (Exception ignored) {}
            }
            JSObject r = new JSObject(); r.put("sent", ns.size()); r.put("watch", ns.get(0).getDisplayName()); call.resolve(r);
        }).addOnFailureListener(e -> call.reject("Wear OS non disponibile: " + e.getMessage()));
    }

    /** Riepiloghi arrivati dall'orologio mentre l'app era chiusa. */
    @PluginMethod public void pending(PluginCall call) {
        SharedPreferences p = getContext().getSharedPreferences("hf_watch", Context.MODE_PRIVATE);
        String s = p.getString("results", "[]"); p.edit().remove("results").apply();
        JSObject r = new JSObject(); JSArray arr = new JSArray();
        try { JSONArray j = new JSONArray(s); for (int i = 0; i < j.length(); i++) arr.put(j.getJSONObject(i)); } catch (Exception ignored) {}
        r.put("results", arr);
        call.resolve(r);
    }
}
